// export const API_URL = 'https://jh5nng6t-5000.asse.devtunnels.ms';
export const API_URL = 'https://api.o-chat.live';
