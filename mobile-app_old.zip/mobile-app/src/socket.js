import io from 'socket.io-client';
import { API_URL } from './config';

let socket = null;

export const getSocket = () => {
  return socket;
};

export const initSocket = (userId) => {
  if (!socket) {
    socket = io(API_URL, {
      transports: ['websocket'],
      forceNew: true
    });
    
    socket.on('connect', () => {
      console.log('Socket connected to backend!');
      socket.emit('merchant_join', userId);
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected from backend');
    });
  }
  return socket;
};

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};
