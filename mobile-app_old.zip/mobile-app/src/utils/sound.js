import { Audio } from 'expo-av';
import { API_URL } from '../config';

export const playSound = async (type) => {
  const soundUrls = {
    new_message: `${API_URL}/sound-effect/mixkit-hard-pop-click-2364.wav`,
    send_message: `${API_URL}/sound-effect/mixkit-hard-pop-click-2364.wav`
  };
  
  try {
    // Ensure sound plays even if device is set to silent or vibrate mode
    await Audio.setAudioModeAsync({
      playsInSilentModeIOS: true,
      staysActiveInBackground: false,
      shouldRouteThroughReceiverIOS: false,
    }).catch(err => console.log('Audio mode config error:', err));

    const { sound } = await Audio.Sound.createAsync(
      { uri: soundUrls[type] },
      { shouldPlay: true }
    );
    sound.setOnPlaybackStatusUpdate((status) => {
      if (status.didJustFinish) {
        sound.unloadAsync();
      }
    });
  } catch (error) {
    console.log('Audio playback error:', error);
  }
};
