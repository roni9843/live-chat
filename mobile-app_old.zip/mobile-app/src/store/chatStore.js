import { create } from 'zustand';

const useChatStore = create((set, get) => ({
  sessions: [],
  activeSessionId: null,
  totalUnread: 0,
  messages: {},
  hasMore: {},
  onlineAgents: [],

  setOnlineAgents: (onlineAgents) => {
    set({ onlineAgents });
  },

  setSessions: (sessions) => {
    set({ sessions });
    get().calculateTotalUnread();
  },

  setActiveSessionId: (activeSessionId) => {
    set({ activeSessionId });
  },

  setMessages: (sessionId, msgs) => {
    set((state) => ({
      messages: { ...state.messages, [sessionId]: msgs }
    }));
  },

  prependMessages: (sessionId, oldMsgs) => {
    set((state) => {
      const current = state.messages[sessionId] || [];
      const existingIds = new Set(current.map((m) => m._id));
      const filteredOld = oldMsgs.filter((m) => !existingIds.has(m._id));
      return {
        messages: { ...state.messages, [sessionId]: [...filteredOld, ...current] }
      };
    });
  },

  addMessage: (sessionId, msg) => {
    set((state) => {
      const current = state.messages[sessionId] || [];
      if (msg.tempId) {
        const tempIndex = current.findIndex((m) => m.tempId === msg.tempId);
        if (tempIndex !== -1) {
          const updated = [...current];
          updated[tempIndex] = msg;
          return { messages: { ...state.messages, [sessionId]: updated } };
        }
      }
      if (msg._id && current.some((m) => m._id === msg._id)) return state;
      return {
        messages: { ...state.messages, [sessionId]: [...current, msg] }
      };
    });
  },

  updateMessage: (sessionId, updatedMsg) => {
    set((state) => {
      const current = state.messages[sessionId] || [];
      return {
        messages: {
          ...state.messages,
          [sessionId]: current.map((m) => (m._id === updatedMsg._id ? updatedMsg : m))
        }
      };
    });
  },

  setHasMore: (sessionId, val) => {
    set((state) => ({
      hasMore: { ...state.hasMore, [sessionId]: val }
    }));
  },

  calculateTotalUnread: () => {
    const sessions = get().sessions;
    const total = sessions.reduce((sum, s) => sum + (s.unreadCount || 0), 0);
    set({ totalUnread: total });
  },

  clearSessionUnread: (sessionId) => {
    set((state) => ({
      sessions: state.sessions.map((s) => (s._id === sessionId ? { ...s, unreadCount: 0 } : s))
    }));
    get().calculateTotalUnread();
  }
}));

export default useChatStore;
