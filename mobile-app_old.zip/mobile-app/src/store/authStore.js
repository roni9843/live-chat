import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_URL } from '../config';

const useAuthStore = create((set) => ({
  user: null,
  token: null,
  isLoading: true,

  loadStoredSession: async () => {
    try {
      const token = await SecureStore.getItemAsync('userToken');
      const userStr = await AsyncStorage.getItem('userData');
      if (token && userStr) {
        set({ token, user: JSON.parse(userStr), isLoading: false });
        return true;
      }
    } catch (e) {
      console.error('Failed to load stored session:', e);
    }
    set({ isLoading: false });
    return false;
  },

  login: async (email, password) => {
    try {
      const response = await fetch(`${API_URL}/api/auth/merchant/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
      
      if (response.ok && data.token) {
        await SecureStore.setItemAsync('userToken', data.token);
        await AsyncStorage.setItem('userData', JSON.stringify(data.user || data));
        set({ token: data.token, user: data.user || data });
        return { success: true };
      } else {
        return { success: false, error: data.message || 'Login failed' };
      }
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  },

  logout: async () => {
    try {
      const token = useAuthStore.getState().token;
      const pushToken = await SecureStore.getItemAsync('pushToken');
      if (token && pushToken) {
        try {
          await fetch(`${API_URL}/api/auth/merchant/push-token/remove`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ token: pushToken })
          });
        } catch (err) {
          console.error('Failed to remove push token from backend:', err);
        }
      }
      await SecureStore.deleteItemAsync('userToken');
      await AsyncStorage.removeItem('userData');
      await SecureStore.deleteItemAsync('pushToken');
    } catch (e) {
      console.error('Failed to clear secure storage:', e);
    }
    set({ user: null, token: null });
  },

  updateUser: async (updatedUser) => {
    try {
      await AsyncStorage.setItem('userData', JSON.stringify(updatedUser));
      set({ user: updatedUser });
    } catch (e) {
      console.error('Failed to update local user cache:', e);
    }
  },

  fetchProfile: async () => {
    const { token, user } = useAuthStore.getState();
    if (!token) return;

    try {
      const response = await fetch(`${API_URL}/api/auth/merchant/profile`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        const updatedUser = { ...user, ...data };
        await AsyncStorage.setItem('userData', JSON.stringify(updatedUser));
        set({ user: updatedUser });
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  }
}));

export default useAuthStore;
