import React, { useState, useMemo, useRef, useEffect } from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity, TextInput, Image, StatusBar, Platform, Modal, Alert, ActivityIndicator, ScrollView, Linking, Animated, PanResponder, KeyboardAvoidingView, Dimensions, Keyboard } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Notifications from 'expo-notifications';
import { Audio } from 'expo-av';
import useAuthStore from '../store/authStore';
import useChatStore from '../store/chatStore';
import { API_URL } from '../config';
import { getSocket } from '../socket';

const resolveFileUrl = (url) => {
  if (!url) return '';
  if (url.startsWith('file://') || url.startsWith('content://')) {
    return url;
  }
  if (url.startsWith('http')) {
    if (url.includes('localhost:') || url.includes('127.0.0.1:')) {
      const parts = url.split('/uploads/');
      if (parts[1]) {
        return `${API_URL}/uploads/${parts[1]}`;
      }
    }
    return url;
  }
  if (url.startsWith('/')) {
    return `${API_URL}${url}`;
  }
  return `${API_URL}/${url}`;
};

export default function HomeScreen({ navigation }) {
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const fetchProfile = useAuthStore((state) => state.fetchProfile);
  const sessions = useChatStore((state) => state.sessions);
  const messages = useChatStore((state) => state.messages);
  const addMessage = useChatStore((state) => state.addMessage);
  const [activeTab, setActiveTab] = useState('active'); // 'active' or 'closed'
  const [searchQuery, setSearchQuery] = useState('');
  
  // Alarm/Ringtone states for incoming guest chats
  const [activeAlarmSession, setActiveAlarmSession] = useState(null);
  const alarmSoundRef = useRef(null);

  const startAlarm = async (session) => {
    try {
      if (alarmSoundRef.current) {
        await alarmSoundRef.current.stopAsync().catch(() => {});
        await alarmSoundRef.current.unloadAsync().catch(() => {});
        alarmSoundRef.current = null;
      }
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
        staysActiveInBackground: false,
        shouldRouteThroughReceiverIOS: false,
      }).catch(err => console.log('Audio mode error:', err));

      const ringtoneUrl = `${API_URL}/sound-effect/alarm.mp3`;
      const { sound } = await Audio.Sound.createAsync(
        { uri: ringtoneUrl },
        { shouldPlay: true, isLooping: true, volume: 1.0 }
      );
      alarmSoundRef.current = sound;
      setActiveAlarmSession(session);
    } catch (err) {
      console.log('Error starting alarm:', err);
    }
  };

  const stopAlarm = async () => {
    try {
      if (alarmSoundRef.current) {
        await alarmSoundRef.current.stopAsync().catch(() => {});
        await alarmSoundRef.current.unloadAsync().catch(() => {});
        alarmSoundRef.current = null;
      }
      setActiveAlarmSession(null);
    } catch (err) {
      console.log('Error stopping alarm:', err);
    }
  };

  useEffect(() => {
    return () => {
      if (alarmSoundRef.current) {
        alarmSoundRef.current.stopAsync().catch(() => {});
        alarmSoundRef.current.unloadAsync().catch(() => {});
      }
    };
  }, []);
  
  // Chat Head States
  const [chatHeadSessionId, setChatHeadSessionId] = useState(null);
  const [showChatHeadPopup, setShowChatHeadPopup] = useState(false);
  const [chatHeadText, setChatHeadText] = useState('');
  const [chatHeadTypingUsers, setChatHeadTypingUsers] = useState([]);
  const isChatHeadTypingRef = useRef(false);
  const chatHeadTypingTimeoutRef = useRef(null);
  const chatHeadFlatListRef = useRef(null);

  // Position and wiggle animations
  const screenWidth = Dimensions.get('window').width;
  const screenHeight = Dimensions.get('window').height;
  const pan = useRef(new Animated.ValueXY({ x: screenWidth - 76, y: 120 })).current;
  const lastOffset = useRef({ x: screenWidth - 76, y: 120 });
  const wiggleAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    pan.addListener((value) => {
      lastOffset.current = value;
    });
    return () => pan.removeAllListeners();
  }, []);

  const triggerWiggle = () => {
    Animated.sequence([
      Animated.timing(wiggleAnim, { toValue: 10, duration: 80, useNativeDriver: true }),
      Animated.timing(wiggleAnim, { toValue: -10, duration: 80, useNativeDriver: true }),
      Animated.timing(wiggleAnim, { toValue: 10, duration: 80, useNativeDriver: true }),
      Animated.timing(wiggleAnim, { toValue: -5, duration: 80, useNativeDriver: true }),
      Animated.timing(wiggleAnim, { toValue: 5, duration: 80, useNativeDriver: true }),
      Animated.timing(wiggleAnim, { toValue: 0, duration: 80, useNativeDriver: true }),
    ]).start();
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (evt, gestureState) => {
        return Math.abs(gestureState.dx) > 5 || Math.abs(gestureState.dy) > 5;
      },
      onPanResponderGrant: () => {
        pan.setOffset({
          x: lastOffset.current.x,
          y: lastOffset.current.y
        });
        pan.setValue({ x: 0, y: 0 });
      },
      onPanResponderMove: Animated.event(
        [null, { dx: pan.x, dy: pan.y }],
        { useNativeDriver: false }
      ),
      onPanResponderRelease: (e, gestureState) => {
        pan.flattenOffset();
        const finalX = lastOffset.current.x;
        const finalY = lastOffset.current.y;
        
        const isLeftHalf = finalX + 30 < screenWidth / 2;
        const snapToX = isLeftHalf ? 16 : screenWidth - 76;
        let snapToY = finalY;

        if (snapToY < 60) snapToY = 60;
        if (snapToY > screenHeight - 150) snapToY = screenHeight - 150;

        Animated.spring(pan, {
          toValue: { x: snapToX, y: snapToY },
          useNativeDriver: false,
          tension: 60,
          friction: 7,
        }).start();

        const dragDist = Math.sqrt(gestureState.dx * gestureState.dx + gestureState.dy * gestureState.dy);
        if (dragDist < 6) {
          setShowChatHeadPopup(true);
        }
      }
    })
  ).current;

  const activeChatHeadSession = useMemo(() => {
    return sessions.find((s) => s._id === chatHeadSessionId);
  }, [sessions, chatHeadSessionId]);

  const activeChatHeadMessages = useMemo(() => {
    return messages[chatHeadSessionId] || [];
  }, [messages, chatHeadSessionId]);

  const handleChatHeadInputChange = (text) => {
    setChatHeadText(text);
    const socket = getSocket();
    if (!socket || !chatHeadSessionId) return;

    if (!isChatHeadTypingRef.current && text.trim().length > 0) {
      isChatHeadTypingRef.current = true;
      socket.emit('typing_start', {
        sessionId: chatHeadSessionId,
        sender: 'merchant',
        merchantId: user?._id,
        senderName: user?.name
      });
    }

    if (chatHeadTypingTimeoutRef.current) {
      clearTimeout(chatHeadTypingTimeoutRef.current);
    }

    chatHeadTypingTimeoutRef.current = setTimeout(() => {
      if (isChatHeadTypingRef.current) {
        isChatHeadTypingRef.current = false;
        socket.emit('typing_end', {
          sessionId: chatHeadSessionId,
          sender: 'merchant',
          merchantId: user?._id
        });
      }
    }, 2000);
  };

  const handleChatHeadSend = () => {
    if (!chatHeadText.trim() || !chatHeadSessionId) return;
    const socket = getSocket();
    if (!socket) return;

    if (chatHeadTypingTimeoutRef.current) {
      clearTimeout(chatHeadTypingTimeoutRef.current);
    }
    if (isChatHeadTypingRef.current) {
      isChatHeadTypingRef.current = false;
      socket.emit('typing_end', {
        sessionId: chatHeadSessionId,
        sender: 'merchant',
        merchantId: user?._id
      });
    }

    const tempId = `temp-${Date.now()}`;
    const newMsg = {
      sessionId: chatHeadSessionId,
      sender: 'merchant',
      content: chatHeadText.trim(),
      merchantId: user?._id,
      senderId: user?._id,
      senderName: user?.name,
      tempId,
      timestamp: Date.now()
    };

    addMessage(chatHeadSessionId, newMsg);
    socket.emit('send_message', newMsg);
    setChatHeadText('');
    
    setTimeout(() => {
      chatHeadFlatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  useEffect(() => {
    const socket = getSocket();
    if (showChatHeadPopup && chatHeadSessionId && activeChatHeadMessages.length === 0) {
      if (socket) {
        socket.emit('get_chat_history', { sessionId: chatHeadSessionId });
      }
    }
    
    // Manage viewing status on socket server for chat head popup
    if (socket) {
      if (showChatHeadPopup && chatHeadSessionId) {
        socket.emit('agent_viewing_session', {
          sessionId: chatHeadSessionId,
          name: user?.name,
          profilePic: user?.profilePic,
          agentId: user?._id
        });
      } else {
        socket.emit('agent_viewing_session', { sessionId: null });
      }
    }
  }, [showChatHeadPopup, chatHeadSessionId, user]);
  
  // WhatsApp Style states
  const [isSearching, setIsSearching] = useState(false);
  const [showHomeMenu, setShowHomeMenu] = useState(false);
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [contactSearchQuery, setContactSearchQuery] = useState('');
  const [contacts, setContacts] = useState([]);
  const [isSearchingContacts, setIsSearchingContacts] = useState(false);

  // Group chat creation states
  const [showNewGroupModal, setShowNewGroupModal] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [groupSearchQuery, setGroupSearchQuery] = useState('');
  const [groupContacts, setGroupContacts] = useState([]);
  const [isSearchingGroupContacts, setIsSearchingGroupContacts] = useState(false);
  const [selectedGroupMembers, setSelectedGroupMembers] = useState([]);
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);

  // Profile settings states
  const [showProfileSettingsModal, setShowProfileSettingsModal] = useState(false);
  const [profileName, setProfileName] = useState('');
  const [profileEmail, setProfileEmail] = useState('');
  const [profileWebsite, setProfileWebsite] = useState('');
  const [profilePic, setProfilePic] = useState('');
  const [profileStatus, setProfileStatus] = useState('online');
  const [isSavingProfileSettings, setIsSavingProfileSettings] = useState(false);

  // Password change states
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Notification/Invites state
  const [invites, setInvites] = useState([]);

  const fetchInvites = async () => {
    try {
      const response = await fetch(`${API_URL}/api/auth/merchant/invites`, {
        headers: { Authorization: `Bearer ${user?.token}` }
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setInvites(data);
      }
    } catch (err) {
      console.error('Error fetching invites:', err);
    }
  };

  const handleRespondInvite = async (widgetId, status) => {
    try {
      const response = await fetch(`${API_URL}/api/auth/merchant/invites/${widgetId}/respond`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user?.token}`
        },
        body: JSON.stringify({ status })
      });
      if (response.ok) {
        setInvites(prev => prev.filter(inv => inv.widgetId !== widgetId));
        Alert.alert('Success', `Invitation ${status}ed successfully!`);
        const { fetchProfile } = useAuthStore.getState();
        if (fetchProfile) {
          await fetchProfile();
        }
      } else {
        Alert.alert('Error', 'Failed to respond to invitation.');
      }
    } catch (err) {
      console.error('Error responding to invite:', err);
      Alert.alert('Error', 'Failed to respond to invitation.');
    }
  };

  React.useEffect(() => {
    fetchInvites();
    if (fetchProfile) {
      fetchProfile();
    }
    
    let socket = getSocket();

    const handleReceiveMessage = (msg) => {
      if (msg.sessionId) {
        setChatHeadSessionId(msg.sessionId);
        triggerWiggle();

        // Alarm: trigger if message is from visitor in an unassigned session
        const currentSessions = useChatStore.getState().sessions;
        const targetSession = currentSessions.find(s => s._id === msg.sessionId);
        if (targetSession) {
          const isVisitor = !targetSession.isGroupChat && !targetSession.isDirectMessage && targetSession.widgetId !== 'group_chat' && !targetSession.groupName;
          if (isVisitor && !targetSession.assignedAgent && targetSession.status !== 'closed' && msg.sender === 'visitor') {
            startAlarm(targetSession);
          }
        }
      }
    };

    const handleNewSession = (session) => {
      const isVisitor = !session.isGroupChat && !session.isDirectMessage && session.widgetId !== 'group_chat' && !session.groupName;
      if (isVisitor && !session.assignedAgent && session.status !== 'closed') {
        startAlarm(session);
      }
    };

    const handleSessionUpdated = (session) => {
      const isVisitor = !session.isGroupChat && !session.isDirectMessage && session.widgetId !== 'group_chat' && !session.groupName;
      if (isVisitor && session.status !== 'closed') {
        if (!session.assignedAgent) {
          // Unassigned visitor session -> ring if not already ringing for this session
          if (!activeAlarmSession || activeAlarmSession._id !== session._id) {
            startAlarm(session);
          }
        } else {
          // Assigned visitor session -> stop alarm if it is currently ringing for this session
          if (activeAlarmSession && activeAlarmSession._id === session._id) {
            stopAlarm();
          }
        }
      }
    };

    const handleTypingStart = ({ sessionId: eventSessionId, senderName, senderId }) => {
      if (chatHeadSessionId && eventSessionId === chatHeadSessionId && senderId?.toString() !== user?._id?.toString()) {
        setChatHeadTypingUsers(prev => {
          if (prev.some(u => u.senderId === senderId)) return prev;
          return [...prev, { senderId, senderName }];
        });
      }
    };

    const handleTypingEnd = ({ sessionId: eventSessionId, senderId }) => {
      if (chatHeadSessionId && eventSessionId === chatHeadSessionId) {
        setChatHeadTypingUsers(prev => prev.filter(u => u.senderId !== senderId));
      }
    };

    const registerListeners = () => {
      if (socket) {
        socket.on('new_invite', fetchInvites);
        socket.on('invite_responded', fetchInvites);
        socket.on('receive_message', handleReceiveMessage);
        socket.on('new_session', handleNewSession);
        socket.on('session_updated', handleSessionUpdated);
        socket.on('typing_start', handleTypingStart);
        socket.on('typing_end', handleTypingEnd);
      }
    };
    
    registerListeners();
    const interval = setInterval(fetchInvites, 10000);
    
    return () => {
      clearInterval(interval);
      if (socket) {
        socket.off('new_invite', fetchInvites);
        socket.off('invite_responded', fetchInvites);
        socket.off('receive_message', handleReceiveMessage);
        socket.off('new_session', handleNewSession);
        socket.off('session_updated', handleSessionUpdated);
        socket.off('typing_start', handleTypingStart);
        socket.off('typing_end', handleTypingEnd);
      }
    };
  }, [user?._id, chatHeadSessionId]);

  const handleSearchContacts = async (email) => {
    setContactSearchQuery(email);
    if (!email.trim()) {
      setContacts([]);
      return;
    }
    setIsSearchingContacts(true);
    try {
      const token = useAuthStore.getState().token;
      const res = await fetch(`${API_URL}/api/auth/merchant/search?email=${encodeURIComponent(email)}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (res.ok) {
        setContacts(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearchingContacts(false);
    }
  };

  const handleSearchGroupContacts = async (email) => {
    setGroupSearchQuery(email);
    if (!email.trim()) {
      setGroupContacts([]);
      return;
    }
    setIsSearchingGroupContacts(true);
    try {
      const token = useAuthStore.getState().token;
      const res = await fetch(`${API_URL}/api/auth/merchant/search?email=${encodeURIComponent(email)}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (res.ok) {
        // Exclude current user from the list if they appear
        setGroupContacts(data.filter(c => c._id !== user?._id));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearchingGroupContacts(false);
    }
  };

  const toggleSelectGroupMember = (contact) => {
    setSelectedGroupMembers(prev => {
      const exists = prev.some(m => m._id === contact._id);
      if (exists) {
        return prev.filter(m => m._id !== contact._id);
      } else {
        return [...prev, contact];
      }
    });
  };

  const handleStartDM = async (targetUserId, targetName) => {
    try {
      const token = useAuthStore.getState().token;
      const res = await fetch(`${API_URL}/api/auth/merchant/direct-message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ targetUserId })
      });
      const data = await res.json();
      if (res.ok) {
        setShowNewChatModal(false);
        setContactSearchQuery('');
        setContacts([]);
        navigation.navigate('Chat', { sessionId: data._id, displayName: targetName });
      } else {
        Alert.alert('Error', data.message || 'Failed to start direct message');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Network error. Please try again.');
    }
  };

  const handleCreateGroup = async () => {
    if (!newGroupName.trim()) {
      Alert.alert('Error', 'Group name is required');
      return;
    }
    if (selectedGroupMembers.length === 0) {
      Alert.alert('Error', 'At least one group member must be added');
      return;
    }
    setIsCreatingGroup(true);
    try {
      const token = useAuthStore.getState().token;
      const res = await fetch(`${API_URL}/api/auth/merchant/group-chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          groupName: newGroupName.trim(),
          targetUserIds: selectedGroupMembers.map(m => m._id)
        })
      });
      const data = await res.json();
      if (res.ok) {
        setShowNewGroupModal(false);
        setNewGroupName('');
        setSelectedGroupMembers([]);
        setGroupSearchQuery('');
        setGroupContacts([]);
        navigation.navigate('Chat', { sessionId: data._id, displayName: data.groupName });
      } else {
        Alert.alert('Error', data.message || 'Failed to create group');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Network error. Please try again.');
    } finally {
      setIsCreatingGroup(false);
    }
  };

  // System Permission States
  const [cameraPermissionGranted, setCameraPermissionGranted] = useState(false);
  const [micPermissionGranted, setMicPermissionGranted] = useState(false);
  const [notifPermissionGranted, setNotifPermissionGranted] = useState(false);

  const checkPermissions = async () => {
    try {
      const cameraStatus = await ImagePicker.getCameraPermissionsAsync();
      setCameraPermissionGranted(cameraStatus.granted);

      const micStatus = await Audio.getPermissionsAsync();
      setMicPermissionGranted(micStatus.granted);

      const notifStatus = await Notifications.getPermissionsAsync();
      setNotifPermissionGranted(notifStatus.granted);
    } catch (e) {
      console.log('Error checking permissions:', e);
    }
  };

  const handleOpenProfileModal = () => {
    setProfileName(user?.name || '');
    setProfileEmail(user?.email || '');
    setProfileWebsite(user?.websiteUrl || '');
    setProfilePic(user?.profilePic || '');
    setProfileStatus(user?.status || 'online');
    setShowChangePassword(false);
    checkPermissions();
    setShowProfileSettingsModal(true);
  };

  const handleRequestNotifPermission = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    setNotifPermissionGranted(status === 'granted');
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please enable notifications in system settings.', [
        { text: 'Cancel' },
        { text: 'Settings', onPress: handleOpenAppSettings }
      ]);
    }
  };

  const handleRequestCameraPermission = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    setCameraPermissionGranted(status === 'granted');
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please enable camera access in system settings.', [
        { text: 'Cancel' },
        { text: 'Settings', onPress: handleOpenAppSettings }
      ]);
    }
  };

  const handleRequestMicPermission = async () => {
    const { status } = await Audio.requestPermissionsAsync();
    setMicPermissionGranted(status === 'granted');
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please enable microphone access in system settings.', [
        { text: 'Cancel' },
        { text: 'Settings', onPress: handleOpenAppSettings }
      ]);
    }
  };

  const handleOpenAppSettings = () => {
    Linking.openSettings().catch(() => {
      Alert.alert('Error', 'Unable to open settings. Please open device settings manually.');
    });
  };

  const handlePickProfilePic = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert('Permission Denied', 'Permission to access media library is required');
      return;
    }

    try {
      const pickerResult = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions ? ImagePicker.MediaTypeOptions.Images : ImagePicker.MediaType.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (pickerResult.canceled || !pickerResult.assets || pickerResult.assets.length === 0) {
        return;
      }

      const selectedImage = pickerResult.assets[0];
      const localUri = selectedImage.uri;

      setIsSavingProfileSettings(true);
      const token = useAuthStore.getState().token;
      const formData = new FormData();
      const filename = localUri.split('/').pop() || 'profile.jpg';
      const match = /\.(\w+)$/.exec(filename);
      const type = match ? `image/${match[1]}` : `image/jpeg`;

      formData.append('file', {
        uri: localUri,
        name: filename,
        type: type,
      });

      const response = await fetch(`${API_URL}/api/upload`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData,
      });

      const result = await response.json();
      if (result && result.success && result.fileUrl) {
        setProfilePic(result.fileUrl);
      } else {
        Alert.alert('Upload Failed', 'Failed to upload profile picture.');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'An error occurred during picture upload.');
    } finally {
      setIsSavingProfileSettings(false);
    }
  };

  const handleUpdateProfile = async () => {
    if (!profileName.trim()) {
      Alert.alert('Error', 'Name is required');
      return;
    }
    if (!profileEmail.trim()) {
      Alert.alert('Error', 'Email is required');
      return;
    }
    setIsSavingProfileSettings(true);
    try {
      const token = useAuthStore.getState().token;
      const res = await fetch(`${API_URL}/api/auth/merchant/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: profileName.trim(),
          email: profileEmail.trim(),
          websiteUrl: profileWebsite.trim(),
          profilePic: profilePic,
          status: profileStatus
        })
      });
      const data = await res.json();
      if (res.ok) {
        const updateUser = useAuthStore.getState().updateUser;
        await updateUser(data);
        Alert.alert('Success', 'Profile updated successfully!');
        setShowProfileSettingsModal(false);
      } else {
        Alert.alert('Error', data.message || 'Failed to update profile');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Network error. Please try again.');
    } finally {
      setIsSavingProfileSettings(false);
    }
  };

  const handleChangePassword = async () => {
    if (!currentPassword) {
      Alert.alert('Error', 'Current password is required');
      return;
    }
    if (!newPassword) {
      Alert.alert('Error', 'New password is required');
      return;
    }
    if (newPassword !== confirmPassword) {
      Alert.alert('Error', 'New passwords do not match');
      return;
    }
    setIsChangingPassword(true);
    try {
      const token = useAuthStore.getState().token;
      const res = await fetch(`${API_URL}/api/auth/merchant/password`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          currentPassword,
          newPassword
        })
      });
      const data = await res.json();
      if (res.ok) {
        Alert.alert('Success', 'Password changed successfully!');
        setShowChangePassword(false);
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        Alert.alert('Error', data.message || 'Failed to change password');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Network error. Please try again.');
    } finally {
      setIsChangingPassword(false);
    }
  };

  const filteredSessions = useMemo(() => {
    return sessions
      .filter((s) => {
        const matchStatus = activeTab === 'active' ? s.status !== 'closed' : s.status === 'closed';
        const matchSearch = (s.visitorName || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
                            (s.lastMessage || '').toLowerCase().includes(searchQuery.toLowerCase());
        return matchStatus && matchSearch;
      })
      .sort((a, b) => new Date(b.lastMessageAt || b.createdAt) - new Date(a.lastMessageAt || a.createdAt));
  }, [sessions, activeTab, searchQuery]);

  const onlineAgents = useChatStore((state) => state.onlineAgents || []);

  const renderSessionItem = ({ item }) => {
    const isGroup = item.isGroupChat === true || !!item.groupName || item.widgetId === 'group_chat';
    const isDM = item.isDirectMessage === true;
    
    let displayName = item.visitorName || 'Guest';
    let displayPic = item.groupImage || '';
    let isOnline = false;
    
    if (isDM && item.dmParticipants) {
      const otherUser = item.dmParticipants.find(p => p.userId?.toString() !== user?._id?.toString());
      if (otherUser) {
        displayName = otherUser.name;
        displayPic = otherUser.profilePic;
        isOnline = onlineAgents.includes(otherUser.userId?.toString());
      }
    } else if (isGroup) {
      displayName = item.groupName || item.visitorName;
    } else {
      isOnline = item.visitorStatus === 'online';
    }

    const hasUnread = item.unreadCount > 0;

    return (
      <TouchableOpacity
        style={styles.sessionCard}
        activeOpacity={0.7}
        onPress={() => navigation.navigate('Chat', { sessionId: item._id, displayName })}
      >
        <View style={styles.avatarContainer}>
          <View style={[styles.avatar, { backgroundColor: isDM ? '#53bdeb' : isGroup ? '#00a884' : '#657786' }]}>
            {displayPic ? (
              <Image source={{ uri: resolveFileUrl(displayPic) }} style={styles.avatarImg} />
            ) : (
              <Text style={styles.avatarText}>{displayName.charAt(0).toUpperCase()}</Text>
            )}
          </View>
          {isOnline && <View style={styles.onlineDot} />}
        </View>

        <View style={styles.sessionDetails}>
          <View style={styles.sessionHeaderRow}>
            <Text style={styles.visitorName} numberOfLines={1}>
              {displayName}
            </Text>
            {item.lastMessageAt ? (
              <Text style={styles.timeText}>
                {new Date(item.lastMessageAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </Text>
            ) : null}
          </View>

          <View style={styles.sessionBodyRow}>
            <View style={styles.messageContainer}>
              {isGroup ? (
                <Text style={styles.groupBadge}>Group</Text>
              ) : isDM ? (
                <Text style={styles.dmBadge}>DM</Text>
              ) : null}
              <Text style={[styles.lastMessage, hasUnread && styles.unreadMessageText]} numberOfLines={1}>
                {item.lastMessage || 'Active session'}
              </Text>
            </View>

            {hasUnread ? (
              <View style={styles.unreadBadge}>
                <Text style={styles.unreadBadgeText}>{item.unreadCount}</Text>
              </View>
            ) : null}
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const renderWidgetCard = (widget, role) => {
    let roleBg = '#00a884';
    if (role === 'Owner') roleBg = '#8b5cf6';
    else if (role === 'Admin') roleBg = '#ef4444';
    else if (role === 'Agent') roleBg = '#3b82f6';

    const widgetColor = widget.color || '#25D366';
    const statusText = widget.isActive !== false ? 'Active' : 'Inactive';
    const statusColor = widget.isActive !== false ? '#00a884' : '#8696a0';

    return (
      <View key={widget._id || widget.domain} style={styles.widgetCard}>
        <View style={styles.widgetHeaderRow}>
          <View style={styles.widgetTitleContainer}>
            <Text style={styles.widgetCompanyName} numberOfLines={1}>{widget.companyName}</Text>
            <Text style={styles.widgetDomain} numberOfLines={1}>{widget.domain}</Text>
          </View>
          <View style={[styles.roleBadge, { backgroundColor: roleBg }]}>
            <Text style={styles.roleBadgeText}>{role}</Text>
          </View>
        </View>

        <View style={styles.widgetDivider} />

        <View style={styles.widgetDetailsRow}>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Title</Text>
            <Text style={styles.detailValue} numberOfLines={1}>{widget.title || 'Chat with us'}</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Status</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
              <Text style={[styles.detailValue, { color: statusColor }]}>{statusText}</Text>
            </View>
          </View>
        </View>

        <View style={[styles.widgetDetailsRow, { marginTop: 8 }]}>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Theme Color</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={[styles.colorIndicator, { backgroundColor: widgetColor }]} />
              <Text style={styles.detailValue}>{widgetColor}</Text>
            </View>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Position</Text>
            <Text style={styles.detailValue}>{widget.position ? widget.position.toUpperCase() : 'RIGHT'}</Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <StatusBar barStyle="light-content" backgroundColor="#111b21" />
      
      {/* App Header */}
      {isSearching ? (
        <View style={styles.searchHeader}>
          <Ionicons name="search" size={20} color="#8696a0" style={styles.searchIcon} />
          <TextInput
            style={styles.headerSearchInput}
            placeholder="Search conversations..."
            placeholderTextColor="#8696a0"
            value={searchQuery}
            onChangeText={setSearchQuery}
            autoFocus
          />
          {searchQuery ? (
            <TouchableOpacity onPress={() => setSearchQuery('')} style={styles.searchClearBtn}>
              <Ionicons name="close" size={24} color="#e9edef" />
            </TouchableOpacity>
          ) : null}
        </View>
      ) : (
        <View style={styles.header}>
          <View>
            <Text style={styles.headerTitle}>Support Inbox</Text>
            <Text style={styles.headerAgentName}>{user?.name || 'Agent'} (online)</Text>
          </View>
          <View style={styles.headerRightActions}>
            <TouchableOpacity style={styles.headerActionBtn} onPress={() => setIsSearching(true)}>
              <Ionicons name="search" size={22} color="#e9edef" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.headerActionBtn} onPress={() => setShowHomeMenu(true)}>
              <Ionicons name="ellipsis-vertical" size={22} color="#e9edef" />
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Tabs */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'active' && styles.activeTabButton]}
          onPress={() => setActiveTab('active')}
        >
          <Text style={[styles.tabText, activeTab === 'active' && styles.activeTabText]}>Active</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'closed' && styles.activeTabButton]}
          onPress={() => setActiveTab('closed')}
        >
          <Text style={[styles.tabText, activeTab === 'closed' && styles.activeTabText]}>Closed</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'widgets' && styles.activeTabButton]}
          onPress={() => Linking.openURL('https://dashboard.o-chat.live/')}
        >
          <Text style={[styles.tabText, activeTab === 'widgets' && styles.activeTabText]}>Widgets</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'notifications' && styles.activeTabButton, { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }]}
          onPress={() => Linking.openURL('https://dashboard.o-chat.live/')}
        >
          <Text style={[styles.tabText, activeTab === 'notifications' && styles.activeTabText, { fontSize: 11 }]}>Notifications</Text>
          {invites.length > 0 && (
            <View style={styles.tabBadge}>
              <Text style={styles.tabBadgeText}>{invites.length}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      {/* Chat List */}
      <FlatList
        data={filteredSessions}
        renderItem={renderSessionItem}
        keyExtractor={(item) => item._id}
        contentContainerStyle={styles.listContainer}
        ListEmptyComponent={
          <View style={styles.emptyView}>
            <Text style={styles.emptyText}>No chat sessions found</Text>
          </View>
        }
      />

      {/* Floating Action Button (FAB) */}
      <TouchableOpacity 
        style={styles.fab} 
        activeOpacity={0.8}
        onPress={() => setShowNewChatModal(true)}
      >
        <Ionicons name="chatbubble-ellipses" size={24} color="#fff" />
      </TouchableOpacity>

      {/* 3-Dot Dropdown Home Menu Modal */}
      <Modal
        visible={showHomeMenu}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowHomeMenu(false)}
      >
        <TouchableOpacity 
          style={styles.dropdownOverlay} 
          activeOpacity={1} 
          onPress={() => setShowHomeMenu(false)}
        >
          <View style={[styles.dropdownMenu, { top: Platform.OS === 'ios' ? 95 : 55, right: 12 }]}>
            <TouchableOpacity 
              style={styles.dropdownItem} 
              onPress={() => {
                setShowHomeMenu(false);
                setShowNewChatModal(true);
              }}
            >
              <Ionicons name="chatbubbles-outline" size={18} color="#e9edef" style={styles.dropdownIcon} />
              <Text style={styles.dropdownText}>New DM Chat</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.dropdownItem} 
              onPress={() => {
                setShowHomeMenu(false);
                setShowNewGroupModal(true);
              }}
            >
              <Ionicons name="people-outline" size={18} color="#e9edef" style={styles.dropdownIcon} />
              <Text style={styles.dropdownText}>New Group Chat</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.dropdownItem} 
              onPress={() => {
                setShowHomeMenu(false);
                Linking.openURL('https://dashboard.o-chat.live/');
              }}
            >
              <Ionicons name="person-circle-outline" size={18} color="#e9edef" style={styles.dropdownIcon} />
              <Text style={styles.dropdownText}>Profile Settings</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={[styles.dropdownItem, { borderBottomWidth: 0 }]} 
              onPress={() => {
                setShowHomeMenu(false);
                logout();
              }}
            >
              <Ionicons name="log-out-outline" size={18} color="#f87171" style={styles.dropdownIcon} />
              <Text style={[styles.dropdownText, { color: '#f87171' }]}>Logout</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* New DM Contact Search Modal */}
      <Modal
        visible={showNewChatModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => { setShowNewChatModal(false); setContactSearchQuery(''); setContacts([]); }}
      >
        <View style={styles.newChatOverlay}>
          <View style={styles.newChatContent}>
            {/* Modal Header */}
            <View style={styles.newChatHeader}>
              <Text style={styles.newChatTitle}>New DM Chat</Text>
              <TouchableOpacity onPress={() => { setShowNewChatModal(false); setContactSearchQuery(''); setContacts([]); }}>
                <Ionicons name="close" size={24} color="#e9edef" />
              </TouchableOpacity>
            </View>

            {/* Search Input */}
            <View style={styles.newChatSearchContainer}>
              <TextInput
                style={styles.newChatSearchInput}
                placeholder="Search agent by email..."
                placeholderTextColor="#8696a0"
                value={contactSearchQuery}
                onChangeText={handleSearchContacts}
                autoCapitalize="none"
              />
            </View>

            {/* Results List */}
            {isSearchingContacts ? (
              <ActivityIndicator color="#00a884" size="large" style={{ marginTop: 20 }} />
            ) : (
              <FlatList
                data={contacts}
                keyExtractor={(item) => item._id}
                contentContainerStyle={{ paddingHorizontal: 16 }}
                ListEmptyComponent={
                  <View style={styles.newChatEmpty}>
                    <Text style={styles.newChatEmptyText}>
                      {contactSearchQuery ? 'No agents found' : 'Type email to search other agents'}
                    </Text>
                  </View>
                }
                renderItem={({ item }) => (
                  <TouchableOpacity 
                    style={styles.contactCard} 
                    onPress={() => handleStartDM(item._id, item.name)}
                  >
                    <View style={styles.contactAvatar}>
                      <Text style={styles.contactAvatarText}>{item.name.charAt(0).toUpperCase()}</Text>
                    </View>
                    <View style={styles.contactInfo}>
                      <Text style={styles.contactName}>{item.name}</Text>
                      <Text style={styles.contactEmail}>{item.email}</Text>
                    </View>
                  </TouchableOpacity>
                )}
              />
            )}
          </View>
        </View>
      </Modal>

      {/* New Group Chat Modal */}
      <Modal
        visible={showNewGroupModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => { 
          setShowNewGroupModal(false); 
          setNewGroupName(''); 
          setSelectedGroupMembers([]); 
          setGroupSearchQuery(''); 
          setGroupContacts([]); 
        }}
      >
        <View style={styles.newChatOverlay}>
          <View style={styles.newChatContent}>
            {/* Modal Header */}
            <View style={styles.newChatHeader}>
              <Text style={styles.newChatTitle}>Create Group Chat</Text>
              <TouchableOpacity onPress={() => { 
                setShowNewGroupModal(false); 
                setNewGroupName(''); 
                setSelectedGroupMembers([]); 
                setGroupSearchQuery(''); 
                setGroupContacts([]); 
              }}>
                <Ionicons name="close" size={24} color="#e9edef" />
              </TouchableOpacity>
            </View>

            <ScrollView style={{ flex: 1 }}>
              {/* Group Name Input */}
              <View style={styles.groupInputContainer}>
                <Text style={styles.groupInputLabel}>Group Name</Text>
                <TextInput
                  style={styles.newChatSearchInput}
                  placeholder="Enter group name..."
                  placeholderTextColor="#8696a0"
                  value={newGroupName}
                  onChangeText={setNewGroupName}
                />
              </View>

              {/* Selected Members Chips */}
              {selectedGroupMembers.length > 0 && (
                <View style={styles.selectedMembersContainer}>
                  <Text style={styles.groupInputLabel}>Selected Members ({selectedGroupMembers.length})</Text>
                  <View style={styles.chipsWrap}>
                    {selectedGroupMembers.map((member) => (
                      <TouchableOpacity 
                        key={member._id}
                        style={styles.memberChip}
                        onPress={() => toggleSelectGroupMember(member)}
                      >
                        <Text style={styles.memberChipText}>{member.name}</Text>
                        <Ionicons name="close-circle" size={16} color="#f87171" style={{ marginLeft: 4 }} />
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              )}

              {/* Search Member Input */}
              <View style={styles.newChatSearchContainer}>
                <Text style={styles.groupInputLabel}>Add Members</Text>
                <TextInput
                  style={styles.newChatSearchInput}
                  placeholder="Search agent by email..."
                  placeholderTextColor="#8696a0"
                  value={groupSearchQuery}
                  onChangeText={handleSearchGroupContacts}
                  autoCapitalize="none"
                />
              </View>

              {/* Search Results */}
              {isSearchingGroupContacts ? (
                <ActivityIndicator color="#00a884" size="large" style={{ marginTop: 20 }} />
              ) : (
                <View style={{ paddingHorizontal: 16 }}>
                  {groupContacts.map((item) => {
                    const isSelected = selectedGroupMembers.some(m => m._id === item._id);
                    return (
                      <TouchableOpacity 
                        key={item._id}
                        style={styles.contactCard} 
                        onPress={() => toggleSelectGroupMember(item)}
                      >
                        <View style={[styles.contactAvatar, isSelected && { backgroundColor: '#00a884' }]}>
                          {isSelected ? (
                            <Ionicons name="checkmark" size={20} color="#fff" />
                          ) : (
                            <Text style={styles.contactAvatarText}>{item.name.charAt(0).toUpperCase()}</Text>
                          )}
                        </View>
                        <View style={styles.contactInfo}>
                          <Text style={styles.contactName}>{item.name}</Text>
                          <Text style={styles.contactEmail}>{item.email}</Text>
                        </View>
                        <Ionicons 
                          name={isSelected ? "checkbox" : "square-outline"} 
                          size={22} 
                          color={isSelected ? "#00a884" : "#8696a0"} 
                        />
                      </TouchableOpacity>
                    );
                  })}
                  {!groupSearchQuery && groupContacts.length === 0 && (
                    <View style={styles.newChatEmpty}>
                      <Text style={styles.newChatEmptyText}>Type email to search agents</Text>
                    </View>
                  )}
                </View>
              )}
            </ScrollView>

            {/* Create Button Footer */}
            <View style={styles.groupModalFooter}>
              <TouchableOpacity 
                style={[
                  styles.createGroupButton, 
                  (!newGroupName.trim() || selectedGroupMembers.length === 0) && styles.createGroupButtonDisabled
                ]}
                onPress={handleCreateGroup}
                disabled={isCreatingGroup || !newGroupName.trim() || selectedGroupMembers.length === 0}
              >
                {isCreatingGroup ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.createGroupButtonText}>Create Group Chat</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Profile Settings Modal */}
      <Modal
        visible={showProfileSettingsModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowProfileSettingsModal(false)}
      >
        <View style={styles.newChatOverlay}>
          <View style={[styles.newChatContent, { height: '85%' }]}>
            {/* Modal Header */}
            <View style={styles.newChatHeader}>
              <Text style={styles.newChatTitle}>Profile Settings</Text>
              <TouchableOpacity onPress={() => setShowProfileSettingsModal(false)}>
                <Ionicons name="close" size={24} color="#e9edef" />
              </TouchableOpacity>
            </View>

            <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 30 }}>
              {/* Profile Avatar Selection Section */}
              <View style={styles.profilePicSelectorContainer}>
                <TouchableOpacity onPress={handlePickProfilePic} activeOpacity={0.8} style={styles.avatarButtonLarge}>
                  {profilePic ? (
                    <Image source={{ uri: resolveFileUrl(profilePic) }} style={styles.avatarLargeImg} />
                  ) : (
                    <View style={styles.avatarLargePlaceholder}>
                      <Text style={styles.avatarLargePlaceholderText}>{profileName.charAt(0).toUpperCase() || 'U'}</Text>
                    </View>
                  )}
                  <View style={styles.cameraIconBadge}>
                    <Ionicons name="camera" size={16} color="#fff" />
                  </View>
                </TouchableOpacity>
                <Text style={styles.changePicLabel}>Tap to change picture</Text>
              </View>

              {/* Status Picker (Online / Offline) */}
              <View style={styles.profileInputContainer}>
                <Text style={styles.groupInputLabel}>Account Status</Text>
                <View style={styles.statusButtonsWrap}>
                  <TouchableOpacity 
                    style={[styles.statusToggleBtn, profileStatus === 'online' && styles.statusToggleBtnActive]} 
                    onPress={() => setProfileStatus('online')}
                  >
                    <View style={[styles.statusDotInner, { backgroundColor: '#00a884' }]} />
                    <Text style={[styles.statusToggleText, profileStatus === 'online' && styles.statusToggleTextActive]}>Online</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.statusToggleBtn, profileStatus === 'offline' && styles.statusToggleBtnActive]} 
                    onPress={() => setProfileStatus('offline')}
                  >
                    <View style={[styles.statusDotInner, { backgroundColor: '#8696a0' }]} />
                    <Text style={[styles.statusToggleText, profileStatus === 'offline' && styles.statusToggleTextActive]}>Offline</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Input Fields */}
              <View style={styles.profileInputContainer}>
                <Text style={styles.groupInputLabel}>Name</Text>
                <TextInput
                  style={styles.newChatSearchInput}
                  value={profileName}
                  onChangeText={setProfileName}
                  placeholder="Enter your name"
                  placeholderTextColor="#8696a0"
                />
              </View>

              <View style={styles.profileInputContainer}>
                <Text style={styles.groupInputLabel}>Email</Text>
                <TextInput
                  style={[styles.newChatSearchInput, { backgroundColor: '#1d2a32', color: '#8696a0' }]}
                  value={profileEmail}
                  editable={false}
                  placeholder="Enter email address"
                  placeholderTextColor="#8696a0"
                  autoCapitalize="none"
                />
              </View>

              <View style={styles.profileInputContainer}>
                <Text style={styles.groupInputLabel}>Website URL</Text>
                <TextInput
                  style={styles.newChatSearchInput}
                  value={profileWebsite}
                  onChangeText={setProfileWebsite}
                  placeholder="e.g. example.com"
                  placeholderTextColor="#8696a0"
                  autoCapitalize="none"
                />
              </View>

              <TouchableOpacity 
                style={styles.saveProfileSettingsBtn} 
                onPress={handleUpdateProfile}
                disabled={isSavingProfileSettings}
              >
                {isSavingProfileSettings ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.saveProfileSettingsBtnText}>Save Profile Settings</Text>
                )}
              </TouchableOpacity>

              {/* App Permissions Section */}
              <View style={styles.profileInputContainer}>
                <Text style={styles.groupInputLabel}>App Permissions</Text>
                <View style={styles.permissionCard}>
                  <View style={styles.permissionRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.permissionName}>Notifications</Text>
                      <Text style={styles.permissionDesc}>Alerts, sounds and icon badges</Text>
                    </View>
                    <TouchableOpacity 
                      style={[styles.permissionBtn, notifPermissionGranted ? styles.permissionBtnGranted : styles.permissionBtnRequest]}
                      onPress={handleRequestNotifPermission}
                    >
                      <Text style={styles.permissionBtnText}>{notifPermissionGranted ? 'Enabled' : 'Enable'}</Text>
                    </TouchableOpacity>
                  </View>

                  <View style={styles.permissionRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.permissionName}>Camera</Text>
                      <Text style={styles.permissionDesc}>Required to capture and send photos</Text>
                    </View>
                    <TouchableOpacity 
                      style={[styles.permissionBtn, cameraPermissionGranted ? styles.permissionBtnGranted : styles.permissionBtnRequest]}
                      onPress={handleRequestCameraPermission}
                    >
                      <Text style={styles.permissionBtnText}>{cameraPermissionGranted ? 'Enabled' : 'Enable'}</Text>
                    </TouchableOpacity>
                  </View>

                  <View style={styles.permissionRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.permissionName}>Microphone</Text>
                      <Text style={styles.permissionDesc}>Required to record voice notes</Text>
                    </View>
                    <TouchableOpacity 
                      style={[styles.permissionBtn, micPermissionGranted ? styles.permissionBtnGranted : styles.permissionBtnRequest]}
                      onPress={handleRequestMicPermission}
                    >
                      <Text style={styles.permissionBtnText}>{micPermissionGranted ? 'Enabled' : 'Enable'}</Text>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity 
                    style={styles.openSystemSettingsBtn}
                    onPress={handleOpenAppSettings}
                  >
                    <Ionicons name="settings-outline" size={16} color="#00a884" style={{ marginRight: 6 }} />
                    <Text style={styles.openSystemSettingsText}>Open Device System Settings</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Password Change Sub-section */}
              <View style={styles.passwordAccordionContainer}>
                <TouchableOpacity 
                  style={styles.accordionHeader} 
                  onPress={() => setShowChangePassword(prev => !prev)}
                >
                  <Text style={styles.accordionTitle}>Change Password</Text>
                  <Ionicons name={showChangePassword ? "chevron-up" : "chevron-down"} size={20} color="#8696a0" />
                </TouchableOpacity>

                {showChangePassword && (
                  <View style={styles.accordionContent}>
                    <View style={styles.profileInputContainer}>
                      <Text style={styles.groupInputLabel}>Current Password</Text>
                      <TextInput
                        style={styles.newChatSearchInput}
                        value={currentPassword}
                        onChangeText={setCurrentPassword}
                        secureTextEntry
                        placeholder="Current password"
                        placeholderTextColor="#8696a0"
                      />
                    </View>

                    <View style={styles.profileInputContainer}>
                      <Text style={styles.groupInputLabel}>New Password</Text>
                      <TextInput
                        style={styles.newChatSearchInput}
                        value={newPassword}
                        onChangeText={setNewPassword}
                        secureTextEntry
                        placeholder="New password"
                        placeholderTextColor="#8696a0"
                      />
                    </View>

                    <View style={styles.profileInputContainer}>
                      <Text style={styles.groupInputLabel}>Confirm New Password</Text>
                      <TextInput
                        style={styles.newChatSearchInput}
                        value={confirmPassword}
                        onChangeText={setConfirmPassword}
                        secureTextEntry
                        placeholder="Confirm new password"
                        placeholderTextColor="#8696a0"
                      />
                    </View>

                    <TouchableOpacity 
                      style={[styles.saveProfileSettingsBtn, { backgroundColor: '#202c33', borderWidth: 1, borderColor: '#00a884', marginTop: 12 }]} 
                      onPress={handleChangePassword}
                      disabled={isChangingPassword}
                    >
                      {isChangingPassword ? (
                        <ActivityIndicator color="#00a884" />
                      ) : (
                        <Text style={[styles.saveProfileSettingsBtnText, { color: '#00a884' }]}>Change Password</Text>
                      )}
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Floating Chat Head Bubble */}
      {chatHeadSessionId && (
        <Animated.View
          style={[
            styles.chatHeadBubble,
            {
              transform: [
                { translateX: pan.x },
                { translateY: pan.y },
                {
                  rotate: wiggleAnim.interpolate({
                    inputRange: [-10, 10],
                    outputRange: ['-10deg', '10deg'],
                  }),
                },
              ],
            },
          ]}
          {...panResponder.panHandlers}
        >
          <TouchableOpacity
            style={styles.chatHeadTouch}
            activeOpacity={0.9}
            onLongPress={() => {
              Alert.alert(
                'Dismiss Chat Head',
                'Remove this floating chat bubble?',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Remove', style: 'destructive', onPress: () => setChatHeadSessionId(null) }
                ]
              );
            }}
          >
            {activeChatHeadSession?.groupImage || activeChatHeadSession?.dmParticipants ? (
              <Image
                source={{
                  uri: resolveFileUrl(
                    activeChatHeadSession.isDirectMessage
                      ? activeChatHeadSession.dmParticipants.find(p => p.userId?.toString() !== user?._id?.toString())?.profilePic
                      : activeChatHeadSession.groupImage
                  )
                }}
                style={styles.chatHeadImg}
              />
            ) : (
              <View style={styles.chatHeadPlaceholder}>
                <Text style={styles.chatHeadLetter}>
                  {(activeChatHeadSession?.visitorName || activeChatHeadSession?.groupName || 'Guest').charAt(0).toUpperCase()}
                </Text>
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.chatHeadCloseBtn}
            onPress={() => setChatHeadSessionId(null)}
          >
            <Ionicons name="close-circle" size={18} color="#f87171" />
          </TouchableOpacity>
        </Animated.View>
      )}

      {/* Messenger-style Popup Chat Modal */}
      <Modal
        visible={showChatHeadPopup}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowChatHeadPopup(false)}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.popupOverlay}
        >
          <TouchableOpacity
            style={styles.popupBackdrop}
            activeOpacity={1}
            onPress={() => setShowChatHeadPopup(false)}
          />
          <View style={styles.popupChatContainer}>
            {/* Header */}
            <View style={styles.popupHeader}>
              <View style={styles.popupHeaderTitleContainer}>
                <Text style={styles.popupHeaderTitle} numberOfLines={1}>
                  {activeChatHeadSession?.visitorName || activeChatHeadSession?.groupName || 'Guest'}
                </Text>
                <Text style={styles.popupHeaderSubtitle}>
                  {chatHeadTypingUsers.length > 0
                    ? 'typing...'
                    : activeChatHeadSession?.visitorStatus === 'online' ? 'online' : 'offline'}
                </Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <TouchableOpacity
                  onPress={() => {
                    setShowChatHeadPopup(false);
                    navigation.navigate('Chat', {
                      sessionId: chatHeadSessionId,
                      displayName: activeChatHeadSession?.visitorName || activeChatHeadSession?.groupName || 'Guest'
                    });
                  }}
                  style={styles.popupActionBtn}
                >
                  <Ionicons name="open-outline" size={22} color="#e9edef" />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setShowChatHeadPopup(false)}
                  style={styles.popupActionBtn}
                >
                  <Ionicons name="close" size={24} color="#e9edef" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Message List */}
            <FlatList
              ref={chatHeadFlatListRef}
              data={activeChatHeadMessages}
              keyExtractor={(item, index) => item._id || item.tempId || index.toString()}
              contentContainerStyle={styles.popupMessageList}
              onContentSizeChange={() => chatHeadFlatListRef.current?.scrollToEnd({ animated: true })}
              onLayout={() => chatHeadFlatListRef.current?.scrollToEnd({ animated: true })}
              renderItem={({ item }) => {
                const isOut = item.sender === 'merchant' && (!item.senderId || item.senderId.toString() === user?._id?.toString());
                return (
                  <View style={[styles.popupMessageRow, isOut ? styles.popupMessageOut : styles.popupMessageIn]}>
                    <View style={[styles.popupBubble, isOut ? styles.popupBubbleOut : styles.popupBubbleIn]}>
                      <Text style={styles.popupMessageText}>{item.content}</Text>
                      <Text style={styles.popupMessageTime}>
                        {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </Text>
                    </View>
                  </View>
                );
              }}
              ListEmptyComponent={
                <View style={styles.popupEmptyView}>
                  <Text style={styles.popupEmptyText}>No messages yet</Text>
                </View>
              }
            />

            {/* Input Bar */}
            <View style={styles.popupInputBar}>
              <TextInput
                style={styles.popupInput}
                placeholder="Type a message..."
                placeholderTextColor="#8696a0"
                value={chatHeadText}
                onChangeText={handleChatHeadInputChange}
              />
              <TouchableOpacity
                style={[styles.popupSendBtn, !chatHeadText.trim() && styles.popupSendBtnDisabled]}
                onPress={handleChatHeadSend}
                disabled={!chatHeadText.trim()}
              >
                <Ionicons name="send" size={20} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Incoming Call/Chat Alarm Modal */}
      {activeAlarmSession && (
        <Modal
          visible={!!activeAlarmSession}
          transparent={true}
          animationType="fade"
          onRequestClose={stopAlarm}
        >
          <View style={styles.alarmOverlay}>
            <View style={styles.alarmContent}>
              <View style={styles.alarmHeader}>
                <Ionicons name="notifications-circle-outline" size={60} color="#00a884" style={{ marginBottom: 12 }} />
                <Text style={styles.alarmTitle}>Incoming Guest Chat!</Text>
                <Text style={styles.alarmSubtitle}>A new client is waiting for support.</Text>
              </View>
              
              <View style={styles.alarmDetailsCard}>
                <Text style={styles.alarmClientName}>{activeAlarmSession.visitorName || 'Guest Visitor'}</Text>
                {activeAlarmSession.visitorEmail ? (
                  <Text style={styles.alarmClientInfo}>{activeAlarmSession.visitorEmail}</Text>
                ) : null}
                <Text style={styles.alarmClientDomain}>Origin: {activeAlarmSession.visitorDomain || 'Website'}</Text>
              </View>

              <View style={styles.alarmActionRow}>
                <TouchableOpacity 
                  style={[styles.alarmButton, styles.alarmButtonReject]} 
                  onPress={stopAlarm}
                >
                  <Ionicons name="close-circle" size={18} color="#fff" style={{ marginRight: 6 }} />
                  <Text style={styles.alarmButtonText}>Ignore</Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  style={[styles.alarmButton, styles.alarmButtonAccept]} 
                  onPress={() => {
                    const sessionToJoin = activeAlarmSession;
                    stopAlarm();
                    const socket = getSocket();
                    if (socket) {
                      socket.emit('join_session', {
                        sessionId: sessionToJoin._id,
                        agentId: user._id,
                        agentName: user.name,
                        merchantId: sessionToJoin.merchantId
                      });
                    }
                    navigation.navigate('Chat', { 
                      sessionId: sessionToJoin._id, 
                      displayName: sessionToJoin.visitorName || 'Guest' 
                    });
                  }}
                >
                  <Ionicons name="checkmark-circle" size={18} color="#fff" style={{ marginRight: 6 }} />
                  <Text style={styles.alarmButtonText}>Join Chat</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111b21',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 16,
    backgroundColor: '#202c33',
    borderBottomWidth: 1,
    borderColor: '#2a3942',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#e9edef',
  },
  headerAgentName: {
    fontSize: 12,
    color: '#00a884',
    fontWeight: '500',
    marginTop: 2,
  },
  headerRightActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerActionBtn: {
    padding: 8,
    marginLeft: 10,
  },
  searchHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    backgroundColor: '#202c33',
    height: Platform.OS === 'ios' ? 70 : 60,
    borderBottomWidth: 1,
    borderColor: '#2a3942',
  },
  searchBackBtn: {
    padding: 8,
  },
  headerSearchInput: {
    flex: 1,
    color: '#e9edef',
    fontSize: 16,
    paddingHorizontal: 12,
  },
  searchClearBtn: {
    padding: 8,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#111b21',
    borderBottomWidth: 1,
    borderColor: '#202c33',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
    borderBottomWidth: 3,
    borderColor: 'transparent',
  },
  activeTabButton: {
    borderColor: '#00a884',
  },
  tabText: {
    color: '#8696a0',
    fontSize: 14,
    fontWeight: 'bold',
  },
  activeTabText: {
    color: '#00a884',
  },
  listContainer: {
    paddingBottom: 90,
  },
  sessionCard: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderColor: '#202c33',
    alignItems: 'center',
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 15,
  },
  onlineDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 13,
    height: 13,
    borderRadius: 6.5,
    backgroundColor: '#00a884',
    borderWidth: 2,
    borderColor: '#111b21',
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  avatarImg: {
    width: 50,
    height: 50,
    borderRadius: 25,
    overflow: 'hidden',
  },
  avatarText: {
    color: '#ffffff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  sessionDetails: {
    flex: 1,
  },
  sessionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  visitorName: {
    color: '#e9edef',
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
    marginRight: 10,
  },
  timeText: {
    color: '#8696a0',
    fontSize: 12,
  },
  sessionBodyRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  messageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  groupBadge: {
    backgroundColor: 'rgba(0, 168, 132, 0.15)',
    color: '#00a884',
    fontSize: 10,
    fontWeight: 'bold',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 4,
    marginRight: 6,
  },
  dmBadge: {
    backgroundColor: 'rgba(83, 189, 235, 0.15)',
    color: '#53bdeb',
    fontSize: 10,
    fontWeight: 'bold',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 4,
    marginRight: 6,
  },
  lastMessage: {
    color: '#8696a0',
    fontSize: 14,
    flex: 1,
  },
  unreadMessageText: {
    color: '#e9edef',
    fontWeight: '500',
  },
  unreadBadge: {
    backgroundColor: '#00a884',
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    paddingHorizontal: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  unreadBadgeText: {
    color: '#111b21',
    fontSize: 11,
    fontWeight: 'bold',
  },
  emptyView: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100,
  },
  emptyText: {
    color: '#8696a0',
    fontSize: 14,
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    backgroundColor: '#00a884',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 8,
  },
  dropdownOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  dropdownMenu: {
    position: 'absolute',
    backgroundColor: '#202c33',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#2a3942',
    paddingVertical: 4,
    minWidth: 160,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 8,
  },
  dropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderColor: 'rgba(134, 150, 160, 0.1)',
  },
  dropdownIcon: {
    marginRight: 10,
  },
  dropdownText: {
    color: '#e9edef',
    fontSize: 14,
    fontWeight: '500',
  },
  newChatOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.75)',
    justifyContent: 'flex-end',
  },
  newChatContent: {
    backgroundColor: '#111b21',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    height: '80%',
  },
  newChatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderColor: '#222e35',
  },
  newChatTitle: {
    color: '#e9edef',
    fontSize: 18,
    fontWeight: 'bold',
  },
  newChatSearchContainer: {
    padding: 16,
  },
  newChatSearchInput: {
    backgroundColor: '#2a3942',
    color: '#e9edef',
    borderRadius: 8,
    padding: 12,
    fontSize: 15,
    borderWidth: 1,
    borderColor: '#202c33',
  },
  newChatEmpty: {
    alignItems: 'center',
    paddingTop: 40,
  },
  newChatEmptyText: {
    color: '#8696a0',
    fontSize: 14,
  },
  contactCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderColor: '#202c33',
  },
  contactAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#00a884',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  contactAvatarText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  contactInfo: {
    flex: 1,
  },
  contactName: {
    color: '#e9edef',
    fontSize: 15,
    fontWeight: 'bold',
  },
  contactEmail: {
    color: '#8696a0',
    fontSize: 12,
    marginTop: 2,
  },
  groupInputContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  groupInputLabel: {
    color: '#8696a0',
    fontSize: 13,
    fontWeight: 'bold',
    marginBottom: 6,
  },
  selectedMembersContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  chipsWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  memberChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#202c33',
    borderColor: '#2a3942',
    borderWidth: 1,
    borderRadius: 16,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  memberChipText: {
    color: '#e9edef',
    fontSize: 13,
  },
  groupModalFooter: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#222e35',
    backgroundColor: '#111b21',
  },
  createGroupButton: {
    backgroundColor: '#00a884',
    borderRadius: 8,
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  createGroupButtonDisabled: {
    backgroundColor: '#202c33',
    opacity: 0.5,
  },
  createGroupButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
  },
  profilePicSelectorContainer: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 16,
  },
  avatarButtonLarge: {
    position: 'relative',
    width: 90,
    height: 90,
    borderRadius: 45,
    elevation: 4,
    overflow: 'hidden',
  },
  avatarLargeImg: {
    width: 90,
    height: 90,
    borderRadius: 45,
    overflow: 'hidden',
  },
  avatarLargePlaceholder: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: '#00a884',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  avatarLargePlaceholderText: {
    fontSize: 36,
    color: '#fff',
    fontWeight: 'bold',
  },
  cameraIconBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#005f4b',
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#111b21',
  },
  changePicLabel: {
    color: '#8696a0',
    fontSize: 12,
    marginTop: 8,
  },
  profileInputContainer: {
    paddingHorizontal: 20,
    marginTop: 16,
  },
  statusButtonsWrap: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 4,
  },
  statusToggleBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#202c33',
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  statusToggleBtnActive: {
    borderColor: '#00a884',
    backgroundColor: 'rgba(0, 168, 132, 0.08)',
  },
  statusDotInner: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  statusToggleText: {
    color: '#8696a0',
    fontSize: 14,
    fontWeight: '600',
  },
  statusToggleTextActive: {
    color: '#00a884',
  },
  saveProfileSettingsBtn: {
    backgroundColor: '#00a884',
    marginHorizontal: 20,
    marginTop: 24,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  saveProfileSettingsBtnText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
  },
  passwordAccordionContainer: {
    marginTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#222e35',
    paddingTop: 10,
  },
  accordionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  accordionTitle: {
    color: '#e9edef',
    fontSize: 16,
    fontWeight: 'bold',
  },
  accordionContent: {
    paddingBottom: 20,
  },
  widgetsScrollContainer: {
    flex: 1,
    backgroundColor: '#111b21',
  },
  widgetsContentContainer: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 40,
  },
  widgetsBanner: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0, 168, 132, 0.08)',
    borderColor: '#00a884',
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  widgetsBannerTitle: {
    color: '#00a884',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  widgetsBannerText: {
    color: '#8696a0',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 8,
  },
  widgetsBannerLink: {
    color: '#53bdeb',
    fontSize: 14,
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
  widgetsSectionHeader: {
    color: '#e9edef',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    marginTop: 10,
  },
  noWidgetsCard: {
    backgroundColor: '#202c33',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
    borderColor: '#2a3942',
    borderWidth: 1,
  },
  noWidgetsText: {
    color: '#8696a0',
    fontSize: 14,
  },
  widgetCard: {
    backgroundColor: '#202c33',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderColor: '#2a3942',
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  widgetHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  widgetTitleContainer: {
    flex: 1,
    marginRight: 12,
  },
  widgetCompanyName: {
    color: '#e9edef',
    fontSize: 16,
    fontWeight: 'bold',
  },
  widgetDomain: {
    color: '#8696a0',
    fontSize: 12,
    marginTop: 2,
  },
  roleBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  roleBadgeText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: 'bold',
  },
  widgetDivider: {
    height: 1,
    backgroundColor: '#2a3942',
    marginVertical: 12,
  },
  widgetDetailsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  detailItem: {
    flex: 1,
  },
  detailLabel: {
    color: '#8696a0',
    fontSize: 11,
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  detailValue: {
    color: '#e9edef',
    fontSize: 13,
    fontWeight: '500',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  colorIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 6,
    borderWidth: 1,
    borderColor: '#fff',
  },
  tabBadge: {
    backgroundColor: '#e53e3e',
    borderRadius: 10,
    width: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 6,
  },
  tabBadgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  inviteActionBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
  },
  inviteActionText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: 'bold',
  },
  // Chat Head & Popup Styles
  chatHeadBubble: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#202c33',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  chatHeadTouch: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30,
    overflow: 'hidden',
  },
  chatHeadImg: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  chatHeadPlaceholder: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#00a884',
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatHeadLetter: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  chatHeadCloseBtn: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#202c33',
    borderRadius: 9,
    padding: 1,
  },
  popupOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  popupBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  popupChatContainer: {
    backgroundColor: '#111b21',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    height: '75%',
    width: '100%',
    elevation: 20,
  },
  popupHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderColor: '#222e35',
    backgroundColor: '#202c33',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  popupHeaderTitleContainer: {
    flex: 1,
    marginRight: 10,
  },
  popupHeaderTitle: {
    color: '#e9edef',
    fontSize: 18,
    fontWeight: 'bold',
  },
  popupHeaderSubtitle: {
    color: '#00a884',
    fontSize: 12,
    marginTop: 2,
  },
  popupActionBtn: {
    padding: 6,
  },
  popupMessageList: {
    padding: 16,
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  popupMessageRow: {
    flexDirection: 'row',
    marginBottom: 10,
    width: '100%',
  },
  popupMessageOut: {
    justifyContent: 'flex-end',
  },
  popupMessageIn: {
    justifyContent: 'flex-start',
  },
  popupBubble: {
    maxWidth: '75%',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  popupBubbleOut: {
    backgroundColor: '#005c4b',
    borderBottomRightRadius: 2,
  },
  popupBubbleIn: {
    backgroundColor: '#202c33',
    borderBottomLeftRadius: 2,
  },
  popupMessageText: {
    color: '#e9edef',
    fontSize: 15,
  },
  popupMessageTime: {
    color: 'rgba(233, 237, 239, 0.6)',
    fontSize: 10,
    alignSelf: 'flex-end',
    marginTop: 4,
  },
  popupEmptyView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  popupEmptyText: {
    color: '#8696a0',
    fontSize: 14,
  },
  popupInputBar: {
    flexDirection: 'row',
    padding: 12,
    backgroundColor: '#202c33',
    alignItems: 'center',
  },
  popupInput: {
    flex: 1,
    backgroundColor: '#2a3942',
    color: '#e9edef',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    fontSize: 15,
    marginRight: 10,
  },
  popupSendBtn: {
    backgroundColor: '#00a884',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  popupSendBtnDisabled: {
    backgroundColor: '#202c33',
    opacity: 0.5,
  },
  // Permission settings styles
  permissionCard: {
    backgroundColor: '#202c33',
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: '#2a3942',
    marginTop: 4,
  },
  permissionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#2a3942',
  },
  permissionName: {
    color: '#e9edef',
    fontSize: 14,
    fontWeight: 'bold',
  },
  permissionDesc: {
    color: '#8696a0',
    fontSize: 11,
    marginTop: 2,
    paddingRight: 10,
  },
  permissionBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 14,
    minWidth: 70,
    alignItems: 'center',
  },
  permissionBtnRequest: {
    backgroundColor: '#00a884',
  },
  permissionBtnGranted: {
    backgroundColor: '#3b4a54',
  },
  permissionBtnText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  openSystemSettingsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 12,
    paddingBottom: 4,
  },
  openSystemSettingsText: {
    color: '#00a884',
    fontSize: 13,
    fontWeight: 'bold',
  },
  // Alarm Ringing Modal Styles
  alarmOverlay: {
    flex: 1,
    backgroundColor: 'rgba(11, 20, 26, 0.95)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alarmContent: {
    width: '85%',
    backgroundColor: '#1f2c34',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#00a884',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
  alarmHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  alarmTitle: {
    color: '#e9edef',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  alarmSubtitle: {
    color: '#8696a0',
    fontSize: 13,
  },
  alarmDetailsCard: {
    backgroundColor: '#202c33',
    width: '100%',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(134, 150, 160, 0.1)',
  },
  alarmClientName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  alarmClientInfo: {
    color: '#8696a0',
    fontSize: 13,
    marginBottom: 2,
  },
  alarmClientDomain: {
    color: '#00a884',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 4,
  },
  alarmActionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  alarmButton: {
    flex: 1,
    height: 46,
    borderRadius: 23,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 6,
  },
  alarmButtonReject: {
    backgroundColor: '#ef4444',
  },
  alarmButtonAccept: {
    backgroundColor: '#00a884',
  },
  alarmButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
  },
});
