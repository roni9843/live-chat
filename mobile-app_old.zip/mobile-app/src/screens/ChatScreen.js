import React, { useState, useEffect, useRef, useLayoutEffect } from 'react';
import { StyleSheet, Text, View, FlatList, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, ActivityIndicator, Modal, ScrollView, Alert, Image, Animated, Clipboard, PanResponder, Keyboard, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useHeaderHeight } from '@react-navigation/elements';
import { useIsFocused } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Audio } from 'expo-av';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import useAuthStore from '../store/authStore';
import useChatStore from '../store/chatStore';
import { getSocket } from '../socket';
import { playSound } from '../utils/sound';
import { API_URL } from '../config';

const EMPTY_ARRAY = [];

const POPULAR_EMOJIS = [
  '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌',
  '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓',
  '😎', '🥸', '🤩', '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣', '😖',
  '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬', '🤯', '😳', '🥵', '🥶', '😱',
  '😨', '😰', '😥', '😓', '🤗', '🤔', '🫣', '🤭', '🤫', '🫡', '✍️', '👍', '👎', '👊',
  '✊', '🤛', '🤜', '🤞', '✌️', '🤟', '🤘', '👌', '🤌', '🤏', '👈', '👉', '👆', '👇',
  '☝️', '✋', '🤚', '🖐️', '🖖', '👋', '🤙', '💪', '🦾', '🖕', '🙏', '🤲', '🤝', '👏',
  '🙌', '🎈', '🎉', '❤️', '🔥', '✨', '⭐'
];

const resolveFileUrl = (url) => {
  if (!url) return '';
  if (url.startsWith('file://') || url.startsWith('content://')) {
    return url;
  }
  if (url.startsWith('http')) {
    if (url.includes('localhost:') || url.includes('127.0.0.1:')) {
      const parts = url.split('/uploads/');
      if (parts[1]) {
        return `${API_URL}/uploads/${parts[1]}`;
      }
    }
    return url;
  }
  if (url.startsWith('/')) {
    return `${API_URL}${url}`;
  }
  return `${API_URL}/${url}`;
};

function TypingIndicator() {
  const dot1 = useRef(new Animated.Value(0.3)).current;
  const dot2 = useRef(new Animated.Value(0.3)).current;
  const dot3 = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    const animateDot = (dot, delay) => {
      return Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(dot, {
            toValue: 1,
            duration: 450,
            useNativeDriver: true,
          }),
          Animated.timing(dot, {
            toValue: 0.3,
            duration: 450,
            useNativeDriver: true,
          }),
        ])
      );
    };

    const anim1 = animateDot(dot1, 0);
    const anim2 = animateDot(dot2, 150);
    const anim3 = animateDot(dot3, 300);

    anim1.start();
    anim2.start();
    anim3.start();

    return () => {
      anim1.stop();
      anim2.stop();
      anim3.stop();
    };
  }, [dot1, dot2, dot3]);

  return (
    <View style={styles.typingIndicatorContainer}>
      <Animated.View style={[styles.typingDot, { transform: [{ scale: dot1 }], opacity: dot1 }]} />
      <Animated.View style={[styles.typingDot, { transform: [{ scale: dot2 }], opacity: dot2 }]} />
      <Animated.View style={[styles.typingDot, { transform: [{ scale: dot3 }], opacity: dot3 }]} />
    </View>
  );
}

function SwipeableMessageBubble({ children, onReply, themeColor = '#00a884' }) {
  const translateX = useRef(new Animated.Value(0)).current;

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => false,
      onStartShouldSetPanResponderCapture: () => false,
      onMoveShouldSetPanResponder: (evt, gestureState) => {
        // Return true if swipe to right is significant and horizontal movement dominates
        return gestureState.dx > 10 && Math.abs(gestureState.dx) > Math.abs(gestureState.dy);
      },
      onMoveShouldSetPanResponderCapture: (evt, gestureState) => {
        // Intercept touch movements that are swipes to the right
        return gestureState.dx > 10 && Math.abs(gestureState.dx) > Math.abs(gestureState.dy);
      },
      onPanResponderMove: (evt, gestureState) => {
        if (gestureState.dx > 0) {
          translateX.setValue(Math.min(gestureState.dx, 60));
        }
      },
      onPanResponderRelease: (evt, gestureState) => {
        if (gestureState.dx > 40) {
          onReply();
        }
        Animated.spring(translateX, {
          toValue: 0,
          tension: 50,
          friction: 6,
          useNativeDriver: true,
        }).start();
      },
      onPanResponderTerminate: () => {
        Animated.spring(translateX, {
          toValue: 0,
          tension: 50,
          friction: 6,
          useNativeDriver: true,
        }).start();
      }
    })
  ).current;

  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', width: '100%', position: 'relative' }}>
      <Animated.View
        style={{
          transform: [{ translateX }],
          flex: 1,
        }}
        {...panResponder.panHandlers}
      >
        {children}
      </Animated.View>
      <Animated.View
        style={{
          position: 'absolute',
          left: 10,
          opacity: translateX.interpolate({
            inputRange: [0, 30],
            outputRange: [0, 1],
            extrapolate: 'clamp',
          }),
          transform: [
            {
              scale: translateX.interpolate({
                inputRange: [0, 30],
                outputRange: [0.5, 1],
                extrapolate: 'clamp',
              }),
            },
          ],
        }}
      >
        <Ionicons name="arrow-undo-circle" size={24} color={themeColor} />
      </Animated.View>
    </View>
  );
}

function AudioPlayerBubble({ fileUrl, isOut, themeColor = '#00a884' }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [sound, setSound] = useState(null);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const resolvedUrl = React.useMemo(() => {
    return resolveFileUrl(fileUrl);
  }, [fileUrl]);

  // Waveform heights derived from the url hash matching web logic
  const waveform = React.useMemo(() => {
    const hash = resolvedUrl.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const count = 28;
    const heights = [];
    for (let i = 0; i < count; i++) {
      const envelope = Math.sin(Math.PI * (i + 0.5) / count);
      const randomFactor = 0.3 + 0.7 * Math.abs(Math.sin(hash * (i + 1) * 456.789));
      const h = 4 + Math.floor(envelope * randomFactor * 22);
      heights.push(h);
    }
    return heights;
  }, [resolvedUrl]);

  useEffect(() => {
    return () => {
      if (sound) {
        sound.unloadAsync().catch(() => {});
      }
    };
  }, [sound]);

  const onPlaybackStatusUpdate = (status) => {
    if (status.isLoaded) {
      setPosition(status.positionMillis);
      setDuration(status.durationMillis || 0);
      setIsPlaying(status.isPlaying);
      if (status.didJustFinish) {
        setPosition(0);
        setIsPlaying(false);
        sound?.setPositionAsync(0).catch(() => {});
      }
    }
  };

  const handlePlayPause = async () => {
    try {
      if (sound) {
        if (isPlaying) {
          await sound.pauseAsync();
        } else {
          await sound.playAsync();
        }
      } else {
        setIsLoading(true);
        // Configure audio mode
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: false,
          playsInSilentModeIOS: true,
          staysActiveInBackground: false,
          shouldRouteThroughReceiverIOS: false,
        }).catch(err => Log.e("Audio", "Audio mode error: " + err.message));

        const { sound: newSound } = await Audio.Sound.createAsync(
          { uri: resolvedUrl },
          { shouldPlay: true },
          onPlaybackStatusUpdate
        );
        setSound(newSound);
      }
    } catch (error) {
      console.log('Error playing sound', error);
      Alert.alert('Error', 'Could not play voice note');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBarPress = async (index) => {
    if (!sound || duration === 0) return;
    const seekPercent = index / waveform.length;
    const newPosition = seekPercent * duration;
    await sound.setPositionAsync(newPosition).catch(() => {});
    setPosition(newPosition);
  };

  const formatTime = (millis) => {
    if (isNaN(millis) || millis <= 0) return '0:00';
    const totalSeconds = Math.floor(millis / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  const progress = duration > 0 ? position / duration : 0;

  return (
    <View style={[styles.audioBubbleContainer, isOut ? styles.audioOut : styles.audioIn]}>
      <TouchableOpacity 
        style={[styles.audioPlayButton, { backgroundColor: isOut ? 'rgba(255,255,255,0.15)' : `${themeColor}24` }]} 
        onPress={handlePlayPause}
        disabled={isLoading}
      >
        {isLoading ? (
          <ActivityIndicator size="small" color={isOut ? "#e9edef" : themeColor} />
        ) : (
          <Ionicons 
            name={isPlaying ? "pause" : "play"} 
            size={20} 
            color={isOut ? "#e9edef" : themeColor} 
          />
        )}
      </TouchableOpacity>
      
      <View style={styles.audioProgressContainer}>
        {/* Waveform Visualizer */}
        <View style={styles.waveformContainer}>
          {waveform.map((height, idx) => {
            const isActive = (idx / waveform.length) <= progress;
            return (
              <TouchableOpacity
                key={idx}
                onPress={() => handleBarPress(idx)}
                activeOpacity={0.7}
                style={[
                  styles.waveformBar,
                  {
                    height: height,
                    backgroundColor: isActive 
                      ? (isOut ? '#e9edef' : themeColor) 
                      : 'rgba(134, 150, 160, 0.4)',
                  }
                ]}
              />
            );
          })}
        </View>
        <View style={styles.audioTimeRow}>
          <Text style={styles.audioTimeText}>{formatTime(position)} / {formatTime(duration || 0)}</Text>
        </View>
      </View>
      <Ionicons name="mic" size={18} color={isOut ? "rgba(233, 237, 239, 0.6)" : "#8696a0"} style={{ marginLeft: 6 }} />
    </View>
  );
}

export default function ChatScreen({ route, navigation }) {
  const { sessionId, displayName } = route.params;
  const user = useAuthStore((state) => state.user);
  const token = useAuthStore((state) => state.token);
  const socket = getSocket();
  const headerHeight = useHeaderHeight();
  const isFocused = useIsFocused();

  const sessions = useChatStore((state) => state.sessions);
  const messages = useChatStore((state) => state.messages[sessionId] || EMPTY_ARRAY);
  const hasMore = useChatStore((state) => state.hasMore[sessionId] !== false);
  const onlineAgents = useChatStore((state) => state.onlineAgents || EMPTY_ARRAY);
  const clearSessionUnread = useChatStore((state) => state.clearSessionUnread);
  const setActiveSessionId = useChatStore((state) => state.setActiveSessionId);
  const prependMessages = useChatStore((state) => useChatStore.getState().prependMessages);

  const [inputMessage, setInputMessage] = useState('');
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [modalTab, setModalTab] = useState('info'); // 'info' or 'settings'
  const [typingUsers, setTypingUsers] = useState([]);
  const [editingMessage, setEditingMessage] = useState(null);
  const [replyingMessage, setReplyingMessage] = useState(null);
  const [showOptionsSheet, setShowOptionsSheet] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [highlightedMessageId, setHighlightedMessageId] = useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  
  // Voice recording states
  const [recording, setRecording] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const recordingTimerRef = useRef(null);
  const recordingDotOpacity = useRef(new Animated.Value(1)).current;
  const recordingDotAnimation = useRef(null);
  const [meteringHistory, setMeteringHistory] = useState([4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]);
  
  const typingTimeoutRef = useRef(null);
  const isTypingRef = useRef(false);
  
  // Group member editing states
  const [nickname, setNickname] = useState('');
  const [designation, setDesignation] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  // Group settings editing states (Admin only)
  const [grpName, setGrpName] = useState('');
  const [grpImage, setGrpImage] = useState('');
  const [isSavingGroupSettings, setIsSavingGroupSettings] = useState(false);
  const [deletePassword, setDeletePassword] = useState('');

  // Member management states (Admin only)
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [addMemberQuery, setAddMemberQuery] = useState('');
  const [addMemberContacts, setAddMemberContacts] = useState([]);
  const [isSearchingAddMember, setIsSearchingAddMember] = useState(false);
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [selectedMemberForActions, setSelectedMemberForActions] = useState(null);
  const [showMemberActionsModal, setShowMemberActionsModal] = useState(false);

  const listRef = useRef(null);

  const activeSession = sessions.find((s) => s._id === sessionId);
  const activeWidget = user?.widgets?.find(w => w._id === activeSession?.widgetId) ||
                       user?.sharedWidgets?.find(w => w._id === activeSession?.widgetId);
  const themeColor = activeWidget?.color || '#00a884';
  const isGroup = activeSession?.isGroupChat === true || !!activeSession?.groupName || activeSession?.widgetId === 'group_chat';
  const isDM = activeSession?.isDirectMessage === true;

  const groupMemberObj = activeSession?.dmParticipants?.find(p => p.userId?.toString() === user?._id?.toString());
  const isGroupAdmin = groupMemberObj?.role === 'admin';

  // Initialize self nickname and designation in modal
  useEffect(() => {
    if (activeSession && activeSession.dmParticipants) {
      const myMemberObj = activeSession.dmParticipants.find(p => p.userId?.toString() === user?._id?.toString());
      if (myMemberObj) {
        setNickname(myMemberObj.nickname || user.name || '');
        setDesignation(myMemberObj.designation || 'Agent');
      }
    }
    if (activeSession) {
      setGrpName(activeSession.groupName || activeSession.visitorName || '');
      setGrpImage(activeSession.groupImage || '');
    }
  }, [activeSession, user]);

  // Clickable header config & 3-dot Ellipsis icon
  useLayoutEffect(() => {
    const isSomeoneTyping = typingUsers.length > 0;
    let subtitleText = isGroup ? `${activeSession?.dmParticipants?.length || 0} members` : (activeSession?.visitorStatus === 'offline' ? 'offline' : 'online');
    
    if (isSomeoneTyping) {
      if (isGroup) {
        subtitleText = `${typingUsers[0].senderName} is typing...`;
      } else {
        subtitleText = 'typing...';
      }
    }

    let displayPic = activeSession?.groupImage || '';
    if (isDM && activeSession?.dmParticipants) {
      const otherUser = activeSession.dmParticipants.find(p => p.userId?.toString() !== user?._id?.toString());
      if (otherUser) {
        displayPic = otherUser.profilePic;
      }
    }

    navigation.setOptions({
      headerTitleAlign: 'left',
      headerLeft: () => (
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.headerLeftContainer}>
          <Ionicons name="arrow-back" size={24} color="#e9edef" style={{ marginRight: 6 }} />
          <View style={[styles.headerAvatar, { backgroundColor: isDM ? '#53bdeb' : isGroup ? themeColor : '#657786' }]}>
            {displayPic ? (
              <Image source={{ uri: resolveFileUrl(displayPic) }} style={styles.headerAvatarImg} />
            ) : (
              <Text style={styles.headerAvatarText}>{(activeSession?.groupName || displayName || 'C').charAt(0).toUpperCase()}</Text>
            )}
          </View>
        </TouchableOpacity>
      ),
      headerTitle: () => (
        <TouchableOpacity onPress={() => { setModalTab('info'); setShowProfileModal(true); }} style={styles.headerTitleContainer}>
          <Text style={styles.headerTitleText} numberOfLines={1}>{activeSession?.groupName || displayName}</Text>
          <Text style={[styles.headerSubtitleText, isSomeoneTyping && styles.typingSubtitleText, isSomeoneTyping && { color: themeColor }]}>
            {subtitleText}
          </Text>
        </TouchableOpacity>
      ),
      headerRight: () => (
        <View style={styles.headerRightActions}>
          <TouchableOpacity onPress={() => Alert.alert('Video Call', 'Video calling is coming soon!')} style={styles.headerRightIcon}>
            <Ionicons name="videocam" size={20} color="#e9edef" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Alert.alert('Voice Call', 'Audio calling is coming soon!')} style={styles.headerRightIcon}>
            <Ionicons name="call" size={18} color="#e9edef" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setShowDropdown(true)} style={styles.threeDotButton}>
            <Ionicons name="ellipsis-vertical" size={20} color="#e9edef" />
          </TouchableOpacity>
        </View>
      )
    });
  }, [navigation, displayName, activeSession?.groupName, activeSession?.groupImage, activeSession?.dmParticipants, activeSession?.visitorStatus, typingUsers, isDM, isGroup, user?._id]);

  // Set active session ID for global store
  useEffect(() => {
    setActiveSessionId(sessionId);
    if (socket && sessionId) {
      socket.emit('agent_viewing_session', {
        sessionId,
        name: user?.name,
        profilePic: user?.profilePic,
        agentId: user?._id
      });
    }
    return () => {
      setActiveSessionId(null);
      if (socket) {
        socket.emit('agent_viewing_session', { sessionId: null });
      }
    };
  }, [sessionId, socket, user]);

  // Mark as read when entering chat
  useEffect(() => {
    if (!isFocused) return;
    clearSessionUnread(sessionId);
    if (socket && activeSession && activeSession.unreadCount > 0) {
      socket.emit('mark_as_read', { sessionId, merchantId: user._id });
    }
  }, [sessionId, activeSession?.unreadCount, socket, isFocused]);

  // Load initial history if not already cached
  useEffect(() => {
    if (socket && messages.length === 0) {
      socket.emit('get_chat_history', { sessionId });
    }
  }, [sessionId, socket]);

  // Listen for typing events from other participants
  useEffect(() => {
    if (!socket) return;

    const handleTypingStart = ({ sessionId: eventSessionId, sender, senderName, senderId }) => {
      if (eventSessionId === sessionId && senderId?.toString() !== user?._id?.toString()) {
        setTypingUsers(prev => {
          if (prev.some(u => u.senderId === senderId)) return prev;
          return [...prev, { senderId, senderName, sender }];
        });
      }
    };

    const handleTypingEnd = ({ sessionId: eventSessionId, senderId }) => {
      if (eventSessionId === sessionId) {
        setTypingUsers(prev => prev.filter(u => u.senderId !== senderId));
      }
    };

    socket.on('typing_start', handleTypingStart);
    socket.on('typing_end', handleTypingEnd);

    // Clean up typing status when screen changes
    setTypingUsers([]);

    return () => {
      socket.off('typing_start', handleTypingStart);
      socket.off('typing_end', handleTypingEnd);
    };
  }, [sessionId, socket, user?._id]);

  // Auto scroll to bottom when someone starts typing
  useEffect(() => {
    if (typingUsers.length > 0) {
      setTimeout(() => {
        listRef.current?.scrollToEnd({ animated: true });
      }, 80);
      setTimeout(() => {
        listRef.current?.scrollToEnd({ animated: true });
      }, 250);
    }
  }, [typingUsers.length]);

  // Listen for session deletion and deletion errors
  useEffect(() => {
    if (!socket) return;

    const handleSessionDeleted = ({ sessionId: deletedId }) => {
      if (deletedId === sessionId) {
        Alert.alert('Group Deleted', 'This group chat has been deleted by an administrator.');
        navigation.navigate('Home');
      }
    };

    const handleDeleteError = ({ sessionId: errorId, message }) => {
      if (errorId === sessionId) {
        Alert.alert('Deletion Failed', message);
      }
    };

    socket.on('session_deleted', handleSessionDeleted);
    socket.on('delete_session_error', handleDeleteError);

    return () => {
      socket.off('session_deleted', handleSessionDeleted);
      socket.off('delete_session_error', handleDeleteError);
    };
  }, [sessionId, socket, navigation]);

  // Auto scroll to bottom when keyboard appears
  useEffect(() => {
    const showEvent = Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow';
    const showSubscription = Keyboard.addListener(showEvent, () => {
      setTimeout(() => {
        listRef.current?.scrollToEnd({ animated: true });
      }, 50);
      setTimeout(() => {
        listRef.current?.scrollToEnd({ animated: true });
      }, 150);
      setTimeout(() => {
        listRef.current?.scrollToEnd({ animated: true });
      }, 300);
    });

    return () => {
      showSubscription.remove();
    };
  }, []);

  // Clear recording timer on unmount
  useEffect(() => {
    return () => {
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
      if (recordingDotAnimation.current) {
        recordingDotAnimation.current.stop();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const permission = await Audio.requestPermissionsAsync();
      if (permission.status !== 'granted') {
        Alert.alert('Permission Denied', 'Please enable microphone access in your settings to record audio.');
        return;
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
        staysActiveInBackground: false,
        shouldRouteThroughReceiverIOS: false,
      });

      // Reset live meter visuals
      setMeteringHistory([4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]);

      const { recording: newRecording } = await Audio.Recording.createAsync(
        {
          ...Audio.RecordingOptionsPresets.HIGH_QUALITY,
          isMeteringEnabled: true,
        }
      );
      
      newRecording.setOnRecordingStatusUpdate((status) => {
        if (status.canRecord && status.metering !== undefined) {
          const db = status.metering;
          // Normalize volume levels from -60dB -> 0dB to a cleaner visual scale
          let normalized = (db + 60) / 60;
          if (normalized < 0) normalized = 0;
          if (normalized > 1) normalized = 1;
          const height = 4 + Math.round(normalized * 28);
          setMeteringHistory((prev) => {
            const next = [...prev.slice(1), height];
            return next;
          });
        }
      });
      await newRecording.setProgressUpdateInterval(100);

      setRecording(newRecording);
      setIsRecording(true);
      setRecordingDuration(0);

      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);

      recordingDotOpacity.setValue(1);
      recordingDotAnimation.current = Animated.loop(
        Animated.sequence([
          Animated.timing(recordingDotOpacity, {
            toValue: 0.2,
            duration: 500,
            useNativeDriver: true,
          }),
          Animated.timing(recordingDotOpacity, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
          })
        ])
      );
      recordingDotAnimation.current.start();

    } catch (err) {
      console.error('Failed to start recording', err);
      Alert.alert('Error', 'Failed to start voice recording.');
    }
  };

  const handleReplyPress = (replyToObj) => {
    if (!replyToObj || !replyToObj.messageId) return;
    const targetIndex = filteredMessages.findIndex(m => {
      const mId = m._id ? m._id.toString() : '';
      const mTempId = m.tempId ? m.tempId.toString() : '';
      const rId = replyToObj.messageId ? replyToObj.messageId.toString() : '';
      return (mId && mId === rId) || (mTempId && mTempId === rId);
    });
    if (targetIndex !== -1) {
      listRef.current?.scrollToIndex({
        index: targetIndex,
        animated: true,
        viewPosition: 0.5
      });
      setHighlightedMessageId(replyToObj.messageId);
      setTimeout(() => {
        setHighlightedMessageId(null);
      }, 1500);
    }
  };

  const handleCameraAction = async () => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (permission.status !== 'granted') {
        Alert.alert('Permission Denied', 'Camera permissions are required to snap photos.');
        return;
      }
      
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        quality: 0.8,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const selectedImage = result.assets[0];
        await uploadAndSendFile(selectedImage.uri, 'image', selectedImage.fileName || 'camera-photo.jpg');
      }
    } catch (error) {
      console.error('Camera error:', error);
      Alert.alert('Error', 'Failed to launch camera.');
    }
  };

  const handleImageLibraryAction = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (permission.status !== 'granted') {
        Alert.alert('Permission Denied', 'Media library access is required.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        quality: 0.8,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const selectedImage = result.assets[0];
        await uploadAndSendFile(selectedImage.uri, 'image', selectedImage.fileName || 'photo.jpg');
      }
    } catch (error) {
      console.error('Gallery error:', error);
      Alert.alert('Error', 'Failed to pick image.');
    }
  };

  const handleDocumentPickerAction = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const selectedDoc = result.assets[0];
        await uploadAndSendFile(selectedDoc.uri, 'file', selectedDoc.name);
      }
    } catch (error) {
      console.error('Document picker error:', error);
      Alert.alert('Error', 'Failed to pick document.');
    }
  };

  const handleAttachmentPress = () => {
    Alert.alert(
      'Share Attachment',
      'Select media source:',
      [
        { text: 'Photo Gallery', onPress: handleImageLibraryAction },
        { text: 'Document File', onPress: handleDocumentPickerAction },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const uploadAndSendFile = async (uri, fileType, defaultName) => {
    const tempId = `temp-${Date.now()}`;
    const localMsg = {
      sessionId,
      sender: 'merchant',
      content: defaultName,
      fileUrl: uri, // local uri
      fileType: fileType,
      merchantId: user._id,
      senderId: user._id,
      senderName: user.name,
      tempId,
      timestamp: Date.now()
    };

    const addMessageStore = useChatStore.getState().addMessage;
    addMessageStore(sessionId, localMsg);

    try {
      const formData = new FormData();
      const filename = uri.split('/').pop() || defaultName;
      const match = /\.(\w+)$/.exec(filename);
      let type = 'application/octet-stream';
      if (fileType === 'image') {
        type = match ? `image/${match[1]}` : `image/jpeg`;
      } else {
        type = match ? `application/${match[1]}` : `application/octet-stream`;
      }

      formData.append('file', {
        uri: uri,
        name: filename,
        type: type,
      });

      const response = await fetch(`${API_URL}/api/upload`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData,
      });

      const result = await response.json();
      if (result && result.success && result.fileUrl) {
        socket.emit('send_message', {
          sessionId,
          sender: 'merchant',
          content: defaultName,
          fileUrl: result.fileUrl,
          fileType: fileType,
          merchantId: user._id,
          senderId: user._id,
          senderName: user.name,
          tempId,
          timestamp: Date.now()
        });
        playSound('send_message');
      } else {
        throw new Error('Upload failed');
      }
    } catch (error) {
      console.log('Upload error:', error);
      Alert.alert('Upload Failed', 'Could not share attachment.');
    }
  };

  const stopRecording = async (shouldSend = true) => {
    if (!recording) return;

    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (recordingDotAnimation.current) {
      recordingDotAnimation.current.stop();
      recordingDotAnimation.current = null;
    }
    setIsRecording(false);

    try {
      await recording.stopAndUnloadAsync();
      const uri = recording.getURI();
      setRecording(null);

      // Reset audio mode to playback only
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
        staysActiveInBackground: false,
        shouldRouteThroughReceiverIOS: false,
      }).catch(err => console.log('Audio mode reset error:', err));

      if (shouldSend && uri) {
        await uploadAndSendAudio(uri);
      }
    } catch (err) {
      console.error('Failed to stop recording', err);
    }
  };

  const uploadAndSendAudio = async (uri) => {
    const tempId = `temp-${Date.now()}`;
    const localMsg = {
      sessionId,
      sender: 'merchant',
      content: 'Voice Note',
      fileUrl: uri, // local temp uri
      fileType: 'audio',
      merchantId: user._id,
      senderId: user._id,
      senderName: user.name,
      tempId,
      timestamp: Date.now()
    };

    const addMessageStore = useChatStore.getState().addMessage;
    addMessageStore(sessionId, localMsg);

    try {
      const formData = new FormData();
      const filename = uri.split('/').pop() || 'voice-note.m4a';
      const match = /\.(\w+)$/.exec(filename);
      const type = match ? `audio/${match[1]}` : `audio/m4a`;

      formData.append('file', {
        uri: uri,
        name: filename,
        type: type,
      });

      const response = await fetch(`${API_URL}/api/upload`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData,
      });

      const result = await response.json();
      if (result && result.success && result.fileUrl) {
        socket.emit('send_message', {
          sessionId,
          sender: 'merchant',
          content: 'Voice Note',
          fileUrl: result.fileUrl,
          fileType: 'audio',
          merchantId: user._id,
          senderId: user._id,
          senderName: user.name,
          tempId,
          timestamp: Date.now()
        });
        playSound('send_message');
      } else {
        throw new Error('Upload response unsuccessful');
      }
    } catch (error) {
      console.error('Failed to upload/send voice note:', error);
      Alert.alert('Upload Failed', 'Failed to upload voice note. Please try again.');
    }
  };

  const handleInputChange = (text) => {
    setInputMessage(text);

    if (!socket || !sessionId) return;

    if (!isTypingRef.current && text.trim().length > 0) {
      isTypingRef.current = true;
      socket.emit('typing_start', {
        sessionId,
        sender: 'merchant',
        merchantId: user._id,
        senderName: user.name
      });
    }

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    typingTimeoutRef.current = setTimeout(() => {
      if (isTypingRef.current) {
        isTypingRef.current = false;
        socket.emit('typing_end', {
          sessionId,
          sender: 'merchant',
          merchantId: user._id
        });
      }
    }, 2000);
  };

  const handleCancelEdit = () => {
    setEditingMessage(null);
    setInputMessage('');
  };

  const handleEditSubmit = () => {
    if (!inputMessage.trim() || !socket || !editingMessage) return;

    socket.emit('edit_message', {
      messageId: editingMessage._id,
      newContent: inputMessage.trim(),
      sessionId,
      merchantId: user._id
    });

    setInputMessage('');
    setEditingMessage(null);
  };

  const handleSend = () => {
    if (!inputMessage.trim() || !socket) return;

    if (editingMessage) {
      handleEditSubmit();
      return;
    }

    // Clear typing status immediately on send
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    if (isTypingRef.current) {
      isTypingRef.current = false;
      socket.emit('typing_end', {
        sessionId,
        sender: 'merchant',
        merchantId: user._id
      });
    }

    const tempId = `temp-${Date.now()}`;
    const newMsg = {
      sessionId,
      sender: 'merchant',
      content: inputMessage.trim(),
      merchantId: user._id,
      senderId: user._id,
      senderName: user.name,
      tempId,
      timestamp: Date.now()
    };

    if (replyingMessage) {
      newMsg.replyTo = {
        messageId: replyingMessage._id,
        content: replyingMessage.content || '📎 Attachment',
        sender: replyingMessage.sender
      };
      setReplyingMessage(null);
    }

    // Optimistic Update: Add message to local cache immediately
    const addMessageStore = useChatStore.getState().addMessage;
    addMessageStore(sessionId, newMsg);

    socket.emit('send_message', newMsg);
    playSound('send_message');
    setInputMessage('');
  };

  const handleJoinSession = () => {
    if (socket && sessionId) {
      socket.emit('join_session', {
        sessionId,
        agentId: user._id,
        agentName: user.name,
        merchantId: activeSession?.merchantId
      });
    }
  };

  const handleLeaveSession = () => {
    Alert.alert(
      'Leave Conversation',
      'Are you sure you want to unassign yourself from this chat?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Leave',
          style: 'destructive',
          onPress: () => {
            if (socket && sessionId) {
              socket.emit('leave_session', {
                sessionId,
                agentName: user.name,
                merchantId: activeSession?.merchantId
              });
            }
          }
        }
      ]
    );
  };

  const handleCloseSession = () => {
    Alert.alert(
      'End Conversation',
      'Are you sure you want to end this chat session? This will move it to the Closed tab.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'End Chat',
          style: 'destructive',
          onPress: () => {
            if (socket && sessionId) {
              socket.emit('close_session', { sessionId });
              navigation.goBack();
            }
          }
        }
      ]
    );
  };

  const handleMessageLongPress = (item) => {
    setSelectedMessage(item);
    setShowOptionsSheet(true);
  };

  const handleLoadMore = () => {
    if (isLoadingMore || !hasMore || messages.length === 0 || !socket) return;

    const oldestMsg = messages.find(m => m._id && !m.tempId);
    if (oldestMsg) {
      setIsLoadingMore(true);
      socket.emit('get_chat_history', {
        sessionId,
        before: oldestMsg.timestamp
      });
    }
  };

  // Turn off loading indicator once messages list updates
  useEffect(() => {
    setIsLoadingMore(false);
  }, [messages.length]);

  useEffect(() => {
    if (!socket) return;
    const handleHistory = () => {
      setIsLoadingMore(false);
    };
    socket.on('chat_history_merchant', handleHistory);
    return () => {
      socket.off('chat_history_merchant', handleHistory);
    };
  }, [socket]);

  // Scroll to bottom when a new message is received/sent or session changes
  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => {
        listRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages[messages.length - 1]?._id || messages[messages.length - 1]?.tempId, sessionId]);

  const handleUpdateGroupMemberProfile = () => {
    Alert.alert(
      'Manage on Web',
      'Personal settings inside groups are managed on the website.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Go to Website', onPress: () => Linking.openURL('https://dashboard.o-chat.live/') }
      ]
    );
  };

  const handleUpdateGroupSettings = () => {
    Alert.alert(
      'Manage on Web',
      'Group profile settings are managed on the website.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Go to Website', onPress: () => Linking.openURL('https://dashboard.o-chat.live/') }
      ]
    );
  };

  const handleDeleteGroup = () => {
    Alert.alert(
      'Manage on Web',
      'Deleting group chats is managed on the website.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Go to Website', onPress: () => Linking.openURL('https://dashboard.o-chat.live/') }
      ]
    );
  };

  const handleSearchAddMember = async (email) => {
    setAddMemberQuery(email);
    if (!email.trim()) {
      setAddMemberContacts([]);
      return;
    }
    setIsSearchingAddMember(true);
    try {
      const res = await fetch(`${API_URL}/api/auth/merchant/search?email=${encodeURIComponent(email)}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (res.ok) {
        const existingIds = activeSession?.dmParticipants?.map(p => p.userId?.toString()) || [];
        setAddMemberContacts(data.filter(c => !existingIds.includes(c._id.toString())));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearchingAddMember(false);
    }
  };

  const handleAddMemberToGroup = async (targetUserId) => {
    setIsAddingMember(true);
    try {
      const res = await fetch(`${API_URL}/api/auth/merchant/group-chat/${sessionId}/member`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ targetUserId })
      });
      const data = await res.json();
      if (res.ok) {
        Alert.alert('Success', 'Member added successfully!');
        setAddMemberQuery('');
        setAddMemberContacts([]);
        setShowAddMemberModal(false);
      } else {
        Alert.alert('Error', data.message || 'Failed to add member');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Network error. Please try again.');
    } finally {
      setIsAddingMember(false);
    }
  };

  const handleUpdateGroupMemberRole = async (targetUserId, newRole) => {
    try {
      const res = await fetch(`${API_URL}/api/auth/merchant/group-chat/${sessionId}/member`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ targetUserId, role: newRole })
      });
      const data = await res.json();
      if (!res.ok) {
        Alert.alert('Error', data.message || 'Failed to change role');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Network error. Please try again.');
    }
  };

  const handleKickGroupMember = async (targetUserId, targetName) => {
    Alert.alert(
      'Remove Member',
      `Are you sure you want to remove ${targetName} from the group?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              const res = await fetch(`${API_URL}/api/auth/merchant/group-chat/${sessionId}/kick`, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ targetUserId })
              });
              const data = await res.json();
              if (!res.ok) {
                Alert.alert('Error', data.message || 'Failed to remove member');
              }
            } catch (err) {
              console.error(err);
              Alert.alert('Error', 'Network error. Please try again.');
            }
          }
        }
      ]
    );
  };

  const handleLeaveGroup = () => {
    Alert.alert(
      'Leave Group',
      'Are you sure you want to leave this group chat?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Leave', 
          style: 'destructive', 
          onPress: async () => {
            try {
              const res = await fetch(`${API_URL}/api/auth/merchant/group-chat/${sessionId}/leave`, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}`
                }
              });
              if (res.ok) {
                setShowProfileModal(false);
                navigation.goBack();
              } else {
                const data = await res.json();
                Alert.alert('Error', data.message || 'Failed to leave group');
              }
            } catch (err) {
              console.error(err);
              Alert.alert('Error', 'Network error. Please try again.');
            }
          }
        }
      ]
    );
  };

  const getMemberDetails = (senderId) => {
    if (!activeSession || !activeSession.dmParticipants) return null;
    return activeSession.dmParticipants.find(p => p.userId?.toString() === senderId?.toString());
  };

  const renderMessageItem = ({ item, index }) => {
    if (item.sender === 'system') {
      const showDateSep = index === 0 || new Date(item.timestamp).toDateString() !== new Date(messages[index - 1].timestamp).toDateString();
      const isEnded = item.content?.toLowerCase().includes('ended') || item.content?.toLowerCase().includes('closed') || item.content?.toLowerCase().includes('left');
      
      return (
        <View style={styles.systemMessageWrapper}>
          {showDateSep && (
            <View style={styles.dateSeparator}>
              <Text style={styles.dateSeparatorText}>
                {new Date(item.timestamp).toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' })}
              </Text>
            </View>
          )}
          <View style={styles.systemMessageContainer}>
            <View style={[
              styles.systemMessageBadge,
              isEnded ? styles.systemMessageBadgeRed : styles.systemMessageBadgeGreen
            ]}>
              <Ionicons 
                name={isEnded ? "ban-outline" : "person-add-outline"} 
                size={14} 
                color={isEnded ? "#f87171" : "#00a884"} 
                style={{ marginRight: 6 }}
              />
              <Text style={[
                styles.systemMessageText,
                isEnded ? styles.systemMessageTextRed : styles.systemMessageTextGreen
              ]}>
                {item.content}
              </Text>
            </View>
          </View>
        </View>
      );
    }

    const isOut = item.sender === 'merchant' && (!item.senderId || item.senderId.toString() === user._id.toString());
    const isIn = !isOut;

    // Resolve Nickname & Designation for Group Chat
    let senderName = item.senderName || 'Agent';
    let senderDesignation = 'Support';
    
    if (isGroup && isIn) {
      const member = getMemberDetails(item.senderId);
      if (member) {
        senderName = member.nickname || member.name || senderName;
        senderDesignation = member.designation || 'Agent';
      }
    }

    // Resolve avatar info
    let avatarUrl = '';
    let avatarLetter = '';
    if (isOut) {
      avatarUrl = user.profilePic || '';
      avatarLetter = (user.name || 'Y').charAt(0).toUpperCase();
    } else {
      if (isGroup) {
        const member = getMemberDetails(item.senderId);
        if (member) {
          avatarUrl = member.profilePic || '';
          avatarLetter = (member.nickname || member.name || 'A').charAt(0).toUpperCase();
        } else {
          avatarLetter = (item.senderName || 'A').charAt(0).toUpperCase();
        }
      } else if (isDM) {
        const otherUser = activeSession?.dmParticipants?.find(p => p.userId?.toString() !== user?._id?.toString());
        if (otherUser) {
          avatarUrl = otherUser.profilePic || '';
          avatarLetter = (otherUser.name || 'U').charAt(0).toUpperCase();
        } else {
          avatarLetter = (displayName || 'U').charAt(0).toUpperCase();
        }
      } else {
        avatarLetter = (displayName || 'V').charAt(0).toUpperCase();
      }
    }

    const isMsgHighlighted = highlightedMessageId && (
      (item._id && item._id.toString() === highlightedMessageId.toString()) ||
      (item.tempId && item.tempId.toString() === highlightedMessageId.toString())
    );

    const showDateSep = index === 0 || new Date(item.timestamp).toDateString() !== new Date(messages[index - 1].timestamp).toDateString();

    return (
      <View>
        {showDateSep && (
          <View style={styles.dateSeparator}>
            <Text style={styles.dateSeparatorText}>
              {new Date(item.timestamp).toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' })}
            </Text>
          </View>
        )}

        <View style={[styles.messageRow, isOut ? styles.messageOutRow : styles.messageInRow]}>
          <SwipeableMessageBubble onReply={() => { setReplyingMessage(item); setEditingMessage(null); }} themeColor={themeColor}>
            <View style={{ flexDirection: 'row', width: '100%', justifyContent: isOut ? 'flex-end' : 'flex-start', alignItems: 'flex-end' }}>
              {/* Incoming Avatar */}
              {isIn && (
                <View style={styles.msgAvatarContainer}>
                  {avatarUrl ? (
                    <Image source={{ uri: resolveFileUrl(avatarUrl) }} style={styles.msgAvatar} />
                  ) : (
                    <View style={[styles.msgAvatarPlaceholder, { backgroundColor: isGroup ? themeColor : '#657786' }]}>
                      <Text style={styles.msgAvatarLetter}>{avatarLetter}</Text>
                    </View>
                  )}
                </View>
              )}

              <TouchableOpacity 
                style={[
                  styles.bubble, 
                  isOut ? styles.bubbleOut : styles.bubbleIn,
                  isMsgHighlighted && styles.bubbleHighlighted,
                  isMsgHighlighted && { borderColor: themeColor }
                ]}
                activeOpacity={0.85}
                onLongPress={() => handleMessageLongPress(item)}
              >
                {/* Replied parent message preview inside bubble */}
                {item.replyTo && !item.isDeleted && (
                  <TouchableOpacity 
                    style={[styles.bubbleReplyPreview, { borderLeftColor: themeColor }]}
                    onPress={() => handleReplyPress(item.replyTo)}
                    activeOpacity={0.7}
                  >
                    <Text style={[styles.bubbleReplySender, { color: themeColor }]} numberOfLines={1}>
                      {item.replyTo.sender === 'merchant' ? 'You' : displayName}
                    </Text>
                    <Text style={styles.bubbleReplyText} numberOfLines={1}>
                      {item.replyTo.content}
                    </Text>
                  </TouchableOpacity>
                )}

                {isGroup && isIn && (
                  <View style={styles.groupSenderHeader}>
                    <Text style={styles.groupSenderName}>{senderName}</Text>
                    <View style={[styles.designationBadge, { backgroundColor: `${themeColor}24` }]}>
                      <Text style={[styles.designationText, { color: themeColor }]}>{senderDesignation}</Text>
                    </View>
                  </View>
                )}

                {item.fileType === 'image' && item.fileUrl ? (
                  <View style={styles.imageMessageContainer}>
                    <Image source={{ uri: resolveFileUrl(item.fileUrl) }} style={styles.imageMessage} />
                  </View>
                ) : item.fileType === 'audio' && item.fileUrl ? (
                  <AudioPlayerBubble fileUrl={item.fileUrl} isOut={isOut} themeColor={themeColor} />
                ) : item.fileType === 'file' && item.fileUrl ? (
                  <TouchableOpacity 
                    style={styles.fileMessageContainer} 
                    onPress={() => Alert.alert('Download File', `Opening link: ${resolveFileUrl(item.fileUrl)}`)}
                  >
                    <Ionicons name="document-attach" size={24} color={isOut ? "#e9edef" : themeColor} />
                    <View style={styles.fileMessageTextContainer}>
                      <Text style={[styles.fileMessageName, { color: '#e9edef' }]} numberOfLines={1}>{item.content || 'Attachment'}</Text>
                      <Text style={styles.fileMessageSize}>File Attachment</Text>
                    </View>
                  </TouchableOpacity>
                ) : (
                  <Text style={styles.messageText}>{item.content}</Text>
                )}
                
                <View style={styles.messageMeta}>
                  <Text style={styles.messageTime}>
                    {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </Text>
                  {isOut && (
                    (item.tempId && !item._id) ? (
                      <Ionicons name="time-outline" size={13} color="rgba(233, 237, 239, 0.5)" style={{ marginLeft: 4 }} />
                    ) : (
                      <Ionicons 
                        name={item.status === 'read' || item.status === 'delivered' ? "checkmark-done" : "checkmark"} 
                        size={16} 
                        color={item.status === 'read' ? "#53bdeb" : "rgba(233, 237, 239, 0.5)"} 
                        style={{ marginLeft: 4 }}
                      />
                    )
                  )}
                </View>
              </TouchableOpacity>

              {/* Outgoing Avatar */}
              {isOut && (
                <View style={styles.msgAvatarContainerRight}>
                  {avatarUrl ? (
                    <Image source={{ uri: resolveFileUrl(avatarUrl) }} style={styles.msgAvatar} />
                  ) : (
                    <View style={[styles.msgAvatarPlaceholder, { backgroundColor: '#53bdeb' }]}>
                      <Text style={styles.msgAvatarLetter}>{avatarLetter}</Text>
                    </View>
                  )}
                </View>
              )}
            </View>
          </SwipeableMessageBubble>
        </View>
      </View>
    );
  };

  const filteredMessages = messages.filter(msg => {
    if (isGroup || activeSession?.isDirectMessage) {
      if (msg.sender === 'system' && (msg.content?.toLowerCase().includes('ended') || msg.content?.toLowerCase().includes('closed'))) {
        return false;
      }
    }
    return true;
  });

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={headerHeight}
        style={{ flex: 1 }}
      >
        <FlatList
          ref={listRef}
          data={filteredMessages}
          renderItem={renderMessageItem}
          keyExtractor={(item, index) => item._id || item.tempId || index.toString()}
          contentContainerStyle={styles.messageList}
          onScrollToIndexFailed={(info) => {
            listRef.current?.scrollToOffset({
              offset: info.averageItemLength * info.index,
              animated: true
            });
            setTimeout(() => {
              listRef.current?.scrollToIndex({
                index: info.index,
                animated: true,
                viewPosition: 0.5
              });
            }, 100);
          }}
          onScroll={({ nativeEvent }) => {
            const { contentOffset } = nativeEvent;
            if (contentOffset.y === 0) {
              handleLoadMore();
            }
          }}
          ListHeaderComponent={
            hasMore ? (
              isLoadingMore ? (
                <ActivityIndicator size="small" color="#00a884" style={{ marginVertical: 10 }} />
              ) : (
                <TouchableOpacity 
                  style={styles.loadMoreBtn} 
                  onPress={handleLoadMore}
                >
                  <Text style={styles.loadMoreBtnText}>Load older messages</Text>
                </TouchableOpacity>
              )
            ) : null
          }
          ListFooterComponent={
            typingUsers.length > 0 ? (
              <View style={styles.typingIndicatorRow}>
                <View style={styles.typingBubble}>
                  {isGroup && (
                    <Text style={styles.typingBubbleUser}>
                      {typingUsers.map(u => u.senderName).join(', ')}
                    </Text>
                  )}
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text style={[styles.typingBubbleText, { color: themeColor }]}>typing</Text>
                    <TypingIndicator />
                  </View>
                </View>
              </View>
            ) : null
          }
        />
        {replyingMessage && (
          <View style={[styles.replyBanner, { borderLeftColor: themeColor }]}>
            <View style={{ flex: 1, paddingLeft: 8 }}>
              <Text style={[styles.replyBannerTitle, { color: themeColor }]}>
                Replying to {replyingMessage.sender === 'merchant' ? 'Agent' : displayName}
              </Text>
              <Text style={styles.replyBannerText} numberOfLines={1}>
                {replyingMessage.content}
              </Text>
            </View>
            <TouchableOpacity onPress={() => setReplyingMessage(null)} style={styles.replyBannerClose}>
              <Ionicons name="close-circle" size={22} color="#f87171" />
            </TouchableOpacity>
          </View>
        )}
        {editingMessage && (
          <View style={[styles.editingBanner, { borderLeftColor: themeColor }]}>
            <View style={{ flex: 1, paddingLeft: 8 }}>
              <Text style={[styles.editingBannerTitle, { color: themeColor }]}>Editing message</Text>
              <Text style={styles.editingBannerText} numberOfLines={1}>{editingMessage.content}</Text>
            </View>
            <TouchableOpacity onPress={handleCancelEdit} style={styles.editingBannerClose}>
              <Ionicons name="close-circle" size={22} color="#f87171" />
            </TouchableOpacity>
          </View>
        )}

        {/* Input Bar or Join/Assign Controls */}
        {activeSession?.status === 'closed' ? (
          <View style={styles.joinContainer}>
            <Text style={styles.joinInfoText}>This conversation has ended.</Text>
          </View>
        ) : !isGroup && !isDM && !activeSession?.assignedAgent ? (
          <View style={styles.joinContainer}>
            <Text style={styles.joinInfoText}>This chat is unassigned. Join to reply.</Text>
            <TouchableOpacity style={[styles.joinButton, { backgroundColor: themeColor }]} onPress={handleJoinSession}>
              <Text style={styles.joinButtonText}>Join Conversation</Text>
            </TouchableOpacity>
          </View>
        ) : !isGroup && !isDM && activeSession?.assignedAgent && activeSession.assignedAgent.toString() !== user?._id?.toString() ? (
          <View style={styles.joinContainer}>
            <Text style={styles.joinInfoText}>Assigned to {activeSession.assignedAgentName || 'another agent'}.</Text>
          </View>
        ) : (
          <View style={styles.inputBar}>
            {isRecording ? (
              <View style={styles.recordingBarContainer}>
                <View style={styles.recordingTimerContainer}>
                  <Animated.View style={[styles.recordingDot, { opacity: recordingDotOpacity }]} />
                  <Text style={styles.recordingTimerText}>
                    {Math.floor(recordingDuration / 60)}:{(recordingDuration % 60).toString().padStart(2, '0')}
                  </Text>
                  
                  {/* Real-time Dancing Waveform */}
                  <View style={styles.recordingWaveform}>
                    {meteringHistory.map((height, idx) => (
                      <View 
                        key={idx} 
                        style={[
                          styles.recordingWaveformBar, 
                          { height: height, backgroundColor: themeColor }
                        ]} 
                      />
                    ))}
                  </View>
                </View>
                
                <View style={styles.recordingControls}>
                  <TouchableOpacity 
                    style={styles.recordingCancelBtn} 
                    onPress={() => stopRecording(false)}
                  >
                    <Ionicons name="trash-outline" size={22} color="#ef4444" />
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.recordingSendBtn, { backgroundColor: themeColor }]} 
                    onPress={() => stopRecording(true)}
                  >
                    <Ionicons name="send" size={18} color="#fff" />
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <>
                <View style={styles.inputContainer}>
                  <TouchableOpacity 
                    style={styles.inputIconBtn} 
                    onPress={() => {
                      Keyboard.dismiss();
                      setShowEmojiPicker(prev => !prev);
                    }}
                  >
                    <Ionicons name={showEmojiPicker ? "keyboard" : "happy-outline"} size={24} color="#8696a0" />
                  </TouchableOpacity>
                  
                  <TextInput
                    style={styles.textInput}
                    placeholder="Type a message..."
                    placeholderTextColor="#8696a0"
                    value={inputMessage}
                    onChangeText={handleInputChange}
                    multiline
                    onFocus={() => {
                      setShowEmojiPicker(false);
                      setTimeout(() => {
                        listRef.current?.scrollToEnd({ animated: true });
                      }, 50);
                      setTimeout(() => {
                        listRef.current?.scrollToEnd({ animated: true });
                      }, 200);
                    }}
                  />

                  <TouchableOpacity style={styles.inputIconBtn} onPress={handleAttachmentPress}>
                    <Ionicons name="attach-outline" size={22} color="#8696a0" />
                  </TouchableOpacity>
                  <TouchableOpacity style={[styles.inputIconBtn, { marginRight: 4 }]} onPress={handleCameraAction}>
                    <Ionicons name="camera-outline" size={24} color="#8696a0" />
                  </TouchableOpacity>
                </View>

                <TouchableOpacity 
                  style={[styles.sendButton, { backgroundColor: themeColor }]} 
                  onPress={inputMessage.trim() ? handleSend : startRecording}
                >
                  <Ionicons name={inputMessage.trim() ? "send" : "mic"} size={20} color="#fff" />
                </TouchableOpacity>
              </>
            )}
          </View>
        )}

        {/* Custom Emoji Picker Panel */}
        {showEmojiPicker && (
          <View style={styles.emojiPickerContainer}>
            <ScrollView contentContainerStyle={styles.emojiGrid} nestedScrollEnabled>
              {POPULAR_EMOJIS.map((emoji, idx) => (
                <TouchableOpacity 
                  key={idx} 
                  style={styles.emojiButton}
                  onPress={() => {
                    setInputMessage(prev => {
                      const next = prev + emoji;
                      handleInputChange(next);
                      return next;
                    });
                  }}
                >
                  <Text style={styles.emojiText}>{emoji}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}
      </KeyboardAvoidingView>

      {/* Three-dot Dropdown Menu Overlay */}
      <Modal
        visible={showDropdown}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowDropdown(false)}
      >
        <TouchableOpacity 
          style={styles.dropdownOverlay} 
          activeOpacity={1} 
          onPress={() => setShowDropdown(false)}
        >
          <View style={[styles.dropdownMenu, { top: Platform.OS === 'ios' ? headerHeight + 50 : headerHeight + 10 }]}>
            <TouchableOpacity 
              style={styles.dropdownItem} 
              onPress={() => {
                setShowDropdown(false);
                setModalTab('info');
                setShowProfileModal(true);
              }}
            >
              <Ionicons name="information-circle-outline" size={18} color="#e9edef" style={styles.dropdownIcon} />
              <Text style={styles.dropdownText}>Chat Details</Text>
            </TouchableOpacity>
            
            {isGroup && (
              <TouchableOpacity 
                style={styles.dropdownItem} 
                onPress={() => {
                  setShowDropdown(false);
                  Alert.alert('Manage on Web', 'Group settings are managed on the website.', [
                    { text: 'Cancel', style: 'cancel' },
                    { text: 'Go to Website', onPress: () => Linking.openURL('https://dashboard.o-chat.live/') }
                  ]);
                }}
              >
                <Ionicons name="settings-outline" size={18} color="#e9edef" style={styles.dropdownIcon} />
                <Text style={styles.dropdownText}>Group Settings</Text>
              </TouchableOpacity>
            )}

            {!isGroup && !isDM && activeSession?.status !== 'closed' && (
              <>
                {activeSession?.assignedAgent?.toString() !== user?._id?.toString() && (
                  <TouchableOpacity 
                    style={styles.dropdownItem} 
                    onPress={() => {
                      setShowDropdown(false);
                      handleJoinSession();
                    }}
                  >
                    <Ionicons name="enter-outline" size={18} color="#00a884" style={styles.dropdownIcon} />
                    <Text style={[styles.dropdownText, { color: '#00a884' }]}>Join Session</Text>
                  </TouchableOpacity>
                )}

                {activeSession?.assignedAgent?.toString() === user?._id?.toString() && (
                  <TouchableOpacity 
                    style={styles.dropdownItem} 
                    onPress={() => {
                      setShowDropdown(false);
                      handleLeaveSession();
                    }}
                  >
                    <Ionicons name="exit-outline" size={18} color="#e9edef" style={styles.dropdownIcon} />
                    <Text style={styles.dropdownText}>Leave Session</Text>
                  </TouchableOpacity>
                )}

                <TouchableOpacity 
                  style={styles.dropdownItem} 
                  onPress={() => {
                    setShowDropdown(false);
                    handleCloseSession();
                  }}
                >
                  <Ionicons name="checkmark-done-circle-outline" size={18} color="#ef4444" style={styles.dropdownIcon} />
                  <Text style={[styles.dropdownText, { color: '#ef4444' }]}>End Session</Text>
                </TouchableOpacity>
              </>
            )}

            <TouchableOpacity 
              style={[styles.dropdownItem, { borderBottomWidth: 0 }]} 
              onPress={() => setShowDropdown(false)}
            >
              <Ionicons name="close-circle-outline" size={18} color="#f87171" style={styles.dropdownIcon} />
              <Text style={[styles.dropdownText, { color: '#f87171' }]}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Profile / Group / Client Detail Modal */}
      {activeSession ? (
        <Modal
          visible={showProfileModal}
          animationType="slide"
          transparent={true}
          onRequestClose={() => setShowProfileModal(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              {/* Modal Header */}
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>{isGroup ? 'Group Details' : 'Chat Info'}</Text>
                <TouchableOpacity onPress={() => setShowProfileModal(false)}>
                  <Ionicons name="close" size={24} color="#e9edef" />
                </TouchableOpacity>
              </View>

              {/* Tab Selector (only for group chats) */}
              {isGroup && (
                <View style={styles.modalTabBar}>
                  <TouchableOpacity 
                    style={[styles.modalTabButton, modalTab === 'info' && styles.activeModalTabButton]}
                    onPress={() => setModalTab('info')}
                  >
                    <Ionicons name="people-outline" size={18} color={modalTab === 'info' ? '#00a884' : '#8696a0'} style={{marginRight: 6}} />
                    <Text style={[styles.modalTabText, modalTab === 'info' && styles.activeModalTabText]}>Members & Info</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.modalTabButton, modalTab === 'settings' && styles.activeModalTabButton]}
                    onPress={() => setModalTab('settings')}
                  >
                    <Ionicons name="settings-outline" size={18} color={modalTab === 'settings' ? '#00a884' : '#8696a0'} style={{marginRight: 6}} />
                    <Text style={[styles.modalTabText, modalTab === 'settings' && styles.activeModalTabText]}>Settings</Text>
                  </TouchableOpacity>
                </View>
              )}

              <ScrollView style={styles.modalScrollBody} contentContainerStyle={{ paddingBottom: 35 }}>
                {/* Avatar area */}
                <View style={styles.profileAvatarSection}>
                  <View style={[styles.largeAvatar, { backgroundColor: isDM ? '#53bdeb' : isGroup ? '#00a884' : '#657786' }]}>
                    {activeSession.groupImage ? (
                      <Image source={{ uri: resolveFileUrl(activeSession.groupImage) }} style={styles.largeAvatarImg} />
                    ) : (
                      <Text style={styles.largeAvatarText}>{(activeSession.groupName || displayName).charAt(0).toUpperCase()}</Text>
                    )}
                  </View>
                  <Text style={styles.profileNameText}>{activeSession.groupName || displayName}</Text>
                  <Text style={styles.profileSubtitleText}>
                    {isGroup ? 'Group Chat Room' : isDM ? 'Direct Message Session' : 'Website Client Session'}
                  </Text>
                </View>

                {/* Section Content */}
                {isGroup ? (
                  modalTab === 'info' ? (
                    <View style={styles.infoSection}>
                      {/* Group members list with online status indicators */}
                      <View style={styles.cardContainer}>
                        <View style={styles.cardHeaderRow}>
                          <Text style={[styles.cardHeading, { color: themeColor }]}>Group Members</Text>
                          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <View style={[styles.activeMembersBadge, { marginRight: 8, backgroundColor: `${themeColor}24` }]}>
                              <Text style={[styles.activeMembersText, { color: themeColor }]}>
                                {activeSession.dmParticipants?.filter(p => onlineAgents.includes(p.userId?.toString())).length || 0} Online
                              </Text>
                            </View>
                            {isGroupAdmin && (
                              <TouchableOpacity 
                                style={styles.addMemberHeaderBtn} 
                                onPress={() => {
                                  setShowProfileModal(false);
                                  Alert.alert('Manage on Web', 'Adding members is managed on the website.', [
                                    { text: 'Cancel', style: 'cancel' },
                                    { text: 'Go to Website', onPress: () => Linking.openURL('https://dashboard.o-chat.live/') }
                                  ]);
                                }}
                              >
                                <Ionicons name="person-add-outline" size={18} color={themeColor} />
                              </TouchableOpacity>
                            )}
                          </View>
                        </View>
                        
                        {activeSession.dmParticipants?.map((member) => {
                          const isMemberOnline = onlineAgents.includes(member.userId?.toString());
                          const isSelf = member.userId?.toString() === user?._id?.toString();
                          return (
                            <View key={member.userId} style={styles.memberRow}>
                              <View style={styles.memberAvatarContainer}>
                                <View style={styles.memberAvatar}>
                                  <Text style={styles.memberAvatarText}>{(member.nickname || member.name || 'A').charAt(0).toUpperCase()}</Text>
                                </View>
                                <View style={[styles.statusDot, { backgroundColor: isMemberOnline ? '#00a884' : '#8696a0' }]} />
                              </View>
                              <View style={styles.memberInfo}>
                                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                  <Text style={styles.memberName}>{member.nickname || member.name} {isSelf && '(You)'}</Text>
                                  {isMemberOnline && (
                                    <Text style={[styles.onlineLabelText, { color: themeColor }]}> • online</Text>
                                  )}
                                </View>
                                <Text style={styles.memberSubText}>
                                  {member.designation || 'Support'} • {member.role === 'admin' ? 'Admin' : 'Member'}
                                </Text>
                              </View>
                              {isGroupAdmin && !isSelf && (
                                <TouchableOpacity 
                                  style={styles.memberActionDots} 
                                  onPress={() => {
                                    setShowProfileModal(false);
                                    Alert.alert('Manage on Web', 'Member actions (roles, remove) are managed on the website.', [
                                      { text: 'Cancel', style: 'cancel' },
                                      { text: 'Go to Website', onPress: () => Linking.openURL('https://dashboard.o-chat.live/') }
                                    ]);
                                  }}
                                >
                                  <Ionicons name="ellipsis-vertical" size={18} color="#8696a0" />
                                </TouchableOpacity>
                              )}
                            </View>
                          );
                        })}
                      </View>
                    </View>
                  ) : (
                    <View style={styles.infoSection}>
                      {/* Admin settings for group details */}
                      {isGroupAdmin ? (
                        <View style={[styles.cardContainer, { marginBottom: 24 }]}>
                          <Text style={styles.cardHeading}>Edit Group Profile (Admin Only)</Text>
                          
                          <Text style={styles.inputLabel}>Group Name</Text>
                          <TextInput
                            style={styles.modalInput}
                            value={grpName}
                            onChangeText={setGrpName}
                            placeholder="Group name"
                            placeholderTextColor="#8696a0"
                          />
                          
                          <Text style={styles.inputLabel}>Group Image URL</Text>
                          <TextInput
                            style={styles.modalInput}
                            value={grpImage}
                            onChangeText={setGrpImage}
                            placeholder="https://example.com/image.png"
                            placeholderTextColor="#8696a0"
                          />

                          {grpImage ? (
                            <View style={styles.imagePreviewContainer}>
                              <Text style={styles.inputLabel}>Live Preview</Text>
                              <Image source={{ uri: grpImage }} style={styles.imagePreview} />
                            </View>
                          ) : null}
                          <TouchableOpacity style={styles.saveBtn} onPress={handleUpdateGroupSettings} disabled={isSavingGroupSettings}>
                            {isSavingGroupSettings ? (
                              <ActivityIndicator color="#fff" />
                            ) : (
                              <Text style={styles.saveBtnText}>Update Group Settings</Text>
                            )}
                          </TouchableOpacity>

                          {/* Delete Group Section (Danger Zone) */}
                          <View style={{ marginTop: 24, borderTopWidth: 1, borderTopColor: 'rgba(239, 68, 68, 0.2)', paddingTop: 16 }}>
                            <Text style={[styles.cardHeading, { color: '#ef4444' }]}>Danger Zone</Text>
                            <Text style={styles.inputLabel}>Enter Admin Password to Delete Group</Text>
                            <TextInput
                              style={styles.modalInput}
                              value={deletePassword}
                              onChangeText={setDeletePassword}
                              secureTextEntry
                              placeholder="Confirm with password"
                              placeholderTextColor="#8696a0"
                            />
                            <TouchableOpacity 
                              style={[styles.saveBtn, { backgroundColor: '#ef4444', marginTop: 4 }]} 
                              onPress={handleDeleteGroup}
                            >
                              <Text style={styles.saveBtnText}>Delete Group Chat</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      ) : null}

                      {/* Self profile settings */}
                      <View style={[styles.cardContainer, { marginBottom: 24 }]}>
                        <Text style={styles.cardHeading}>Your Personal Settings</Text>
                        
                        <Text style={styles.inputLabel}>Group Nickname</Text>
                        <TextInput
                          style={styles.modalInput}
                          value={nickname}
                          onChangeText={setNickname}
                          placeholder="Enter nickname"
                          placeholderTextColor="#8696a0"
                        />
                        
                        <Text style={styles.inputLabel}>Group Designation</Text>
                        <TextInput
                          style={styles.modalInput}
                          value={designation}
                          onChangeText={setDesignation}
                          placeholder="Enter designation"
                          placeholderTextColor="#8696a0"
                        />
                        
                        <TouchableOpacity style={styles.saveBtn} onPress={handleUpdateGroupMemberProfile} disabled={isSavingProfile}>
                          {isSavingProfile ? (
                            <ActivityIndicator color="#fff" />
                          ) : (
                            <Text style={styles.saveBtnText}>Save Personal Settings</Text>
                          )}
                        </TouchableOpacity>

                        <TouchableOpacity 
                          style={[styles.saveBtn, { backgroundColor: '#f87171', marginTop: 12 }]} 
                          onPress={handleLeaveGroup}
                        >
                          <Text style={styles.saveBtnText}>Leave Group</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  )
                ) : (
                  <View style={styles.infoSection}>
                    <View style={styles.cardContainer}>
                      <Text style={styles.cardHeading}>Session Details</Text>
                      
                      <View style={styles.infoField}>
                        <Text style={styles.infoFieldLabel}>Email Address</Text>
                        <Text style={styles.infoFieldValue}>{activeSession.visitorEmail || 'N/A'}</Text>
                      </View>

                      <View style={styles.infoField}>
                        <Text style={styles.infoFieldLabel}>Phone Number</Text>
                        <Text style={styles.infoFieldValue}>{activeSession.visitorPhone || 'N/A'}</Text>
                      </View>

                      <View style={styles.infoField}>
                        <Text style={styles.infoFieldLabel}>Website Domain</Text>
                        <Text style={styles.infoFieldValue}>{activeSession.visitorDomain || 'N/A'}</Text>
                      </View>

                      <View style={styles.infoField}>
                        <Text style={styles.infoFieldLabel}>Landing Page</Text>
                        <Text style={styles.infoFieldValue}>{activeSession.visitorPath || 'N/A'}</Text>
                      </View>

                      <View style={styles.infoField}>
                        <Text style={styles.infoFieldLabel}>Status</Text>
                        <Text style={styles.infoFieldValue}>{activeSession.visitorStatus || 'online'}</Text>
                      </View>

                      {activeSession.isOfflineLead && (
                        <View style={[styles.infoField, styles.offlineCard]}>
                          <Text style={[styles.infoFieldLabel, { color: '#ef4444' }]}>Offline Lead Query</Text>
                          <Text style={styles.infoFieldValue}>{activeSession.visitorDetails || 'No message provided'}</Text>
                        </View>
                      )}
                    </View>
                  </View>
                )}
              </ScrollView>
            </View>
          </View>
        </Modal>
      ) : null}

      {/* Bottom Sheet Message Options Modal */}
      <Modal
        visible={showOptionsSheet}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowOptionsSheet(false)}
      >
        <TouchableOpacity 
          style={styles.sheetOverlay} 
          activeOpacity={1} 
          onPress={() => setShowOptionsSheet(false)}
        >
          <View style={styles.sheetContent}>
            {/* Indicator handle */}
            <View style={styles.sheetHandle} />

            {selectedMessage && (
              <View style={styles.sheetHeader}>
                <Text style={styles.sheetHeaderText} numberOfLines={1}>
                  "{selectedMessage.content}"
                </Text>
              </View>
            )}

            <TouchableOpacity 
              style={styles.sheetItem} 
              onPress={() => {
                setShowOptionsSheet(false);
                if (selectedMessage) {
                  setReplyingMessage(selectedMessage);
                  setEditingMessage(null);
                }
              }}
            >
              <Ionicons name="arrow-undo-outline" size={20} color="#e9edef" style={styles.sheetItemIcon} />
              <Text style={styles.sheetItemText}>Reply</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.sheetItem} 
              onPress={() => {
                setShowOptionsSheet(false);
                if (selectedMessage) {
                  Clipboard.setString(selectedMessage.content);
                  Alert.alert('Copied', 'Message copied to clipboard');
                }
              }}
            >
              <Ionicons name="copy-outline" size={20} color="#e9edef" style={styles.sheetItemIcon} />
              <Text style={styles.sheetItemText}>Copy Text</Text>
            </TouchableOpacity>

            {selectedMessage && selectedMessage.sender === 'merchant' && (!selectedMessage.senderId || selectedMessage.senderId.toString() === user._id.toString()) && !selectedMessage.isDeleted && (
              <>
                <TouchableOpacity 
                  style={styles.sheetItem} 
                  onPress={() => {
                    setShowOptionsSheet(false);
                    setEditingMessage(selectedMessage);
                    setInputMessage(selectedMessage.content);
                    setReplyingMessage(null);
                  }}
                >
                  <Ionicons name="pencil-outline" size={20} color="#e9edef" style={styles.sheetItemIcon} />
                  <Text style={styles.sheetItemText}>Edit Message</Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  style={[styles.sheetItem, { borderBottomWidth: 0 }]} 
                  onPress={() => {
                    setShowOptionsSheet(false);
                    Alert.alert(
                      'Delete Message',
                      'Are you sure you want to delete this message?',
                      [
                        { text: 'Cancel', style: 'cancel' },
                        {
                          text: 'Delete',
                          style: 'destructive',
                          onPress: () => {
                            socket.emit('delete_message', {
                              messageId: selectedMessage._id,
                              sessionId,
                              merchantId: user._id
                            });
                          }
                        }
                      ]
                    );
                  }}
                >
                  <Ionicons name="trash-outline" size={20} color="#f87171" style={styles.sheetItemIcon} />
                  <Text style={[styles.sheetItemText, { color: '#f87171' }]}>Delete Message</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Add Member Modal (Admin Only) */}
      <Modal
        visible={showAddMemberModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => { setShowAddMemberModal(false); setAddMemberQuery(''); setAddMemberContacts([]); }}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { height: '75%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Group Member</Text>
              <TouchableOpacity onPress={() => { setShowAddMemberModal(false); setAddMemberQuery(''); setAddMemberContacts([]); }}>
                <Ionicons name="close" size={24} color="#e9edef" />
              </TouchableOpacity>
            </View>

            <View style={{ padding: 16 }}>
              <TextInput
                style={styles.modalInput}
                placeholder="Search agent by email..."
                placeholderTextColor="#8696a0"
                value={addMemberQuery}
                onChangeText={handleSearchAddMember}
                autoCapitalize="none"
              />
            </View>

            {isSearchingAddMember ? (
              <ActivityIndicator color="#00a884" size="large" style={{ marginTop: 20 }} />
            ) : (
              <FlatList
                data={addMemberContacts}
                keyExtractor={(item) => item._id}
                contentContainerStyle={{ paddingHorizontal: 16 }}
                ListEmptyComponent={
                  <View style={{ alignItems: 'center', paddingTop: 30 }}>
                    <Text style={{ color: '#8696a0', fontSize: 14 }}>
                      {addMemberQuery ? 'No agents found' : 'Type email to search other agents'}
                    </Text>
                  </View>
                }
                renderItem={({ item }) => (
                  <TouchableOpacity 
                    style={styles.memberRow} 
                    onPress={() => handleAddMemberToGroup(item._id)}
                    disabled={isAddingMember}
                  >
                    <View style={styles.memberAvatar}>
                      <Text style={styles.memberAvatarText}>{item.name.charAt(0).toUpperCase()}</Text>
                    </View>
                    <View style={styles.memberInfo}>
                      <Text style={styles.memberName}>{item.name}</Text>
                      <Text style={styles.memberSubText}>{item.email}</Text>
                    </View>
                    {isAddingMember ? (
                      <ActivityIndicator size="small" color="#00a884" />
                    ) : (
                      <Ionicons name="add-circle" size={24} color="#00a884" />
                    )}
                  </TouchableOpacity>
                )}
              />
            )}
          </View>
        </View>
      </Modal>

      {/* Member Actions Modal Sheet (Admin Only) */}
      <Modal
        visible={showMemberActionsModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => { setShowMemberActionsModal(false); setSelectedMemberForActions(null); }}
      >
        <TouchableOpacity 
          style={styles.sheetOverlay} 
          activeOpacity={1} 
          onPress={() => { setShowMemberActionsModal(false); setSelectedMemberForActions(null); }}
        >
          <View style={styles.sheetContent}>
            <View style={styles.sheetHandle} />

            {selectedMemberForActions && (
              <View style={styles.sheetHeader}>
                <Text style={styles.sheetHeaderText} numberOfLines={1}>
                  Options for {selectedMemberForActions.nickname || selectedMemberForActions.name}
                </Text>
              </View>
            )}

            {selectedMemberForActions && (
              <>
                <TouchableOpacity 
                  style={styles.sheetItem} 
                  onPress={() => {
                    setShowMemberActionsModal(false);
                    const newRole = selectedMemberForActions.role === 'admin' ? 'member' : 'admin';
                    handleUpdateGroupMemberRole(selectedMemberForActions.userId, newRole);
                    setSelectedMemberForActions(null);
                  }}
                >
                  <Ionicons name="shield-half-outline" size={20} color="#e9edef" style={styles.sheetItemIcon} />
                  <Text style={styles.sheetItemText}>
                    {selectedMemberForActions.role === 'admin' ? 'Demote to Member' : 'Promote to Admin'}
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  style={[styles.sheetItem, { borderBottomWidth: 0 }]} 
                  onPress={() => {
                    setShowMemberActionsModal(false);
                    handleKickGroupMember(selectedMemberForActions.userId, selectedMemberForActions.nickname || selectedMemberForActions.name);
                    setSelectedMemberForActions(null);
                  }}
                >
                  <Ionicons name="trash-outline" size={20} color="#f87171" style={styles.sheetItemIcon} />
                  <Text style={[styles.sheetItemText, { color: '#f87171' }]}>Remove from Group</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0b141a',
  },
  headerLeftContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 12,
  },
  headerAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  headerAvatarImg: {
    width: 36,
    height: 36,
    borderRadius: 18,
    overflow: 'hidden',
  },
  headerAvatarText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  headerTitleContainer: {
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingVertical: 4,
    paddingLeft: 8,
  },
  headerTitleText: {
    color: '#e9edef',
    fontWeight: 'bold',
    fontSize: 16,
  },
  headerSubtitleText: {
    color: '#8696a0',
    fontSize: 11,
    marginTop: 1,
  },
  headerRightActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerRightIcon: {
    padding: 8,
    marginHorizontal: 2,
  },
  threeDotButton: {
    paddingHorizontal: 8,
    paddingVertical: 8,
    marginRight: 4,
  },
  messageList: {
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  dateSeparator: {
    alignItems: 'center',
    marginVertical: 12,
  },
  dateSeparatorText: {
    color: '#8696a0',
    fontSize: 11,
    backgroundColor: '#182229',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 6,
  },
  messageRow: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  messageOutRow: {
    justifyContent: 'flex-end',
  },
  messageInRow: {
    justifyContent: 'flex-start',
  },
  bubble: {
    maxWidth: '80%',
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.18,
    shadowRadius: 1.0,
    elevation: 1,
  },
  bubbleOut: {
    backgroundColor: '#005c4b',
    borderBottomRightRadius: 2,
  },
  bubbleIn: {
    backgroundColor: '#202c33',
    borderBottomLeftRadius: 2,
  },
  groupSenderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  groupSenderName: {
    color: '#34b7f1',
    fontWeight: 'bold',
    fontSize: 12,
    marginRight: 6,
  },
  designationBadge: {
    backgroundColor: 'rgba(0, 168, 132, 0.15)',
    borderRadius: 4,
    paddingHorizontal: 4,
    paddingVertical: 1,
  },
  designationText: {
    color: '#00a884',
    fontSize: 9,
    fontWeight: 'bold',
  },
  messageText: {
    color: '#e9edef',
    fontSize: 15,
    lineHeight: 20,
  },
  messageMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    marginTop: 4,
  },
  messageTime: {
    color: 'rgba(233, 237, 239, 0.6)',
    fontSize: 10,
  },
  checkMark: {
    color: '#8696a0',
    fontSize: 11,
    marginLeft: 4,
  },
  checkMarkRead: {
    color: '#53bdeb',
  },
  sendingIcon: {
    color: 'rgba(233, 237, 239, 0.6)',
    fontSize: 9,
    marginLeft: 4,
  },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 8,
    paddingVertical: 8,
    backgroundColor: '#0b141a',
  },
  inputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#202c33',
    borderRadius: 24,
    paddingHorizontal: 8,
    paddingVertical: Platform.OS === 'ios' ? 4 : 2,
  },
  textInput: {
    flex: 1,
    color: '#e9edef',
    fontSize: 16,
    paddingHorizontal: 8,
    paddingVertical: 6,
    maxHeight: 120,
  },
  inputIconBtn: {
    padding: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButton: {
    backgroundColor: '#00a884',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 6,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.75)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#111b21',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    height: '85%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderColor: '#222e35',
  },
  modalTitle: {
    color: '#e9edef',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalScrollBody: {
    padding: 16,
  },
  profileAvatarSection: {
    alignItems: 'center',
    marginBottom: 20,
  },
  largeAvatar: {
    width: 90,
    height: 90,
    borderRadius: 45,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  largeAvatarImg: {
    width: 90,
    height: 90,
    borderRadius: 45,
  },
  largeAvatarText: {
    color: '#fff',
    fontSize: 36,
    fontWeight: 'bold',
  },
  profileNameText: {
    color: '#e9edef',
    fontSize: 20,
    fontWeight: 'bold',
  },
  profileSubtitleText: {
    color: '#8696a0',
    fontSize: 13,
    marginTop: 4,
  },
  infoSection: {
    width: '100%',
  },
  cardContainer: {
    backgroundColor: '#1d2a32',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(134,150,160,0.1)',
  },
  cardHeading: {
    color: '#00a884',
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginBottom: 16,
    letterSpacing: 0.5,
  },
  memberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderColor: '#202c33',
  },
  memberAvatarContainer: {
    position: 'relative',
    marginRight: 12,
  },
  memberAvatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#657786',
    justifyContent: 'center',
    alignItems: 'center',
  },
  memberAvatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  statusDot: {
    position: 'absolute',
    bottom: -1,
    right: -1,
    width: 10,
    height: 10,
    borderRadius: 5,
    borderWidth: 1.5,
    borderColor: '#1d2a32',
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    color: '#e9edef',
    fontSize: 15,
    fontWeight: 'bold',
  },
  memberSubText: {
    color: '#8696a0',
    fontSize: 12,
    marginTop: 2,
  },
  onlineLabelText: {
    color: '#00a884',
    fontSize: 11,
    fontWeight: 'bold',
  },
  addMemberHeaderBtn: {
    padding: 4,
  },
  memberActionDots: {
    padding: 8,
  },
  inputLabel: {
    color: '#8696a0',
    fontSize: 11,
    marginBottom: 6,
    fontWeight: 'bold',
  },
  modalInput: {
    backgroundColor: '#2a3942',
    color: '#e9edef',
    borderRadius: 8,
    padding: 10,
    fontSize: 15,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#202c33',
  },
  saveBtn: {
    backgroundColor: '#00a884',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 6,
  },
  saveBtnText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  infoField: {
    marginBottom: 18,
    borderBottomWidth: 1,
    borderColor: '#202c33',
    paddingBottom: 10,
  },
  infoFieldLabel: {
    color: '#8696a0',
    fontSize: 12,
    marginBottom: 4,
  },
  infoFieldValue: {
    color: '#e9edef',
    fontSize: 15,
    fontWeight: '500',
  },
  offlineCard: {
    backgroundColor: '#202c33',
    padding: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#2a3942',
    marginTop: 10,
  },
  dropdownOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  dropdownMenu: {
    position: 'absolute',
    right: 12,
    backgroundColor: '#202c33',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#2a3942',
    paddingVertical: 4,
    minWidth: 170,
    // Shadow for elevation
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 8,
  },
  dropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderColor: 'rgba(134, 150, 160, 0.1)',
  },
  dropdownIcon: {
    marginRight: 10,
  },
  dropdownText: {
    color: '#e9edef',
    fontSize: 14,
    fontWeight: '500',
  },
  modalTabBar: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderColor: '#222e35',
    backgroundColor: '#111b21',
  },
  modalTabButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderBottomWidth: 2,
    borderColor: 'transparent',
  },
  activeModalTabButton: {
    borderColor: '#00a884',
  },
  modalTabText: {
    color: '#8696a0',
    fontSize: 13,
    fontWeight: 'bold',
  },
  activeModalTabText: {
    color: '#00a884',
  },
  cardHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    borderBottomWidth: 1,
    borderColor: '#202c33',
    paddingBottom: 8,
  },
  activeMembersBadge: {
    backgroundColor: 'rgba(0, 168, 132, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
  },
  activeMembersText: {
    color: '#00a884',
    fontSize: 11,
    fontWeight: 'bold',
  },
  imagePreviewContainer: {
    marginBottom: 16,
    alignItems: 'center',
    backgroundColor: '#202c33',
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#2a3942',
  },
  imagePreview: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginTop: 4,
  },
  typingSubtitleText: {
    color: '#00a884',
    fontWeight: 'bold',
  },
  typingIndicatorRow: {
    flexDirection: 'row',
    marginVertical: 6,
    paddingHorizontal: 10,
    justifyContent: 'flex-start',
  },
  typingBubble: {
    backgroundColor: '#202c33',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 8,
    borderTopLeftRadius: 0,
  },
  typingBubbleText: {
    color: '#00a884',
    fontSize: 13,
    fontStyle: 'italic',
    fontWeight: '500',
  },
  typingIndicatorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 4,
    paddingTop: 4,
  },
  typingDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#00a884',
    marginHorizontal: 2.5,
  },
  typingBubbleUser: {
    color: '#34b7f1',
    fontSize: 11,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  editingBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1d2a32',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#00a884',
    borderTopWidth: 1,
    borderTopColor: '#202c33',
  },
  editingBannerTitle: {
    color: '#00a884',
    fontSize: 12,
    fontWeight: 'bold',
  },
  editingBannerText: {
    color: '#8696a0',
    fontSize: 13,
    marginTop: 2,
  },
  editingBannerClose: {
    padding: 6,
  },
  replyBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1d2a32',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#00a884',
    borderTopWidth: 1,
    borderTopColor: '#202c33',
  },
  replyBannerTitle: {
    color: '#00a884',
    fontSize: 12,
    fontWeight: 'bold',
  },
  replyBannerText: {
    color: '#8696a0',
    fontSize: 13,
    marginTop: 2,
  },
  replyBannerClose: {
    padding: 6,
  },
  bubbleReplyPreview: {
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    borderLeftWidth: 3,
    borderLeftColor: '#00a884',
    padding: 6,
    borderRadius: 4,
    marginBottom: 6,
    minWidth: 120,
  },
  bubbleReplySender: {
    color: '#00a884',
    fontSize: 11,
    fontWeight: 'bold',
  },
  bubbleReplyText: {
    color: '#d1d7db',
    fontSize: 12,
    marginTop: 2,
  },
  sheetOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  sheetContent: {
    backgroundColor: '#202c33',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingVertical: 12,
    paddingBottom: Platform.OS === 'ios' ? 30 : 16,
  },
  sheetHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#8696a0',
    alignSelf: 'center',
    marginBottom: 12,
  },
  sheetHeader: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderColor: 'rgba(134,150,160,0.1)',
    marginBottom: 8,
  },
  sheetHeaderText: {
    color: '#8696a0',
    fontSize: 13,
    fontStyle: 'italic',
  },
  sheetItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
  },
  sheetItemIcon: {
    marginRight: 15,
  },
  sheetItemText: {
    color: '#e9edef',
    fontSize: 15,
    fontWeight: '500',
  },
  msgAvatarContainer: {
    marginRight: 8,
    alignSelf: 'flex-end',
    marginBottom: 2,
  },
  msgAvatarContainerRight: {
    marginLeft: 8,
    alignSelf: 'flex-end',
    marginBottom: 2,
  },
  msgAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
  },
  msgAvatarPlaceholder: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  msgAvatarLetter: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  loadMoreBtn: {
    backgroundColor: '#202c33',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    alignSelf: 'center',
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#2a3942',
  },
  loadMoreBtnText: {
    color: '#00a884',
    fontSize: 13,
    fontWeight: 'bold',
  },
  recordingBarContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#202c33',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 8,
    minHeight: 48,
  },
  recordingTimerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  recordingDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#ef4444',
    marginRight: 8,
  },
  recordingTimerText: {
    color: '#e9edef',
    fontSize: 16,
    fontWeight: '600',
  },
  recordingControls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  recordingCancelBtn: {
    padding: 8,
    marginRight: 16,
  },
  recordingSendBtn: {
    backgroundColor: '#00a884',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  audioBubbleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 4,
    minWidth: 220,
  },
  audioPlayButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  audioProgressContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  audioProgressBarBackground: {
    height: 4,
    backgroundColor: 'rgba(134, 150, 160, 0.2)',
    borderRadius: 2,
    marginBottom: 4,
  },
  audioProgressBarFill: {
    height: 4,
    borderRadius: 2,
  },
  audioTimeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  audioTimeText: {
    color: 'rgba(233, 237, 239, 0.6)',
    fontSize: 10,
  },
  audioOut: {},
  audioIn: {},
  waveformContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 32,
    justifyContent: 'space-between',
    paddingHorizontal: 2,
    marginVertical: 4,
    width: 150,
  },
  waveformBar: {
    width: 3,
    borderRadius: 1.5,
    minHeight: 4,
  },
  recordingWaveform: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 32,
    marginLeft: 12,
  },
  recordingWaveformBar: {
    width: 3,
    backgroundColor: '#00a884',
    marginHorizontal: 1.5,
    borderRadius: 1.5,
    minHeight: 4,
  },
  bubbleHighlighted: {
    backgroundColor: '#0c8a6f',
    borderColor: '#00a884',
    borderWidth: 1.5,
  },
  imageMessageContainer: {
    width: 200,
    height: 150,
    borderRadius: 8,
    overflow: 'hidden',
    marginVertical: 4,
  },
  imageMessage: {
    width: '100%',
    height: '100%',
  },
  fileMessageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 8,
    backgroundColor: 'rgba(0,0,0,0.15)',
    marginVertical: 4,
    minWidth: 200,
    maxWidth: 240,
  },
  fileMessageTextContainer: {
    marginLeft: 10,
    flex: 1,
  },
  fileMessageName: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  fileMessageSize: {
    fontSize: 10,
    color: '#8696a0',
    marginTop: 2,
  },
  emojiPickerContainer: {
    height: 200,
    backgroundColor: '#111b21',
    borderTopWidth: 1,
    borderTopColor: '#222e35',
  },
  emojiGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 8,
    paddingVertical: 8,
    justifyContent: 'flex-start',
  },
  emojiButton: {
    width: '12.5%',
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emojiText: {
    fontSize: 24,
  },
  // Join Conversation container styles
  joinContainer: {
    backgroundColor: '#1f2c34',
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderTopWidth: 1,
    borderTopColor: '#2f3b43',
  },
  joinInfoText: {
    color: '#8696a0',
    fontSize: 14,
    marginBottom: 12,
    textAlign: 'center',
  },
  joinButton: {
    backgroundColor: '#00a884',
    paddingVertical: 10,
    paddingHorizontal: 24,
    borderRadius: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  joinButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
  },
  systemMessageWrapper: {
    marginVertical: 8,
    width: '100%',
  },
  systemMessageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    paddingHorizontal: 16,
  },
  systemMessageBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    maxWidth: '90%',
  },
  systemMessageBadgeGreen: {
    backgroundColor: 'rgba(0, 168, 132, 0.1)',
    borderColor: 'rgba(0, 168, 132, 0.2)',
  },
  systemMessageBadgeRed: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderColor: 'rgba(239, 68, 68, 0.2)',
  },
  systemMessageText: {
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  systemMessageTextGreen: {
    color: '#00a884',
  },
  systemMessageTextRed: {
    color: '#f87171',
  },
});
