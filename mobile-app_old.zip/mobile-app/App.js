import React, { useEffect } from 'react';
import { StyleSheet, ActivityIndicator, View, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import * as SecureStore from 'expo-secure-store';
import useAuthStore from './src/store/authStore';
import useChatStore from './src/store/chatStore';
import { initSocket, disconnectSocket } from './src/socket';
import { playSound } from './src/utils/sound';
import { API_URL } from './src/config';

// Screens
import LoginScreen from './src/screens/LoginScreen';
import HomeScreen from './src/screens/HomeScreen';
import ChatScreen from './src/screens/ChatScreen';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

if (Platform.OS !== 'web') {
  Notifications.setNotificationCategoryAsync('message_reply', [
    {
      identifier: 'reply_action',
      buttonTitle: 'Reply',
      options: {
        opensAppToForeground: false,
        isDestructive: false,
        isAuthenticationRequired: false,
      },
      textInput: {
        submitButtonTitle: 'Send',
        placeholder: 'Type your reply...',
      },
    },
  ]);
}

const Stack = createStackNavigator();

export default function App() {
  const user = useAuthStore((state) => state.user);
  const token = useAuthStore((state) => state.token);
  const isLoading = useAuthStore((state) => state.isLoading);
  const loadStoredSession = useAuthStore((state) => state.loadStoredSession);
  const setSessions = useChatStore((state) => state.setSessions);
  const addMessage = useChatStore((state) => state.addMessage);
  const prependMessages = useChatStore((state) => state.prependMessages);
  const setMessages = useChatStore((state) => state.setMessages);

  // Load session on startup
  useEffect(() => {
    loadStoredSession();
  }, []);

  // Handle Notification Action Response (Quick Reply)
  useEffect(() => {
    const subscription = Notifications.addNotificationResponseReceivedListener(async (response) => {
      const { actionIdentifier, userText, notification } = response;
      const sessionId = notification.request.content.data?.sessionId;

      if (actionIdentifier === 'reply_action' && userText && sessionId) {
        console.log('[NotificationResponse] Quick reply text:', userText, 'Session ID:', sessionId);
        const token = useAuthStore.getState().token;
        if (token) {
          try {
            const res = await fetch(`${API_URL}/api/auth/merchant/message`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
              },
              body: JSON.stringify({ sessionId, content: userText })
            });
            const resData = await res.json();
            console.log('[NotificationResponse] Quick reply send result:', resData);
          } catch (err) {
            console.error('[NotificationResponse] Quick reply REST send failed:', err);
          }
        }
      }
    });

    return () => subscription.remove();
  }, []);

  // Handle Registering Push Token to Backend
  useEffect(() => {
    if (!token || !user) return;

    async function setupPushToken() {
      console.log('[PushToken] Setup initiated for user ID:', user._id);
      try {
        const pushToken = await registerForPushNotificationsAsync();
        console.log('[PushToken] Generated Token:', pushToken);
        if (pushToken) {
          const res = await fetch(`${API_URL}/api/auth/merchant/push-token`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ token: pushToken })
          });
          const resData = await res.json();
          console.log('[PushToken] Backend register response:', resData);
          await SecureStore.setItemAsync('pushToken', pushToken);
          
          // Temporary success alert for debugging
          // import Alert from react-native is already done implicitly because of react-native imports
          const { Alert } = require('react-native');
          Alert.alert('Push Token Status', 'Successfully registered token: ' + pushToken.substring(0, 25) + '...');
        } else {
          console.warn('[PushToken] Generated token is empty, skipping registration.');
          const { Alert } = require('react-native');
          Alert.alert('Push Token Status', 'Failed to generate token from Expo (Token is empty).');
        }
      } catch (err) {
        console.error('[PushToken] Failed to register push token with backend:', err);
        const { Alert } = require('react-native');
        Alert.alert('Push Token Status', 'Registration Error: ' + err.message);
      }
    }

    setupPushToken();
  }, [token, user]);

  async function registerForPushNotificationsAsync() {
    let token;
    const { Alert } = require('react-native');
    
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    console.log('[PushToken] Permission status:', finalStatus);
    if (finalStatus !== 'granted') {
      console.warn('[PushToken] Permission not granted. Cannot fetch token.');
      Alert.alert('Notification Permission', 'Notification permissions are not granted. Please enable them in your phone settings.');
      return null;
    }
    
    try {
      const projectId = Constants.expoConfig?.extra?.eas?.projectId || Constants.easConfig?.projectId;
      console.log('[PushToken] EAS Project ID used:', projectId);
      if (!projectId) {
        Alert.alert('Config Error', 'EAS Project ID is undefined in app config!');
      }
      token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
    } catch (e) {
      console.error('[PushToken] Error fetching token from Expo:', e);
      Alert.alert('Expo Fetch Error', 'Failed to fetch push token: ' + e.message);
    }
    
    if (Platform.OS === 'android') {
      Notifications.setNotificationChannelAsync('default', {
        name: 'default',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#FF231F7C',
      });
    }

    return token;
  }

  // Listen to sockets when authenticated
  useEffect(() => {
    if (!token || !user) {
      disconnectSocket();
      return;
    }

    const socket = initSocket(user._id);

    socket.on('all_sessions', (allSessions) => {
      setSessions(allSessions);
    });

    socket.on('online_agents', (agentIds) => {
      useChatStore.getState().setOnlineAgents(agentIds);
    });

    socket.on('new_session', (session) => {
      const current = useChatStore.getState().sessions;
      setSessions([session, ...current.filter((s) => s._id !== session._id)]);
    });

    socket.on('session_updated', (updatedSession) => {
      const current = useChatStore.getState().sessions;
      const existing = current.find((s) => s._id === updatedSession._id);
      
      const isGroupOrDM = 
        updatedSession.isGroupChat === true || 
        updatedSession.isDirectMessage === true || 
        !!updatedSession.groupName || 
        updatedSession.widgetId === 'group_chat';
      
      const localUnread = isGroupOrDM && existing
        ? (existing.unreadCount || 0)
        : updatedSession.unreadCount;

      const mergedSession = { ...updatedSession, unreadCount: localUnread };
      setSessions([mergedSession, ...current.filter((s) => s._id !== updatedSession._id)]);
    });

    socket.on('session_deleted', ({ sessionId }) => {
      const current = useChatStore.getState().sessions;
      setSessions(current.filter((s) => s._id !== sessionId));
    });

    socket.on('receive_message', (msg) => {
      addMessage(msg.sessionId, msg);
      
      const activeSessionId = useChatStore.getState().activeSessionId;
      const isCurrentlyViewingThisSession = activeSessionId?.toString() === msg.sessionId?.toString();

      const isFromSomeoneElse =
        msg.sender === 'visitor' ||
        (msg.sender === 'merchant' && msg.senderId?.toString() !== user?._id?.toString());
      if (isFromSomeoneElse && !isCurrentlyViewingThisSession) {
        playSound('new_message');
        
        // Schedule immediate local OS notification
        Notifications.scheduleNotificationAsync({
          content: {
            title: msg.senderName || 'New Message',
            body: msg.content || 'Sent an attachment',
            data: { sessionId: msg.sessionId },
          },
          trigger: null,
        }).catch(err => console.log('Notification error:', err));
      }

      // Update last message in sessions list
      const currentSessions = useChatStore.getState().sessions;
      setSessions(
        currentSessions.map((s) => {
          if (s._id === msg.sessionId) {
            return {
              ...s,
              lastMessage: msg.content || 'Attachment',
              lastMessageAt: msg.timestamp || Date.now(),
              unreadCount: isFromSomeoneElse ? (s.unreadCount || 0) + 1 : s.unreadCount
            };
          }
          return s;
        })
      );
    });

    socket.on('message_updated', (updatedMsg) => {
      useChatStore.getState().updateMessage(updatedMsg.sessionId, updatedMsg);
    });

    socket.on('messages_status_updated', ({ sessionId, status }) => {
      useChatStore.setState((state) => {
        const current = state.messages[sessionId] || [];
        return {
          messages: {
            ...state.messages,
            [sessionId]: current.map((m) =>
              m.sender === 'merchant' && m.status !== 'read' ? { ...m, status } : m
            )
          }
        };
      });
    });

    socket.on('chat_history_merchant', ({ sessionId, messages, hasMore, isAppend }) => {
      if (isAppend) {
        prependMessages(sessionId, messages);
      } else {
        setMessages(sessionId, messages);
      }
      useChatStore.getState().setHasMore(sessionId, hasMore);
    });

    return () => {
      socket.off('all_sessions');
      socket.off('new_session');
      socket.off('session_updated');
      socket.off('session_deleted');
      socket.off('receive_message');
      socket.off('message_updated');
      socket.off('messages_status_updated');
      socket.off('chat_history_merchant');
      socket.off('online_agents');
    };
  }, [token, user]);

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#00a884" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#202c33', borderBottomWidth: 1, borderColor: '#2a3942' },
          headerTintColor: '#e9edef',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        {!token ? (
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        ) : (
          <>
            <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
            <Stack.Screen
              name="Chat"
              component={ChatScreen}
              options={({ route }) => ({ title: route.params.displayName })}
            />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    backgroundColor: '#111b21',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
