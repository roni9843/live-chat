const jwt = require("jsonwebtoken");
const Merchant = require("../models/Merchant");
const Admin = require("../models/Admin");

const protect = async (req, res, next) => {
  try {
    let token = null;

    const authorization = req.headers.authorization;

    if (
      authorization &&
      authorization.startsWith("Bearer ")
    ) {
      token = authorization.split(" ")[1];
    }

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Not authorized, no token",
      });
    }

    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET ||
      "your_super_secret_jwt_key_here"
    );

    // Dedicated admin token
    if (decoded.role === "admin") {
      const adminUser = await Admin.findById(decoded.id).select(
        "-password"
      );

      if (!adminUser) {
        return res.status(401).json({
          success: false,
          message: "Admin account not found",
        });
      }

      req.user = adminUser;
      req.authType = "admin";

      return next();
    }

    // Merchant token
    if (decoded.role === "merchant") {
      const merchant = await Merchant.findById(
        decoded.id
      ).select("-password");

      if (!merchant) {
        return res.status(401).json({
          success: false,
          message: "Merchant account not found",
        });
      }

      req.user = merchant;
      req.authType = "merchant";

      return next();
    }

    return res.status(401).json({
      success: false,
      message: "Invalid token role",
    });
  } catch (error) {
    console.error("Auth middleware error:", error);

    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        message: "Token expired. Please login again.",
      });
    }

    return res.status(401).json({
      success: false,
      message: "Not authorized, token failed",
      error: error.message,
    });
  }
};

const adminOnly = (req, res, next) => {
  const isDedicatedAdmin = req.authType === "admin";

  const isMerchantSuperAdmin =
    req.authType === "merchant" &&
    req.user?.role === "super_admin";

  if (isDedicatedAdmin || isMerchantSuperAdmin) {
    return next();
  }

  return res.status(403).json({
    success: false,
    message: "Admin access required",
    authType: req.authType || null,
    role: req.user?.role || null,
  });
};

// পুরোনো settingsRoutes.js-এ admin import আছে,
// তাই compatibility alias রাখা হচ্ছে।
const admin = adminOnly;

module.exports = {
  protect,
  admin,
  adminOnly,
};