const { Expo } = require('expo-server-sdk');
const Merchant = require('../models/Merchant');

const expo = new Expo();

/**
 * Sends push notifications to specified merchant IDs
 * @param {Array<string>} userIds - Recipient merchant database IDs
 * @param {string} title - Push Notification Title
 * @param {string} body - Push Notification Body
 * @param {object} data - Custom payload
 */
exports.sendPushNotifications = async (userIds, title, body, data = {}, options = {}) => {
  if (!userIds || userIds.length === 0) return;

  try {
    const merchants = await Merchant.find({ _id: { $in: userIds } }).select('pushTokens');
    
    let messages = [];
    let tokenToMerchantMap = {};

    for (const merchant of merchants) {
      if (!merchant.pushTokens || merchant.pushTokens.length === 0) continue;

      for (const token of merchant.pushTokens) {
        if (!Expo.isExpoPushToken(token)) {
          console.warn(`Push token ${token} is not a valid Expo push token`);
          continue;
        }

        const msgObj = {
          to: token,
          sound: 'default',
          title: title,
          body: body,
          data: data,
          priority: 'high',
          channelId: 'default',
        };

        if (options.categoryIdentifier) {
          msgObj.categoryIdentifier = options.categoryIdentifier;
        }
        if (options.android) {
          msgObj.android = options.android;
        }
        if (options.ios) {
          msgObj.ios = options.ios;
        }

        messages.push(msgObj);

        tokenToMerchantMap[token] = merchant;
      }
    }

    if (messages.length === 0) return;

    let chunks = expo.chunkPushNotifications(messages);
    let tickets = [];

    for (let chunk of chunks) {
      try {
        let ticketChunk = await expo.sendPushNotificationsAsync(chunk);
        tickets.push(...ticketChunk);
      } catch (error) {
        console.error('Error sending push chunk:', error);
      }
    }

    for (let i = 0; i < tickets.length; i++) {
      const ticket = tickets[i];
      const message = messages[i];
      
      if (ticket.status === 'error') {
        console.error(`Error sending to token ${message.to}:`, ticket.details);
        
        if (ticket.details && ticket.details.error === 'DeviceNotRegistered') {
          const merchant = tokenToMerchantMap[message.to];
          if (merchant) {
            merchant.pushTokens = merchant.pushTokens.filter(t => t !== message.to);
            await merchant.save();
            console.log(`Cleaned up inactive token ${message.to} for merchant ${merchant._id}`);
          }
        }
      }
    }
  } catch (err) {
    console.error('Error in sendPushNotifications helper:', err);
  }
};
