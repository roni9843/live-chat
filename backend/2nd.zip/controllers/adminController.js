const Merchant = require("../models/Merchant");
const ChatSession = require("../models/ChatSession");

exports.getAllUsers = async (req, res) => {
  try {
    const search = String(req.query.search || "").trim();
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(100, Math.max(1, Number(req.query.limit || 20)));

    const query = search
      ? {
        $or: [
          { name: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
          { "subscription.packageName": { $regex: search, $options: "i" } },
        ],
      }
      : {};

    const [users, total] = await Promise.all([
      Merchant.find(query)
        .select("-password")
        .populate("widgets.authorizedUsers.user", "name email profilePic")
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Merchant.countDocuments(query),
    ]);

    const usersWithMembership = await Promise.all(
      users.map(async (u) => {
        const uObj = u.toObject();
        const parentMerchant = await Merchant.findOne({
          _id: { $ne: u._id },
          "widgets.authorizedUsers.user": u._id
        }, "name email widgets");

        if (parentMerchant) {
          const widget = parentMerchant.widgets.find(w =>
            w.authorizedUsers.some(au => au.user && au.user.toString() === u._id.toString())
          );
          uObj.belongsTo = {
            merchantId: parentMerchant._id,
            merchantName: parentMerchant.name,
            merchantEmail: parentMerchant.email,
            widgetId: widget?._id,
            widgetName: widget?.companyName || "Unnamed Widget",
            widgetDomain: widget?.domain
          };
        } else {
          uObj.belongsTo = null;
        }
        return uObj;
      })
    );

    res.json({
      success: true,
      data: usersWithMembership,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const user = await Merchant.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (req.body.name !== undefined) user.name = req.body.name;
    if (req.body.email !== undefined) user.email = req.body.email;
    if (req.body.password !== undefined && req.body.password.trim() !== "") {
      const bcrypt = require("bcryptjs");
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(req.body.password, salt);
    }
    if (req.body.canCreateWidgets !== undefined) {
      user.canCreateWidgets = Boolean(req.body.canCreateWidgets);
    }
    if (req.body.widgets !== undefined) {
      user.widgets = req.body.widgets;
    }

    if (
      req.body.role &&
      ["super_admin", "user"].includes(req.body.role)
    ) {
      user.role = req.body.role;
    }

    const updatedUser = await user.save();
    res.json({ success: true, data: updatedUser });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const user = await Merchant.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    await user.deleteOne();
    res.json({ success: true, message: "User removed" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

exports.getUserById = async (req, res) => {
  try {
    const user = await Merchant.findById(req.params.id)
      .select("-password")
      .populate("widgets.authorizedUsers.user", "name email profilePic");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const sessions = await ChatSession.find({ merchantId: req.params.id })
      .sort({ lastMessageAt: -1 })
      .populate("assignedAgent", "name email");

    const parentMerchant = await Merchant.findOne({
      _id: { $ne: user._id },
      "widgets.authorizedUsers.user": user._id
    }, "name email widgets");

    let belongsTo = null;
    if (parentMerchant) {
      const widget = parentMerchant.widgets.find(w =>
        w.authorizedUsers.some(au => au.user && au.user.toString() === user._id.toString())
      );
      belongsTo = {
        merchantId: parentMerchant._id,
        merchantName: parentMerchant.name,
        merchantEmail: parentMerchant.email,
        widgetId: widget?._id,
        widgetName: widget?.companyName || "Unnamed Widget",
        widgetDomain: widget?.domain
      };
    }

    res.json({ success: true, data: user, sessions, belongsTo });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

exports.getSessionMessages = async (req, res) => {
  try {
    const Message = require("../models/Message");
    const messages = await Message.find({ sessionId: req.params.sessionId }).sort({ timestamp: 1 });
    res.json({ success: true, data: messages });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
