const express = require("express");
const router = express.Router();

const {
  getAllUsers,
  updateUser,
  deleteUser,
  getUserById,
  getSessionMessages,
} = require("../controllers/adminController");

const {
  protect,
  adminOnly,
} = require("../middleware/authMiddleware");

// সব admin route-এর জন্য প্রথমে token,
// তারপর admin permission check হবে।
router.use(protect);
router.use(adminOnly);

router.get("/users", getAllUsers);

router
  .route("/users/:id")
  .get(getUserById)
  .put(updateUser)
  .delete(deleteUser);

router.get("/sessions/:sessionId/messages", getSessionMessages);

module.exports = router;