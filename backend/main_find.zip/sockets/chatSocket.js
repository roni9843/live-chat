const mongoose = require('mongoose');
const ChatSession = require('../models/ChatSession');
const Message = require('../models/Message');
const Merchant = require('../models/Merchant');

const sessionViewers = {}; // sessionId -> { socketId: { agentId, name, profilePic } }
const connectedAgents = new Set();

module.exports = (io, app) => {
  if (app) app.set('connectedAgents', connectedAgents);

  // Auto re-open any closed group chats or DMs (fix legacy closed sessions)
  ChatSession.updateMany(
    { 
      status: 'closed', 
      $or: [
        { isGroupChat: true }, 
        { isDirectMessage: true }, 
        { widgetId: 'group_chat' }
      ] 
    },
    { $set: { status: 'active' } }
  ).catch(err => console.error('Error auto-activating legacy group/DM sessions:', err));

  // Background job to clean up inactive sessions (10 minutes inactivity timeout)
  // ONLY client/visitor sessions should end, all group chats and DMs should remain active indefinitely.
  setInterval(async () => {
    const INACTIVITY_TIMEOUT = 10 * 60 * 1000; // 10 minutes
    const thresholdTime = new Date(Date.now() - INACTIVITY_TIMEOUT);
    
    try {
      // Find active sessions that have been inactive for more than 10 minutes
      const inactiveSessions = await ChatSession.find({
        status: 'active',
        isDirectMessage: { $ne: true },
        isGroupChat: { $ne: true },
        widgetId: { $ne: 'group_chat' },
        groupName: null,
        $and: [
          {
            $or: [
              { dmParticipants: { $exists: false } },
              { dmParticipants: { $size: 0 } }
            ]
          },
          {
            $or: [
              { lastMessageAt: { $lt: thresholdTime } },
              { lastMessageAt: { $exists: false }, createdAt: { $lt: thresholdTime } }
            ]
          }
        ]
      });
      
      for (const session of inactiveSessions) {
        await closeSessionHelper(session);
      }
    } catch (err) {
      console.error('Error in session cleanup job:', err);
    }
  }, 60 * 1000); // Check every 1 minute

  const cleanupViewing = (sk) => {
    const prevSessionId = sk.viewingSessionId;
    if (prevSessionId && sessionViewers[prevSessionId]) {
      delete sessionViewers[prevSessionId][sk.id];
      if (Object.keys(sessionViewers[prevSessionId]).length === 0) {
        delete sessionViewers[prevSessionId];
      }
      sk.leave(`session_${prevSessionId}`);
      sk.viewingSessionId = null;
      sendActiveViewersUpdate(prevSessionId);
    }
  };

  const sendActiveViewersUpdate = (sessionId) => {
    const viewersMap = sessionViewers[sessionId] || {};
    const uniqueAgents = [];
    const seenIds = new Set();
    
    Object.values(viewersMap).forEach(agent => {
      if (agent.agentId && !seenIds.has(agent.agentId.toString())) {
        seenIds.add(agent.agentId.toString());
        uniqueAgents.push(agent);
      }
    });

    io.to(`session_${sessionId}`).emit('active_viewers_updated', uniqueAgents);
  };

  const notifyMerchants = async (merchantId, sessionId, eventName, eventData) => {
    if (!merchantId) return;
    
    try {
      const session = await ChatSession.findById(sessionId);
      
      if (session && (session.isDirectMessage || session.isGroupChat)) {
        const pIds = new Set();
        if (session.participants) {
          session.participants.forEach(pId => pIds.add(pId.toString()));
        }
        if (session.dmParticipants) {
          session.dmParticipants.forEach(p => {
            const pId = p.userId || p.user;
            if (pId) pIds.add(pId.toString());
          });
        }
        pIds.forEach(pId => io.to(pId).emit(eventName, eventData));
        return;
      }

      io.to(merchantId.toString()).emit(eventName, eventData);

      if (session && session.widgetId && mongoose.Types.ObjectId.isValid(session.widgetId)) {
        const owner = await Merchant.findById(merchantId);
        if (owner) {
          const widget = owner.widgets.id(session.widgetId);
          if (widget && widget.authorizedUsers) {
            widget.authorizedUsers.forEach(au => {
              const uid = au.user ? au.user.toString() : au.toString();
              io.to(uid).emit(eventName, eventData);
            });
          }
        }
      }
    } catch (err) {
      console.error('Error in notifyMerchants:', err);
    }
  };

  const closeSessionHelper = async (session) => {
    try {
      console.log(`[Session Close Attempt] ID: ${session._id}, visitorName: ${session.visitorName}, isGroupChat: ${session.isGroupChat}, widgetId: ${session.widgetId}, groupName: ${session.groupName}`);
      if (
        session.isGroupChat || 
        session.isDirectMessage || 
        session.widgetId === 'group_chat' || 
        session.groupName || 
        (session.dmParticipants && session.dmParticipants.length > 0) ||
        (session.participants && session.participants.length > 0)
      ) {
        console.log(`[Session Close Skipped] Protected Group/DM Session: ${session._id}`);
        return;
      }
      session.status = 'closed';
      session.lastMessage = 'This chat session has ended.';
      session.lastMessageAt = Date.now();
      await session.save();

      const systemMsg = await Message.create({
        sessionId: session._id,
        sender: 'system',
        content: 'This chat session has ended.',
        status: 'read'
      });

      await notifyMerchants(session.merchantId, session._id, 'receive_message', systemMsg);
      await notifyMerchants(session.merchantId, session._id, 'session_updated', session);

      io.to(`session_${session._id}`).emit('receive_message', systemMsg);
      io.to(`session_${session._id}`).emit('session_closed', { sessionId: session._id });
    } catch (err) {
      console.error('Error in closeSessionHelper:', err);
    }
  };

  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    // Merchant joins their own room to listen to all their chats
    socket.on('merchant_join', async (merchantId) => {
      socket.merchantId = merchantId;
      connectedAgents.add(merchantId.toString());
      socket.join(merchantId.toString());
      io.emit('online_agents', Array.from(connectedAgents));
      console.log(`Merchant ${merchantId} joined room`);
      try {
        const merchantUser = await Merchant.findById(merchantId);
        const ownWidgets = merchantUser ? merchantUser.widgets.map(w => w._id.toString()) : [];

        const ownersWithAccess = await Merchant.find({ 'widgets.authorizedUsers.user': merchantId });
        let accessibleWidgets = [...ownWidgets];
        
        ownersWithAccess.forEach(owner => {
          owner.widgets.forEach(w => {
            if (w.authorizedUsers.some(au => au.user.toString() === merchantId)) {
              accessibleWidgets.push(w._id.toString());
            }
          });
        });

        // Send all sessions to merchant
        const sessions = await ChatSession.find({
          $or: [
            { merchantId },
            { widgetId: { $in: accessibleWidgets } },
            { participants: merchantId }
          ]
        }).sort({ lastMessageAt: -1 });
        socket.emit('all_sessions', sessions);
      } catch (err) {
        console.error('Error fetching sessions', err);
      }
    });

    // Merchant fetches chat history for a specific session
    socket.on('get_chat_history', async (params) => {
      try {
        let sessionId;
        let before;
        if (typeof params === 'string') {
          sessionId = params;
        } else {
          sessionId = params.sessionId;
          before = params.before;
        }
        
        if (!mongoose.Types.ObjectId.isValid(sessionId)) {
          return;
        }
        const query = { sessionId: new mongoose.Types.ObjectId(sessionId) };
        if (before) {
          query.timestamp = { $lt: new Date(before) };
        }
        const limit = 15;
        const messages = await Message.find(query)
          .sort({ timestamp: -1 })
          .limit(limit);
        
        messages.reverse();
        
        socket.emit('chat_history_merchant', { 
          sessionId, 
          messages, 
          hasMore: messages.length === limit,
          isAppend: !!before
        });
      } catch (err) {
        console.error('Error fetching chat history', err);
      }
    });

    socket.on('visitor_join', async ({ merchantId, visitorId, visitorDomain, visitorPath, widgetId, companyName, visitorName: vName, visitorEmail, visitorPhone, visitorDetails }) => {
      try {
        let session = await ChatSession.findOne({ merchantId, visitorId, status: 'active' });
        
        const INACTIVITY_TIMEOUT = 10 * 60 * 1000; // 10 minutes
        if (session) {
          const lastActive = session.lastMessageAt || session.createdAt;
          if (Date.now() - new Date(lastActive).getTime() > INACTIVITY_TIMEOUT) {
            await closeSessionHelper(session);
            session = null;
          }
        }

        if (!session) {
          const { isSubscriptionActive } = require('../utils/subscription');
          const merchantUser = await Merchant.findOne({ "widgets._id": widgetId })
            .populate('widgets.authorizedUsers.user', 'name profilePic status schedule');

          if (!merchantUser || !isSubscriptionActive(merchantUser)) {
            console.log(`Blocked session creation for visitor ${visitorId} because merchant subscription is inactive/expired`);
            socket.emit('subscription_expired_state', { expired: true });
            return;
          }

          // Check if widget is online before creating a new session
          const widgetObj = merchantUser.widgets.id(widgetId);
          if (widgetObj) {
            const isOwnerConnected = connectedAgents.has(merchantUser._id.toString());
            const isAnyAgentConnected = widgetObj.authorizedUsers?.some(au => au.user && connectedAgents.has(au.user._id.toString())) || false;
            const isAgentConnected = isOwnerConnected || isAnyAgentConnected;

              let isWidgetOnline = false;
              const widgetStatus = widgetObj.status || 'online';
              if (widgetStatus === 'online') {
                if (widgetObj.schedule && widgetObj.schedule.enabled) {
                  const now = new Date();
                  const currentHour = now.getHours().toString().padStart(2, '0');
                  const currentMinute = now.getMinutes().toString().padStart(2, '0');
                  const currentTimeString = `${currentHour}:${currentMinute}`;
                  
                  const { start, end } = widgetObj.schedule;
                  if (start && end) {
                    if (start <= end) {
                      if (currentTimeString >= start && currentTimeString <= end) {
                        isWidgetOnline = true;
                      }
                    } else {
                      if (currentTimeString >= start || currentTimeString <= end) {
                        isWidgetOnline = true;
                      }
                    }
                  } else {
                    isWidgetOnline = true;
                  }
                } else {
                  isWidgetOnline = true;
                }
              }

              if (!isWidgetOnline) {
                console.log(`Blocked session creation for visitor ${visitorId} because widget ${widgetId} is offline`);
                socket.emit('widget_offline_state', { offline: true });
                return;
              }
            }

          // Generate a unique 4 character alphanumeric string
          const randomId = Math.random().toString(36).substring(2, 6);
          
          session = await ChatSession.create({
            merchantId,
            widgetId,
            source: companyName || 'Website',
            visitorId,
            visitorName: vName || `Guest ${randomId}`,
            visitorEmail: visitorEmail || '',
            visitorPhone: visitorPhone || '',
            visitorDetails: visitorDetails || '',
            visitorDomain: visitorDomain || 'Unknown',
            visitorPath: visitorPath || '/',
            visitorStatus: 'online'
          });

          // Trigger push notifications to all authorized agents/admin for this new session
          (async () => {
            try {
              const { sendPushNotifications } = require('../utils/pushNotifications');
              const owner = await Merchant.findById(merchantId);
              if (owner) {
                const recipients = [owner._id.toString()];
                const widget = owner.widgets.id(widgetId);
                if (widget && widget.authorizedUsers) {
                  widget.authorizedUsers.forEach(au => {
                    const uid = au.user ? au.user.toString() : au.toString();
                    if (uid) recipients.push(uid);
                  });
                }
                const uniqueRecipients = [...new Set(recipients)];
                const title = `New Chat Session: ${session.visitorName}`;
                const body = `New visitor has come, do you want to chat?`;
                const avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(session.visitorName)}&background=00a884&color=fff&rounded=true`;

                 await sendPushNotifications(
                   uniqueRecipients,
                   title,
                   body,
                   { 
                     sessionId: session._id.toString(), 
                     soundType: "default", 
                     screen: "chat",
                     visitorName: session.visitorName || '',
                     visitorEmail: session.visitorEmail || '',
                     visitorPhone: session.visitorPhone || '',
                     visitorDomain: session.visitorDomain || '',
                     visitorPath: session.visitorPath || '',
                     isUnassigned: "false"
                   },
                   {
                     categoryIdentifier: 'message_reply',
                     android: { largeIcon: avatarUrl },
                     ios: { attachments: [{ url: avatarUrl }] }
                   }
                 );
              }
            } catch (err) {
              console.error('Error sending new session push notification:', err);
            }
          })();
        } else {
          session.visitorStatus = 'online';
          session.isOfflineLead = false; // Reset offline lead status as they are now active
          if (visitorDomain) session.visitorDomain = visitorDomain;
          if (visitorPath) session.visitorPath = visitorPath;
          if (vName) session.visitorName = vName;
          if (visitorEmail) session.visitorEmail = visitorEmail;
          if (visitorPhone) session.visitorPhone = visitorPhone;
          if (visitorDetails) session.visitorDetails = visitorDetails;
          await session.save();
        }

        const roomName = `session_${session._id}`;
        socket.join(roomName);
        socket.sessionId = session._id;
        socket.merchantId = merchantId;
        console.log(`Visitor ${visitorId} joined room ${roomName}`);

        // Notify merchant
        await notifyMerchants(merchantId, session._id, 'new_session', session);

        // Send chat history to visitor
        const messages = await Message.find({ sessionId: session._id }).sort({ timestamp: 1 });
        socket.emit('chat_history', { sessionId: session._id, messages, session });
        
        // Send active viewing agents list to visitor
        sendActiveViewersUpdate(session._id);
      } catch (err) {
        console.error('Error on visitor join', err);
      }
    });

    // Handle incoming messages
    socket.on('send_message', async ({ sessionId, sender, content, merchantId, fileUrl, fileType, replyTo, senderId, senderName, senderProfilePic, tempId }) => {
      try {
        const sessionObj = await ChatSession.findById(sessionId);
        if (!sessionObj || sessionObj.status === 'closed') {
          console.log(`Blocked message sending to closed/missing session: ${sessionId}`);
          return;
        }

        if (sender === 'merchant') {
          const isDMorGroup = sessionObj.isDirectMessage || sessionObj.isGroupChat || sessionObj.widgetId === 'group_chat';
          if (!isDMorGroup && sessionObj.assignedAgent && sessionObj.assignedAgent.toString() !== senderId.toString()) {
            console.log(`Blocked message: Agent ${senderId} is not assigned to session ${sessionId}`);
            return;
          }
        }

        const message = await Message.create({
          sessionId,
          sender,
          content,
          fileUrl,
          fileType,
          replyTo,
          senderId,
          senderName,
          senderProfilePic
        });

        const updateData = {
          lastMessageAt: Date.now(),
          lastMessage: content
        };
        
        // Increment unread count for visitor messages, direct messages, and group chats
        if (sender === 'visitor' || sessionObj.isDirectMessage || sessionObj.isGroupChat) {
          updateData.$inc = { unreadCount: 1 };
          if (sender === 'visitor') {
            updateData.isOfflineLead = false;
          }
        }

        const session = await ChatSession.findByIdAndUpdate(
          sessionId, 
          updateData, 
          { returnDocument: 'after' }
        );
        
        const roomName = `session_${sessionId}`;
        
        const msgJson = message.toJSON();
        if (tempId) {
          msgJson.tempId = tempId;
        }

        // Broadcast to the specific session room (for visitor, bypass for DM/Group)
        const isDMorGroup = sessionObj.isDirectMessage || sessionObj.isGroupChat || sessionObj.widgetId === 'group_chat';
        if (!isDMorGroup) {
          io.to(roomName).emit('receive_message', msgJson);
        }
        
        // Broadcast to the merchant's global room to update sidebar and chat area
        if (merchantId) {
          await notifyMerchants(merchantId, sessionId, 'receive_message', msgJson);
          await notifyMerchants(merchantId, sessionId, 'session_updated', session);
        }

        // Send remote push notifications to offline or background agents
        (async () => {
          try {
            const viewersMap = sessionViewers[sessionId] || {};
            const activeAgentIds = new Set(
              Object.values(viewersMap)
                .map(v => v.agentId ? v.agentId.toString() : null)
                .filter(Boolean)
            );

            const isViewing = (agentId) => {
              if (!sessionViewers[sessionId]) return false;
              return Object.values(sessionViewers[sessionId]).some(
                viewer => viewer.agentId && viewer.agentId.toString() === agentId.toString()
              );
            };

            let recipients = [];

            if (sender === 'visitor') {
              const ownerId = sessionObj.merchantId;
              if (ownerId && !isViewing(ownerId)) {
                recipients.push(ownerId.toString());
              }

              const owner = await Merchant.findById(ownerId);
              if (owner && sessionObj.widgetId) {
                const widget = owner.widgets.id(sessionObj.widgetId);
                if (widget && widget.authorizedUsers) {
                  widget.authorizedUsers.forEach(au => {
                    const uid = au.user ? au.user.toString() : au.toString();
                    if (uid && !isViewing(uid)) {
                      recipients.push(uid.toString());
                    }
                  });
                }
              }
            } else if (sender === 'merchant') {
              if (sessionObj.isDirectMessage || sessionObj.isGroupChat) {
                if (sessionObj.participants) {
                  sessionObj.participants.forEach(pId => {
                    if (pId && pId.toString() !== senderId.toString() && !isViewing(pId)) {
                      recipients.push(pId.toString());
                    }
                  });
                }
                if (sessionObj.dmParticipants) {
                  sessionObj.dmParticipants.forEach(p => {
                    const pId = p.userId || p.user || p;
                    if (pId && pId.toString() !== senderId.toString() && !isViewing(pId)) {
                      recipients.push(pId.toString());
                    }
                  });
                }
              }
            }

            recipients = [...new Set(recipients)];

            if (recipients.length > 0) {
              const { sendPushNotifications } = require('../utils/pushNotifications');
              const isGroup = sessionObj.isGroupChat === true || !!sessionObj.groupName || sessionObj.widgetId === 'group_chat';
              let notificationTitle = sender === 'visitor' ? (sessionObj.visitorName || 'New Visitor Message') : (senderName || 'New Message');
              let notificationBody = content || 'Sent an attachment';
              let avatarUrl = '';

              const resolveFileUrl = (url) => {
                if (!url) return '';
                const API_URL = process.env.API_URL || 'http://localhost:5000';
                if (url.startsWith('http')) return url;
                if (url.startsWith('/')) return `${API_URL}${url}`;
                return `${API_URL}/${url}`;
              };

              if (isGroup) {
                notificationTitle = sessionObj.groupName || 'Group Chat';
                notificationBody = `${senderName}: ${content || 'Sent an attachment'}`;
                if (sessionObj.groupImage) {
                  avatarUrl = resolveFileUrl(sessionObj.groupImage);
                }
              } else {
                if (sender === 'visitor') {
                  avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(sessionObj.visitorName || 'G')}&background=00a884&color=fff&rounded=true`;
                } else if (senderProfilePic) {
                  avatarUrl = resolveFileUrl(senderProfilePic);
                }
              }

              const pushOptions = {
                categoryIdentifier: 'message_reply',
              };

              if (avatarUrl) {
                pushOptions.android = {
                  largeIcon: avatarUrl,
                };
                pushOptions.ios = {
                  attachments: [
                    {
                      url: avatarUrl,
                    }
                  ]
                };
              }
              
              await sendPushNotifications(
                recipients,
                notificationTitle,
                notificationBody,
                { 
                  sessionId: sessionId.toString(),
                  soundType: 'default',
                  screen: 'chat',
                  visitorName: sessionObj.visitorName || '',
                  visitorEmail: sessionObj.visitorEmail || '',
                  visitorPhone: sessionObj.visitorPhone || '',
                  visitorDomain: sessionObj.visitorDomain || '',
                  visitorPath: sessionObj.visitorPath || '',
                  isUnassigned: (!sessionObj.assignedAgent).toString()
                },
                pushOptions
              );
            }
          } catch (err) {
            console.error('Error triggering push notifications:', err);
          }
        })();

      } catch (err) {
        console.error('Error saving message', err);
      }
    });

    // Join / Enroll in chat session
    socket.on('join_session', async ({ sessionId, agentId, agentName, merchantId }) => {
      try {
        const session = await ChatSession.findById(sessionId);
        if (!session) return;

        // Assign the agent
        session.assignedAgent = agentId;
        session.assignedAgentName = agentName;
        await session.save();

        // Create a system message: "Agent [Name] joined the conversation"
        const systemMsg = await Message.create({
          sessionId: session._id,
          sender: 'system',
          content: `${agentName} joined the conversation`,
          status: 'read'
        });

        const roomName = `session_${sessionId}`;
        
        // Broadcast to visitor and other participants in the room
        io.to(roomName).emit('receive_message', systemMsg);
        io.to(roomName).emit('session_updated', session);
        
        // Notify all merchants/agents that the session was updated and a message was received
        const targetMerchantId = merchantId || session.merchantId;
        if (targetMerchantId) {
          await notifyMerchants(targetMerchantId, sessionId, 'receive_message', systemMsg);
          await notifyMerchants(targetMerchantId, sessionId, 'session_updated', session);
        }
      } catch (err) {
        console.error('Error joining session:', err);
      }
    });

    // Leave / Unassign chat session
    socket.on('leave_session', async ({ sessionId, agentName, merchantId }) => {
      try {
        const session = await ChatSession.findById(sessionId);
        if (!session) return;

        session.assignedAgent = null;
        session.assignedAgentName = null;
        await session.save();

        const systemMsg = await Message.create({
          sessionId: session._id,
          sender: 'system',
          content: `${agentName} left the conversation`,
          status: 'read'
        });

        const roomName = `session_${sessionId}`;
        io.to(roomName).emit('receive_message', systemMsg);

        const targetMerchantId = merchantId || session.merchantId;
        if (targetMerchantId) {
          await notifyMerchants(targetMerchantId, sessionId, 'receive_message', systemMsg);
          await notifyMerchants(targetMerchantId, sessionId, 'session_updated', session);
        }
      } catch (err) {
        console.error('Error leaving session:', err);
      }
    });

    // Mark session as read
    socket.on('mark_as_read', async ({ sessionId, merchantId }) => {
      try {
        const session = await ChatSession.findByIdAndUpdate(sessionId, { unreadCount: 0 }, { new: true });
        if (merchantId) {
          await notifyMerchants(merchantId, sessionId, 'session_updated', session);
        }
      } catch (err) {
        console.error('Error marking as read', err);
      }
    });

    // Edit message
    socket.on('edit_message', async ({ messageId, newContent, sessionId, merchantId }) => {
      try {
        const message = await Message.findByIdAndUpdate(
          messageId, 
          { content: newContent, isEdited: true },
          { new: true }
        );
        const roomName = `session_${sessionId}`;
        io.to(roomName).emit('message_updated', message);
        if (merchantId) await notifyMerchants(merchantId, sessionId, 'message_updated', message);
      } catch (err) {
        console.error('Error editing message', err);
      }
    });

    // Delete message
    socket.on('delete_message', async ({ messageId, sessionId, merchantId }) => {
      try {
        const message = await Message.findByIdAndUpdate(
          messageId,
          { content: 'This message was deleted', isDeleted: true },
          { new: true }
        );
        const roomName = `session_${sessionId}`;
        io.to(roomName).emit('message_updated', message);
        if (merchantId) await notifyMerchants(merchantId, sessionId, 'message_updated', message);
      } catch (err) {
        console.error('Error deleting message', err);
      }
    });

    // Message status update (delivered / read)
    socket.on('messages_status_update', async ({ sessionId, status, merchantId }) => {
      try {
        // Update merchant's messages to 'delivered' or 'read'
        await Message.updateMany(
          { sessionId, sender: 'merchant', status: { $ne: 'read' } },
          { status }
        );
        const roomName = `session_${sessionId}`;
        io.to(roomName).emit('messages_status_updated', { sessionId, status });
        if (merchantId) await notifyMerchants(merchantId, sessionId, 'messages_status_updated', { sessionId, status });
      } catch (err) {
        console.error('Error updating message status', err);
      }
    });

    // Widget state change
    socket.on('widget_state_change', async ({ sessionId, state, merchantId }) => {
      try {
        const session = await ChatSession.findByIdAndUpdate(
          sessionId,
          { visitorStatus: state },
          { new: true }
        );
        if (merchantId) {
          await notifyMerchants(merchantId, sessionId, 'session_updated', session);
        }
      } catch (err) {
        console.error('Error updating widget state', err);
      }
    });

    // Update visitor's current path/page location
    socket.on('visitor_path_update', async ({ sessionId, visitorPath, merchantId }) => {
      try {
        const session = await ChatSession.findByIdAndUpdate(
          sessionId,
          { visitorPath: visitorPath || '/' },
          { new: true }
        );
        if (session && merchantId) {
          await notifyMerchants(merchantId, sessionId, 'session_updated', session);
        }
      } catch (err) {
        console.error('Error updating visitor path', err);
      }
    });

    // Typing indicators
    socket.on('typing_start', async ({ sessionId, sender, merchantId, senderName, senderProfilePic }) => {
      try {
        const sessionObj = await ChatSession.findById(sessionId);
        if (!sessionObj || sessionObj.status === 'closed') return;

        const roomName = `session_${sessionId}`;
        const sId = sender === 'visitor' ? sessionObj.visitorId : (merchantId || socket.merchantId);
        // Broadcast to visitor
        io.to(roomName).emit('typing_start', { sessionId, sender, senderName, senderProfilePic, senderId: sId });
        // Broadcast to merchant
        if (merchantId) await notifyMerchants(merchantId, sessionId, 'typing_start', { sessionId, sender, senderName, senderProfilePic, senderId: sId });
      } catch (err) {
        console.error('Error typing_start', err);
      }
    });

    socket.on('typing_end', async ({ sessionId, sender, merchantId }) => {
      try {
        const sessionObj = await ChatSession.findById(sessionId);
        if (!sessionObj || sessionObj.status === 'closed') return;

        const roomName = `session_${sessionId}`;
        const sId = sender === 'visitor' ? sessionObj.visitorId : (merchantId || socket.merchantId);
        io.to(roomName).emit('typing_end', { sessionId, sender, senderId: sId });
        if (merchantId) await notifyMerchants(merchantId, sessionId, 'typing_end', { sessionId, sender, senderId: sId });
      } catch (err) {
        console.error('Error typing_end', err);
      }
    });

    // Agent starts/stops viewing a specific session actively
    socket.on('agent_viewing_session', ({ sessionId, name, profilePic, agentId }) => {
      cleanupViewing(socket);
      if (sessionId) {
        socket.viewingSessionId = sessionId;
        socket.agentInfo = { agentId, name, profilePic };
        socket.join(`session_${sessionId}`);
        
        if (!sessionViewers[sessionId]) {
          sessionViewers[sessionId] = {};
        }
        sessionViewers[sessionId][socket.id] = { agentId, name, profilePic };
        sendActiveViewersUpdate(sessionId);
      }
    });

    // Close session
    socket.on('close_session', async ({ sessionId }) => {
      try {
        const session = await ChatSession.findById(sessionId);
        if (session && session.status !== 'closed') {
          if (
            session.isDirectMessage === true || 
            session.isGroupChat === true || 
            session.widgetId === 'group_chat' || 
            !!session.groupName || 
            (session.dmParticipants && session.dmParticipants.length > 0)
          ) {
            return;
          }
          await closeSessionHelper(session);
        }
      } catch (err) {
        console.error('Error closing session', err);
      }
    });

    // Delete session
    socket.on('delete_session', async ({ sessionId, merchantId, password }) => {
      try {
        const session = await ChatSession.findById(sessionId);
        if (!session) return;

        // If it's a group chat, verify admin privileges and password
        const isGroup = session.isGroupChat === true || !!session.groupName || session.widgetId === 'group_chat';
        if (isGroup) {
          const participant = session.dmParticipants?.find(p => p.userId?.toString() === merchantId?.toString());
          if (!participant || participant.role !== 'admin') {
            socket.emit('delete_session_error', { sessionId, message: 'Only group admins can delete this group.' });
            return;
          }

          const Merchant = require('../models/Merchant');
          const bcrypt = require('bcryptjs');
          const merchant = await Merchant.findById(merchantId);
          if (!merchant || !(await bcrypt.compare(password, merchant.password))) {
            socket.emit('delete_session_error', { sessionId, message: 'Incorrect password. Deletion cancelled.' });
            return;
          }
        }
        
        await Message.deleteMany({ sessionId });
        await ChatSession.findByIdAndDelete(sessionId);
        
        const roomName = `session_${sessionId}`;
        io.to(roomName).emit('session_deleted', { sessionId });
        
        if (session.isDirectMessage || session.isGroupChat) {
          if (session.participants) {
            session.participants.forEach(pId => io.to(pId.toString()).emit('session_deleted', { sessionId }));
          }
        } else {
          if (merchantId) {
             io.to(merchantId.toString()).emit('session_deleted', { sessionId });
          }
          if (session.widgetId && mongoose.Types.ObjectId.isValid(session.widgetId)) {
            const owner = await Merchant.findById(session.merchantId);
            if (owner) {
              const widget = owner.widgets.id(session.widgetId);
              if (widget && widget.authorizedUsers) {
                widget.authorizedUsers.forEach(au => {
                  const uid = au.user ? au.user.toString() : au.toString();
                  io.to(uid).emit('session_deleted', { sessionId });
                });
              }
            }
          }
        }
      } catch (err) {
        console.error('Error deleting session', err);
      }
    });

    // WebRTC calling events
    socket.on('call_request', async ({ sessionId, callerName, callerType }) => {
      try {
        const session = await ChatSession.findById(sessionId);
        if (!session || session.status === 'closed') return;

        const roomName = `session_${sessionId}`;

        if (session.isGroupChat) {
          if (session.participants) {
            session.participants.forEach(pId => {
              if (pId.toString() !== socket.merchantId?.toString()) {
                io.to(pId.toString()).emit('incoming_call', {
                  sessionId,
                  callerName,
                  callerType: 'merchant',
                  isGroupCall: true,
                  callerId: socket.merchantId
                });
              }
            });
          }
          return;
        }

        if (callerType === 'visitor') {
          // If visitor calls, notify the merchant room globally so the agent gets it anywhere.
          // Agents viewing the chat are also listening to the merchant room, so this avoids duplicate event delivery.
          if (session.merchantId) {
            await notifyMerchants(session.merchantId, sessionId, 'incoming_call', {
              sessionId,
              callerName,
              callerType,
              visitorName: session.visitorName
            });
          }
        } else {
          // If merchant calls, broadcast incoming call to the visitor in the session room
          socket.to(roomName).emit('incoming_call', {
            sessionId,
            callerName,
            callerType,
            visitorName: session.visitorName
          });
        }
      } catch (err) {
        console.error('Error in call_request socket event:', err);
      }
    });


    socket.on('call_accept', async ({ sessionId, joinerId, joinerName }) => {
      try {
        const session = await ChatSession.findById(sessionId);
        if (session && session.isGroupChat) {
          socket.to(`session_${sessionId}`).emit('group_call_joined', { sessionId, joinerId, joinerName });
        } else {
          socket.to(`session_${sessionId}`).emit('call_accepted', { sessionId });
        }
      } catch (err) {
        console.error(err);
      }
    });

    socket.on('call_reject', async ({ sessionId, reason, rejecterId }) => {
      try {
        const session = await ChatSession.findById(sessionId);
        if (session && session.isGroupChat) {
          socket.to(`session_${sessionId}`).emit('group_call_rejected', { sessionId, reason, rejecterId });
        } else {
          socket.to(`session_${sessionId}`).emit('call_rejected', { sessionId, reason });
          if (socket.merchantId) {
            io.to(socket.merchantId.toString()).emit('call_rejected', { sessionId, reason });
          }
        }
      } catch (err) {
        console.error(err);
      }
    });

    socket.on('webrtc_offer', ({ sessionId, offer, targetId, senderId }) => {
      if (targetId) {
        io.to(targetId.toString()).emit('webrtc_offer_received', { sessionId, offer, senderId });
      } else {
        socket.to(`session_${sessionId}`).emit('webrtc_offer_received', { sessionId, offer });
      }
    });

    socket.on('webrtc_answer', ({ sessionId, answer, targetId, senderId }) => {
      if (targetId) {
        io.to(targetId.toString()).emit('webrtc_answer_received', { sessionId, answer, senderId });
      } else {
        socket.to(`session_${sessionId}`).emit('webrtc_answer_received', { sessionId, answer });
      }
    });

    socket.on('webrtc_ice', ({ sessionId, candidate, targetId, senderId }) => {
      if (targetId) {
        io.to(targetId.toString()).emit('webrtc_ice_received', { sessionId, candidate, senderId });
      } else {
        socket.to(`session_${sessionId}`).emit('webrtc_ice_received', { sessionId, candidate });
      }
    });

    socket.on('call_hangup', async ({ sessionId, senderId }) => {
      try {
        const session = await ChatSession.findById(sessionId);
        if (session && session.isGroupChat) {
          socket.to(`session_${sessionId}`).emit('group_call_left', { sessionId, senderId });
        } else {
          socket.to(`session_${sessionId}`).emit('call_hungup', { sessionId });
          if (socket.merchantId) {
            io.to(socket.merchantId.toString()).emit('call_hungup', { sessionId });
          }
        }
      } catch (err) {
        console.error(err);
      }
    });

    socket.on('disconnect', async () => {
      console.log('User disconnected:', socket.id);
      cleanupViewing(socket);
      
      if (socket.merchantId) {
        try {
          const sockets = await io.in(socket.merchantId.toString()).fetchSockets();
          if (sockets.length === 0) {
            connectedAgents.delete(socket.merchantId.toString());
            io.emit('online_agents', Array.from(connectedAgents));
          }
        } catch (err) {
          console.error('Error on agent disconnect cleanup:', err);
        }
      }

      if (socket.sessionId) {
        try {
          // Check if there are any messages in this session
          const msgCount = await Message.countDocuments({ sessionId: socket.sessionId });
          if (msgCount === 0) {
            await ChatSession.findByIdAndDelete(socket.sessionId);
            console.log(`[Visitor Disconnect] Deleted empty session: ${socket.sessionId}`);
            if (socket.merchantId) {
              io.to(socket.merchantId.toString()).emit('session_deleted', { sessionId: socket.sessionId });
            }
          } else {
            const session = await ChatSession.findByIdAndUpdate(
              socket.sessionId,
              { visitorStatus: 'offline' },
              { new: true }
            );
            if (socket.merchantId) {
              await notifyMerchants(socket.merchantId, socket.sessionId, 'session_updated', session);
            }
          }
        } catch (err) {
          console.error('Error handling visitor disconnect cleanup', err);
        }
      }
    });
  });
};

